#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版出牌分析器 - 提供智能出牌建议
"""

from typing import List, Dict, Tuple
from collections import Counter
import math

# 导入核心模块
try:
    from mahjong_analyzer_complete import MahjongTile, YakuAnalyzer, WinProbabilityCalculator
except ImportError:
    # 如果导入失败，创建基本的类
    class MahjongTile:
        def __init__(self, suit, value):
            self.suit = suit
            self.value = value
        
        def __str__(self):
            if self.suit == 'man':
                return f"{self.value}万"
            elif self.suit == 'pin':
                return f"{self.value}筒"
            elif self.suit == 'sou':
                return f"{self.value}条"
            elif self.suit == 'honor':
                honor_map = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}
                return honor_map.get(self.value, f"字{self.value}")
            return f"{self.suit}{self.value}"
    
    class YakuAnalyzer:
        @staticmethod
        def analyze_yaku(tiles): return []
    
    class WinProbabilityCalculator:
        @staticmethod
        def calculate_shanten(tiles): return 6
        @staticmethod
        def estimate_win_probability(tiles, remaining=70): return 0.1
def get_enhanced_discard_advice(hand_tiles: List[MahjongTile], 
                               discard_records: Dict[str, List[MahjongTile]] = None,
                               player_wind: str = '东',
                               round_wind: str = '东') -> Dict[str, any]:
    """
    获取增强的出牌建议
    
    Args:
        hand_tiles: 当前手牌
        discard_records: 各家出牌记录
        player_wind: 玩家门风
        round_wind: 场风
    
    Returns:
        包含分析结果的字典
    """
    
    if not hand_tiles:
        return {
            'shanten': 6,
            'advice': "请输入手牌",
            'suggested_discard': None,
            'win_probability': 0.0,
            'yaku_potential': []
        }
    
    # 计算当前向听数
    shanten = WinProbabilityCalculator.calculate_shanten(hand_tiles)
    
    # 分析和牌概率
    win_prob = WinProbabilityCalculator.estimate_win_probability(hand_tiles)
    
    # 分析役种潜力
    yaku_analysis = YakuAnalyzer.analyze_yaku(hand_tiles)
    
    # 推荐出牌（简化算法）
    suggested_discard = _get_best_discard(hand_tiles, shanten)
    
    # 构建建议文本
    advice_parts = []
    
    if shanten == 0:
        advice_parts.append("🎉 已听牌！")
    elif shanten == 1:
        advice_parts.append("🎯 一向听")
    else:
        advice_parts.append(f"向听数: {shanten}")
    
    if suggested_discard:
        advice_parts.append(f"建议出牌: {suggested_discard}")
    
    if yaku_analysis:
        advice_parts.append(f"役种潜力: {', '.join(yaku_analysis)}")
    
    advice_text = "\n".join(advice_parts)
    
    return {
        'shanten': shanten,
        'advice': advice_text,
        'suggested_discard': str(suggested_discard) if suggested_discard else None,
        'win_probability': win_prob,
        'yaku_potential': yaku_analysis
    }

def _get_best_discard(hand_tiles: List[MahjongTile], shanten: int) -> Optional[MahjongTile]:
    """获取最佳出牌建议"""
    
    if not hand_tiles:
        return None
    
    # 统计牌型
    tile_counts = Counter(hand_tiles)
    
    # 优先打出孤立牌
    isolated_tiles = []
    honor_terminals = []
    middle_tiles = []
    
    for tile in hand_tiles:
        count = tile_counts[tile]
        
        if count == 1:
            if tile.is_honor() or tile.is_terminal():
                honor_terminals.append(tile)
            else:
                # 检查是否有相邻牌
                has_adjacent = False
                for delta in [-1, 1]:
                    adjacent = MahjongTile(tile.suit, tile.value + delta)
                    if adjacent in tile_counts:
                        has_adjacent = True
                        break
                
                if not has_adjacent:
                    isolated_tiles.append(tile)
                else:
                    middle_tiles.append(tile)
    
    # 出牌优先级：
    # 1. 孤立的中张牌（4-6）
    # 2. 孤立的老头牌（1、9）  
    # 3. 字牌
    # 4. 有相邻牌的牌
    
    # 优先选择孤立的中张牌
    middle_isolated = [t for t in isolated_tiles if 4 <= t.value <= 6]
    if middle_isolated:
        return middle_isolated[0]
    
    # 其次选择孤立的老头牌
    terminal_isolated = [t for t in isolated_tiles if t.value in [1, 9]]
    if terminal_isolated:
        return terminal_isolated[0]
    
    # 最后选择字牌
    if honor_terminals:
        return honor_terminals[0]
    
    # 默认返回第一张牌
    return hand_tiles[0] if hand_tiles else None

def analyze_discard_pattern(discarded_tiles: List[MahjongTile]) -> Dict[str, any]:
    """分析出牌模式"""
    
    if not discarded_tiles:
        return {
            'safe_tiles': [],
            'danger_level': 'low',
            'pattern': '无出牌记录'
        }
    
    tile_counts = Counter(discarded_tiles)
    
    # 简单的安全牌判断
    safe_candidates = []
    for tile, count in tile_counts.items():
        if count >= 3:  # 某牌已经被打3张以上，比较安全
            safe_candidates.append(tile)
    
    # 危险度评估
    if len(discarded_tiles) < 5:
        danger_level = 'low'
    elif len(discarded_tiles) < 15:
        danger_level = 'medium'
    else:
        danger_level = 'high'
    
    return {
        'safe_tiles': safe_candidates,
        'danger_level': danger_level,
        'pattern': f"已出牌{len(discarded_tiles)}张"
    }

__all__ = ['get_enhanced_discard_advice', 'analyze_discard_pattern']