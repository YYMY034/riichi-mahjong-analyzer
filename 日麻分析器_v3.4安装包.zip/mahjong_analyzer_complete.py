#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日麻分析器核心模块 - 包含牌、役种分析和胜率计算
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Optional, Set, Tuple
from collections import Counter
import math


class Suit(Enum):
    """牌花色枚举"""
    MAN = 'man'      # 万
    PIN = 'pin'      # 筒  
    SOU = 'sou'      # 条
    HONOR = 'honor'  # 字牌


@dataclass
class MahjongTile:
    """麻将牌类"""
    suit: str
    value: int
    
    def __str__(self):
        if self.suit == 'man':
            return f"{self.value}万"
        elif self.suit == 'pin':
            return f"{self.value}筒"
        elif self.suit == 'sou':
            return f"{self.value}条"
        elif self.suit == 'honor':
            honor_map = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}
            return honor_map.get(self.value, f"字{self.value}")
        else:
            return f"{self.suit}{self.value}"
    
    def __repr__(self):
        return self.__str__()
    
    def __eq__(self, other):
        if not isinstance(other, MahjongTile):
            return False
        return self.suit == other.suit and self.value == other.value
    
    def __hash__(self):
        return hash((self.suit, self.value))
    
    def is_yaochu(self) -> bool:
        """是否幺九牌（老头牌或字牌）"""
        return self.suit == 'honor' or self.value in [1, 9]
    
    def is_honor(self) -> bool:
        """是否字牌"""
        return self.suit == 'honor'
    
    def is_terminal(self) -> bool:
        """是否老头牌（1、9）"""
        return self.value in [1, 9]
    
    @staticmethod
    def from_str(s: str) -> Optional['MahjongTile']:
        """从字符串解析牌（如 '3万' -> MahjongTile('man', 3)）"""
        s = s.strip()
        if not s:
            return None
        for suit, suffix in [('man', '万'), ('pin', '筒'), ('sou', '条')]:
            if s.endswith(suffix):
                num_part = s[:-len(suffix)]
                try:
                    val = int(num_part)
                    if 1 <= val <= 9:
                        return MahjongTile(suit, val)
                except ValueError:
                    pass
        honor_map = {'东': 1, '南': 2, '西': 3, '北': 4, '白': 5, '发': 6, '中': 7}
        if s in honor_map:
            return MahjongTile('honor', honor_map[s])
        return None


class YakuAnalyzer:
    """役种分析器"""
    
    @staticmethod
    def analyze_yaku(hand_tiles: List[MahjongTile], winning_tile: Optional[MahjongTile] = None) -> List[str]:
        """分析手牌可能的役种"""
        if not hand_tiles:
            return []
        
        yaku_list = []
        
        # 检查基本役种
        if YakuAnalyzer._is_pinfu(hand_tiles):
            yaku_list.append("平和")
        
        if YakuAnalyzer._is_tanyao(hand_tiles):
            yaku_list.append("断幺九")
        
        if YakuAnalyzer._is_iipeikou(hand_tiles):
            yaku_list.append("一杯口")
        
        if YakuAnalyzer._is_yakuhai(hand_tiles):
            yaku_list.append("役牌")
        
        # 检查高级役种
        if YakuAnalyzer._is_chantai(hand_tiles):
            yaku_list.append("混全带幺九")
        
        if YakuAnalyzer._is_sanshoku(hand_tiles):
            yaku_list.append("三色同顺")
        
        if YakuAnalyzer._is_ittsu(hand_tiles):
            yaku_list.append("一气通贯")
        
        if YakuAnalyzer._is_honroutou(hand_tiles):
            yaku_list.append("混老头")
            
        return yaku_list
    
    @staticmethod
    def _is_pinfu(tiles: List[MahjongTile]) -> bool:
        """检查平和（基本形：4顺子+1对子）"""
        # 简化的平和检查
        tile_counts = Counter(tiles)
        pairs = sum(1 for count in tile_counts.values() if count == 2)
        return pairs == 1 and len(tiles) == 14
    
    @staticmethod
    def _is_tanyao(tiles: List[MahjongTile]) -> bool:
        """检查断幺九（无老头牌和字牌）"""
        return all(not tile.is_yaochu() for tile in tiles)
    
    @staticmethod
    def _is_iipeikou(tiles: List[MahjongTile]) -> bool:
        """检查一杯口（一对顺子）"""
        tile_counts = Counter(tiles)
        sequence_pairs = 0
        
        for suit in ['man', 'pin', 'sou']:
            suit_tiles = [t for t in tiles if t.suit == suit]
            suit_counts = Counter(suit_tiles)
            
            for value in range(1, 8):  # 检查1-7的顺子
                sequence = [MahjongTile(suit, value), MahjongTile(suit, value+1), MahjongTile(suit, value+2)]
                if all(suit_counts[tile] >= 2 for tile in sequence):
                    sequence_pairs += 1
        
        return sequence_pairs >= 1
    
    @staticmethod
    def _is_yakuhai(tiles: List[MahjongTile]) -> bool:
        """检查役牌（风牌或三元牌刻子）"""
        tile_counts = Counter(tiles)
        
        # 检查风牌刻子
        for wind in [1, 2, 3, 4]:  # 东南西北
            wind_tile = MahjongTile('honor', wind)
            if tile_counts[wind_tile] >= 3:
                return True
        
        # 检查三元牌刻子
        for dragon in [5, 6, 7]:  # 白發中
            dragon_tile = MahjongTile('honor', dragon)
            if tile_counts[dragon_tile] >= 3:
                return True
        
        return False
    
    @staticmethod
    def _is_chantai(tiles: List[MahjongTile]) -> bool:
        """检查混全带幺九"""
        tile_counts = Counter(tiles)
        yaochu_count = sum(count for tile, count in tile_counts.items() if tile.is_yaochu())
        return 0 < yaochu_count < len(tiles) and yaochu_count >= 4
    
    @staticmethod
    def _is_sanshoku(tiles: List[MahjongTile]) -> bool:
        """检查三色同顺"""
        for value in range(1, 8):
            found_in_suits = set()
            for suit in ['man', 'pin', 'sou']:
                sequence = [MahjongTile(suit, value), MahjongTile(suit, value+1), MahjongTile(suit, value+2)]
                if all(tiles.count(tile) >= 1 for tile in sequence):
                    found_in_suits.add(suit)
            if len(found_in_suits) >= 3:
                return True
        return False
    
    @staticmethod
    def _is_ittsu(tiles: List[MahjongTile]) -> bool:
        """检查一气通贯"""
        for suit in ['man', 'pin', 'sou']:
            suit_tiles = [t for t in tiles if t.suit == suit]
            if len(suit_tiles) >= 9:
                # 检查是否有123, 456, 789顺子
                has_123 = any(t.suit == suit and t.value in [1,2,3] for t in tiles)
                has_456 = any(t.suit == suit and t.value in [4,5,6] for t in tiles)
                has_789 = any(t.suit == suit and t.value in [7,8,9] for t in tiles)
                if has_123 and has_456 and has_789:
                    return True
        return False
    
    @staticmethod
    def _is_honroutou(tiles: List[MahjongTile]) -> bool:
        """检查混老头（只有幺九牌）"""
        return all(tile.is_yaochu() for tile in tiles)


class WinProbabilityCalculator:
    """胜率计算器"""
    
    @staticmethod
    def calculate_shanten(hand_tiles: List[MahjongTile]) -> int:
        """计算向听数"""
        if len(hand_tiles) == 0:
            return 6  # 空手牌
        
        # 简化的向听数计算
        unique_tiles = len(set(hand_tiles))
        pairs = sum(1 for count in Counter(hand_tiles).values() if count >= 2)
        
        # 基于牌数和配对数估算向听数
        base_shanten = max(0, 8 - unique_tiles - pairs)
        
        # 手牌太少时的调整
        if len(hand_tiles) < 13:
            return max(base_shanten, 14 - len(hand_tiles) - 1)
        
        return max(0, base_shanten)
    
    @staticmethod
    def estimate_win_probability(hand_tiles: List[MahjongTile], remaining_tiles: int = 70) -> float:
        """估算和牌概率"""
        shanten = WinProbabilityCalculator.calculate_shanten(hand_tiles)
        
        if shanten == 0:
            # 听牌状态 - 较高概率
            return min(0.8, remaining_tiles / 100)
        elif shanten == 1:
            # 一向听 - 中等概率
            return min(0.6, remaining_tiles / 120)
        elif shanten == 2:
            # 二向听 - 较低概率
            return min(0.3, remaining_tiles / 200)
        else:
            # 多向听 - 很低概率
            return min(0.1, remaining_tiles / 300)
    
    @staticmethod
    def calculate_tile_efficiency(hand_tiles: List[MahjongTile]) -> Dict[MahjongTile, float]:
        """计算各牌的进张效率"""
        efficiency = {}
        
        for tile in hand_tiles:
            # 简化的效率计算
            if tile.is_honor() or tile.is_terminal():
                efficiency[tile] = 0.3  # 字牌和老头牌效率较低
            else:
                efficiency[tile] = 0.8  # 中张数牌效率较高
        
        return efficiency


__all__ = ['MahjongTile', 'Suit', 'YakuAnalyzer', 'WinProbabilityCalculator']