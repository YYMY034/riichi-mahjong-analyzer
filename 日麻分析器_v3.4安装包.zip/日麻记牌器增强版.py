#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日麻记牌器增强版
在完整版基础上添加完整工作日志、导出功能和完善碰杠吃系统

核心增强功能：
1. 修复随机13张牌生成问题
2. 修复界面显示问题（分析框显示完整）
3. 添加自动记录完整工作日志功能
4. 添加导出功能按钮
5. 完善碰牌、杠牌记录系统
6. 分析器识别碰杠吃作为刻子/对子
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import random
from collections import Counter
import datetime
import json
import os

# 导入分析模块
from mahjong_analyzer_complete import MahjongTile, YakuAnalyzer, WinProbabilityCalculator
from wind_analyzer import MahjongTurnManager, WindAnalyzer


class MahjongHandOrganizer:
    """智能手牌整理器 - 自动识别和整理刻子、顺子、对子"""
    
    @staticmethod
    def organize_hand(hand_tiles):
        """智能整理手牌，将刻子、顺子分组"""
        if not hand_tiles:
            return []
        
        # 排序手牌为字符串顺序
        sorted_tiles = sorted(hand_tiles, key=str)
        
        # 用索引追踪已使用的牌，避免重复牌被误判
        used = [False] * len(sorted_tiles)
        organized = []
        
        # 1. 优先找刻子
        tile_counts = {}
        for tile in sorted_tiles:
            tile_counts[tile] = tile_counts.get(tile, 0) + 1
        
        for tile, count in tile_counts.items():
            if count >= 3:
                # 刻子
                added = 0
                for idx, t in enumerate(sorted_tiles):
                    if added >= 3:
                        break
                    if not used[idx] and t == tile:
                        used[idx] = True
                        organized.append(t)
                        added += 1
        
        # 2. 找顺子 (只对数牌) - 从未使用的牌中找
        # 构建未使用牌到 sorted_tiles 索引的映射（每个牌只对应一个未使用的索引）
        remaining_tiles = []
        for idx in range(len(sorted_tiles)):
            if not used[idx]:
                remaining_tiles.append(sorted_tiles[idx])
        shuntsu_groups = MahjongHandOrganizer._find_shuntsu(remaining_tiles)
        
        for group in shuntsu_groups:
            organized.extend(group)
            # 标记顺子中的牌在 sorted_tiles 中为已使用
            for gtile in group:
                for idx in range(len(sorted_tiles)):
                    if not used[idx] and sorted_tiles[idx] == gtile:
                        used[idx] = True
                        break
        
        # 3. 添加剩余的单张和对子
        for idx in range(len(sorted_tiles)):
            if not used[idx]:
                organized.append(sorted_tiles[idx])
        
        return organized if organized else sorted_tiles
    
    @staticmethod
    def _find_shuntsu(tiles):
        """寻找顺子组合"""
        shuntsu_groups = []
        used = [False] * len(tiles)
        
        for i in range(len(tiles)):
            if used[i] or tiles[i].suit == 'honor':
                continue
                
            # 寻找以当前牌为起点的顺子
            base_tile = tiles[i]
            if base_tile.value > 7:
                continue
                
            # 找第二张牌
            second_idx = -1
            for j in range(i+1, len(tiles)):
                if (not used[j] and 
                    tiles[j].suit == base_tile.suit and 
                    tiles[j].value == base_tile.value + 1):
                    second_idx = j
                    break
            
            # 找第三张牌
            third_idx = -1
            if second_idx != -1:
                for k in range(second_idx+1, len(tiles)):
                    if (not used[k] and 
                        tiles[k].suit == base_tile.suit and 
                        tiles[k].value == base_tile.value + 2):
                        third_idx = k
                        break
            
            # 找到完整顺子
            if second_idx != -1 and third_idx != -1:
                group = [tiles[i], tiles[second_idx], tiles[third_idx]]
                shuntsu_groups.append(group)
                
                # 标记为已使用
                used[i] = True
                used[second_idx] = True
                used[third_idx] = True
        
        return shuntsu_groups
    
    @staticmethod
    def format_organized_display(organized_tiles):
        """格式化整理后的手牌显示 - 按万/筒/条/字分类
        使用索引追踪已分组的牌，确保重复牌不被遗漏"""
        if not organized_tiles:
            return "手牌为空"
        
        # 按花色分组
        suit_names = {'man': '万', 'pin': '筒', 'sou': '条', 'honor': '字'}
        groups_by_suit = {'man': [], 'pin': [], 'sou': [], 'honor': []}
        for tile in organized_tiles:
            groups_by_suit[tile.suit].append(tile)
        
        display_parts = []
        for suit in ['man', 'pin', 'sou', 'honor']:
            tiles = groups_by_suit[suit]
            if not tiles:
                continue
            
            # 在花色内分组：刻子、顺子、对子、单张
            tile_list = sorted(tiles, key=lambda t: (t.suit, t.value))
            used = [False] * len(tile_list)
            groups = []
            i = 0
            
            while i < len(tile_list):
                if used[i]:
                    i += 1
                    continue
                    
                current = tile_list[i]
                
                # 刻子
                if i + 2 < len(tile_list) and not used[i+1] and not used[i+2] and tile_list[i] == tile_list[i+1] == tile_list[i+2]:
                    groups.append(f"[{current}刻]")
                    used[i] = used[i+1] = used[i+2] = True
                    i += 3
                    continue
                
                # 顺子（只对数牌）- 在列表中搜索连续的三张牌
                if suit != 'honor' and current.value <= 7:
                    second_idx = -1
                    third_idx = -1
                    for j in range(i+1, len(tile_list)):
                        if not used[j] and tile_list[j].suit == current.suit and tile_list[j].value == current.value + 1:
                            second_idx = j
                            break
                    if second_idx != -1:
                        for k in range(second_idx+1, len(tile_list)):
                            if not used[k] and tile_list[k].suit == current.suit and tile_list[k].value == current.value + 2:
                                third_idx = k
                                break
                    if second_idx != -1 and third_idx != -1:
                        groups.append(f"[{current}{tile_list[second_idx]}{tile_list[third_idx]}顺]")
                        used[i] = used[second_idx] = used[third_idx] = True
                        i += 1
                        continue
                
                # 对子
                if i + 1 < len(tile_list) and not used[i+1] and tile_list[i] == tile_list[i+1]:
                    groups.append(f"[{current}对]")
                    used[i] = used[i+1] = True
                    i += 2
                    continue
                
                # 单张
                groups.append(str(current))
                used[i] = True
                i += 1
            
            display_parts.append(f"{suit_names[suit]}: {' '.join(groups)}")
        
        return "\n".join(display_parts)


class EnhancedEventLogger:
    """增强的事件日志系统 - 记录完整的工作日志"""
    
    def __init__(self):
        self.events = []
        self.session_start = datetime.datetime.now()
        
    def log_event(self, event_type, actor, tile=None, source_position=None, details=None):
        """记录一个事件"""
        event = {
            'timestamp': datetime.datetime.now().isoformat(),
            'session_time': (datetime.datetime.now() - self.session_start).total_seconds(),
            'type': event_type,  # 'draw', 'discard', 'chi', 'pon', 'kan', 'ron'
            'actor': actor,      # 操作方
            'tile': str(tile) if tile else None,
            'source_position': source_position,  # 牌来源方位
            'details': details or {}
        }
        self.events.append(event)
        return event
    
    def export_log(self, filename=None):
        """导出日志到文件"""
        if filename is None:
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"mahjong_session_{timestamp}.json"
        
        log_data = {
            'export_time': datetime.datetime.now().isoformat(),
            'session_start': self.session_start.isoformat(),
            'total_events': len(self.events),
            'events': self.events
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
        
        return filename
    
    def get_statistics(self):
        """获取游戏统计信息"""
        if not self.events:
            return {}
            
        stats = {
            'total_events': len(self.events),
            'events_by_type': Counter(),
            'events_by_player': Counter(),
            'session_duration': (datetime.datetime.now() - self.session_start).total_seconds()
        }
        
        for event in self.events:
            stats['events_by_type'][event['type']] += 1
            stats['events_by_player'][event['actor']] += 1
            
        return stats


class MahjongMeldsAnalyzer:
    """碰杠吃分析器 - 识别碰杠吃作为刻子/对子"""
    
    @staticmethod
    def analyze_with_melds(hand_tiles, melds_list):
        """分析包含碰杠吃的手牌"""
        
        # 合并手牌和明牌组进行分析
        all_tiles = hand_tiles.copy()
        for meld in melds_list:
            all_tiles.extend(meld['tiles'])
        
        return {
            'with_melds': all_tiles,
            'shanten': WinProbabilityCalculator.calculate_shanten(hand_tiles),
            'yaku_analysis': YakuAnalyzer.analyze_yaku(hand_tiles),
            'meld_count': len(melds_list),
            'total_tile_count': len(all_tiles)
        }
    
    @staticmethod
    def convert_meld_to_text(meld):
        """将碰杠吃转换为文本显示"""
        meld_type = meld['type']
        tiles = meld['tiles']
        
        if meld_type == 'pon':
            return f"碰: {' '.join(str(t) for t in tiles)}"
        elif meld_type == 'kan':
            return f"杠: {' '.join(str(t) for t in tiles)}"
        elif meld_type == 'chi':
            return f"吃: {' '.join(str(t) for t in tiles)}"
        else:
            return f"明牌: {' '.join(str(t) for t in tiles)}"


class CompleteMahjongRecordEnhancedGUI:
    """增强版日麻记牌器GUI"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("日麻记牌器 (增强版) v3.2")
        self.root.geometry("1400x900")
        
        # ===== 核心数据系统 =====
        
        # 四家完整手牌系统
        self.player_hands = {
            'east': [],
            'south': [],  
            'west': [],
            'north': []
        }
        
        # 四家公开舍牌池
        self.public_discards = {
            'east': [],
            'south': [],
            'west': [],
            'north': []
        }
        
        # 各家的碰杠明牌组（重要！）
        self.player_melds = {
            'east': [],
            'south': [],
            'west': [],
            'north': []
        }
        
        # 增强的事件日志系统
        self.event_logger = EnhancedEventLogger()
        
        # 风位管理
        self.wind_analyzer = WindAnalyzer()
        self.turn_manager = MahjongTurnManager()
        
        # 环境设置
        self.player_wind_var = tk.StringVar(value="东")
        self.round_wind_var = tk.StringVar(value="东")
        self.is_dealer_var = tk.BooleanVar(value=False)
        
        # 当前记录状态
        self.current_record_position = 'east'
        self.record_mode = 'discard'
        
        # 本局dora指示牌列表
        self.current_dora_indicators = []
        
        # 日志显示变量
        self.work_log_text = tk.StringVar(value="游戏开始 - 等待记录...\n")
        
        # 其他家出牌临时存储
        self._pending_other_discard = None
        
        # 创建界面
        self._setup_ui()
        self._update_button_states()
        self._update_current_position_display()
        
    def setup_auto_rotation_system(self):
        """设置自动轮换系统"""
        # 添加自动轮换状态跟踪
        self.auto_rotation_enabled = False
        self.rotation_mode = 'round'  # 'round':一轮 ', 'eternal':永不停息
        self.rotation_speed = 1000  # 毫秒
        self.forced_meld_change = False  # 标记是否有强制轮换事件（碰杠吃）
        
        # 创建用于自动轮换的高优先级事件队列
        self.rotation_queue = []
        
    def _setup_ui(self):
        """创建重新设计的紧凑型用户界面"""
        # 使用更好的布局管理
        main_frame = ttk.Frame(self.root, padding="5")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 环境设置 - 简化到顶部一行
        env_frame = ttk.LabelFrame(main_frame, text="🌍 设置", padding="5")
        env_frame.grid(row=0, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 5))
        
        ttk.Label(env_frame, text="自风:").pack(side="left", padx=2)
        player_wind_combo = ttk.Combobox(
            env_frame, 
            textvariable=self.player_wind_var,
            values=["东", "南", "西", "北"], 
            width=3,
            state="readonly"
        )
        player_wind_combo.pack(side="left", padx=2)
        player_wind_combo.bind('<<ComboboxSelected>>', self._on_wind_changed)
        
        ttk.Label(env_frame, text="场风:").pack(side="left", padx=2)
        round_wind_combo = ttk.Combobox(
            env_frame,
            textvariable=self.round_wind_var, 
            values=["东", "南", "西", "北"],
            width=3,
            state="readonly"
        )
        round_wind_combo.pack(side="left", padx=2)
        
        ttk.Checkbutton(env_frame, text="庄家", variable=self.is_dealer_var).pack(side="left", padx=2)
        ttk.Button(env_frame, text="新游戏", command=self._start_new_game).pack(side="left", padx=5)
        ttk.Button(env_frame, text="导出", command=self._export_session_log).pack(side="left", padx=2)
        ttk.Button(env_frame, text="开始", command=self._start_game, style='Accent.TButton').pack(side="left", padx=2)
        ttk.Button(env_frame, text="关于", command=self._show_about).pack(side="left", padx=2)
        
        # 当前轮到谁出牌 - 醒目显示
        self.current_turn_label = tk.Label(
            env_frame,
            text="轮到东家出牌",
            font=('Arial', 13, 'bold'),
            fg='white',
            bg='#2196F3',
            padx=15,
            pady=3
        )
        self.current_turn_label.pack(side="right", padx=10)
        
        # 主要区域 - 三列布局
        left_panel = ttk.Frame(main_frame)
        left_panel.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 5))
        
        middle_panel = ttk.Frame(main_frame)  
        middle_panel.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        right_panel = ttk.Frame(main_frame)
        right_panel.grid(row=1, column=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(5, 0))
        
        # 当前状态 - 简化并增加滚动功能
        status_frame = ttk.LabelFrame(left_panel, text="🎯 当前状态", padding="5")
        status_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 5))
        
        self.work_log_display = scrolledtext.ScrolledText(
            status_frame,
            height=6,
            width=40,
            font=('Courier', 9)
        )
        self.work_log_display.pack(fill='x', expand=True)
        
        # 我的手牌区域
        hand_frame = ttk.LabelFrame(left_panel, text="🎴 我的手牌", padding="5")
        hand_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        # 手牌显示
        self.current_hand_display = scrolledtext.ScrolledText(
            hand_frame, 
            height=10, 
            width=50, 
            font=('Courier', 12)
        )
        self.current_hand_display.grid(row=0, column=0, columnspan=20, pady=(0, 5))
        
        # 创建紧凑的牌按钮网格
        self._create_compact_tile_buttons(hand_frame)
        
        # 手牌控制按钮
        btn_frame = ttk.Frame(hand_frame)
        btn_frame.grid(row=10, column=0, columnspan=20, pady=5)
        
        ttk.Button(btn_frame, text="清空", command=self._clear_current_hand).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="随机13张", command=self._generate_random_hand).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="删除", command=self._delete_tile).pack(side="left", padx=2)

        # 四家记录模式切换 
        record_frame = ttk.LabelFrame(left_panel, text="🎯 记录模式", padding="5")
        record_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.record_mode_var = tk.StringVar(value="current")
        ttk.Radiobutton(record_frame, text="当前轮到谁记谁", variable=self.record_mode_var, 
                       value="current", command=self._switch_record_mode).pack(anchor="w")
        ttk.Radiobutton(record_frame, text="固定记手牌", variable=self.record_mode_var, 
                       value="fixed", command=self._switch_record_mode).pack(anchor="w")
        
        # 四家记录选择
        self.record_player_var = tk.StringVar(value="east")
        player_frame = ttk.Frame(record_frame)
        player_frame.pack(fill="x", pady=5)
        
        ttk.Label(player_frame, text="记录玩家:").pack(side="left")
        player_combo = ttk.Combobox(
            player_frame,
            textvariable=self.record_player_var,
            values=[("东", "east"), ("南", "south"), ("西", "west"), ("北", "north")],
            width=5,
            state="readonly"
        )
        player_combo.pack(side="left", padx=5)
        
        ttk.Button(record_frame, text="为选中玩家输入", command=self._record_for_selected_player).pack(fill="x", pady=2)
        
        # Add combo box configuration
        player_combo['values'] = ["东", "南", "西", "北"]
        player_combo.bind('<<ComboboxSelected>>', lambda e: self._on_player_selected())
        
        # 出牌操作
        discard_frame = ttk.LabelFrame(left_panel, text="🃏 出牌操作", padding="5")
        discard_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        discard_btn_frame = ttk.Frame(discard_frame)
        discard_btn_frame.pack(pady=5)
        
        ttk.Label(discard_btn_frame, text="选择出牌:", font=('Arial', 10)).pack(side="left", padx=2)
        self.discard_var = tk.StringVar()
        self.discard_combo = ttk.Combobox(
            discard_btn_frame, 
            textvariable=self.discard_var,
            width=18,
            font=('Arial', 11),
            state="readonly"
        )
        self.discard_combo.pack(side="left", padx=2)
        ttk.Button(discard_btn_frame, text="出牌", command=self._discard_tile).pack(side="left", padx=2)
        ttk.Button(discard_btn_frame, text="碰", command=self._pon_action).pack(side="left", padx=2)
        ttk.Button(discard_btn_frame, text="杠", command=self._kan_action).pack(side="left", padx=2)
        ttk.Button(discard_btn_frame, text="智能分析", command=self._smart_discard_analysis).pack(side="left", padx=2)
        
        # 中间面板 - 其他三家出牌记录
        self._create_other_players_display(middle_panel)
        
        # 右侧面板 - 分析功能
        analysis_frame = ttk.LabelFrame(right_panel, text="📊 分析", padding="5")
        analysis_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 5))
        
        analysis_btn_frame = ttk.Frame(analysis_frame)
        analysis_btn_frame.pack(pady=5)
        
        # 分析按钮 + 宝牌选择按钮（同一行）
        analysis_dora_row = ttk.Frame(analysis_btn_frame)
        analysis_dora_row.pack(fill="x", pady=2)
        ttk.Button(analysis_dora_row, text="分析", command=self._analyze_hand).pack(side="left", padx=2)
        ttk.Button(analysis_dora_row, text="宝牌", command=self._select_dora_tiles, width=4).pack(side="left", padx=2)
        self.dora_display_var = tk.StringVar(value="宝牌: 未设置")
        ttk.Label(analysis_dora_row, textvariable=self.dora_display_var, font=('Arial', 9), width=12).pack(side="left", padx=2)
        
        ttk.Button(analysis_btn_frame, text="碰杠吃", command=self._pon_action).pack(fill="x", pady=2)
        ttk.Button(analysis_btn_frame, text="统计", command=self._show_statistics).pack(fill="x", pady=2)
        ttk.Button(analysis_btn_frame, text="和牌!", command=self._declare_win).pack(fill="x", pady=2)
        
        # 分析结果显示
        self.analysis_text = scrolledtext.ScrolledText(
            analysis_frame, 
            height=22,
            width=55, 
            font=('Courier', 9)
        )
        self.analysis_text.pack(fill='both', expand=True)
        
        # 明牌组显示
        meld_frame = ttk.LabelFrame(analysis_frame, text="🀄 明牌组", padding="3")
        meld_frame.pack(fill='x', pady=(5, 0))
        
        self.meld_display_text = scrolledtext.ScrolledText(
            meld_frame,
            height=3,
            width=30,
            font=('Courier', 9)
        )
        self.meld_display_text.pack(fill='x')

        # 自动轮换状态显示
        auto_frame = ttk.LabelFrame(right_panel, text="🤖 自动轮换", padding="5")
        auto_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(5, 0))

        self.auto_status_text = scrolledtext.ScrolledText(
            auto_frame,
            height=6,
            width=30,
            font=('Courier', 9)
        )
        self.auto_status_text.pack(fill='both', expand=True)
        
        # 风位关系显示
        wind_frame = ttk.LabelFrame(right_panel, text="🧭 风位关系", padding="5")
        wind_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.wind_relations_text = scrolledtext.ScrolledText(
            wind_frame, 
            height=8, 
            width=30, 
            font=('Courier', 9)
        )
        self.wind_relations_text.pack(fill='both', expand=True)
        
        # 配置网格权重
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=0)
        main_frame.columnconfigure(2, weight=3)
        main_frame.rowconfigure(1, weight=1)
        left_panel.rowconfigure(1, weight=1)
        middle_panel.rowconfigure(0, weight=1)
        right_panel.rowconfigure(0, weight=1)
        
        # 初始化界面状态
        self._update_wind_relations_display()
        
    def _create_compact_tile_buttons(self, parent):
        """创建紧凑的牌按钮网格"""
        # 数牌按钮 (万筒条)
        row = 1
        for suit, suit_name in [('man', '万'), ('pin', '筒'), ('sou', '条')]:
            ttk.Label(parent, text=suit_name, font=('Arial', 8)).grid(row=row, column=0, sticky="w")
            for num in range(1, 10):
                btn = ttk.Button(
                    parent,
                    text=str(num),
                    width=2,
                    command=lambda s=suit, n=num: self._add_tile_to_current_hand(s, n)
                )
                btn.grid(row=row, column=num, padx=0, pady=0, sticky="w")
            row += 1
        
        # 字牌按钮
        honor_names = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}
        for idx, (num, name) in enumerate(honor_names.items()):
            btn = ttk.Button(
                parent,
                text=name,
                width=2,
                command=lambda n=num: self._add_tile_to_current_hand('honor', n)
            )
            btn.grid(row=4, column=idx+1, padx=0, pady=0, sticky="w")
    
    def _create_other_players_display(self, parent):
        """创建其他三家出牌显示区域"""
        title_frame = ttk.LabelFrame(parent, text="👥 其他三家出牌记录", padding="5")
        title_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 获取相对位置
        positions = self.turn_manager.get_relative_positions()
        wind_names = self.turn_manager.wind_names
        
        # 上家显示
        prev_frame = ttk.LabelFrame(title_frame, text=f"⬆️ {wind_names[positions['prev']]}家 (上家)", padding="3")
        prev_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 5))
        self.prev_player_display = scrolledtext.ScrolledText(
            prev_frame,
            height=5,
            width=22,
            font=('Courier', 10)
        )
        self.prev_player_display.pack(fill='both', expand=True)
        
        # 对家显示
        opposite_frame = ttk.LabelFrame(title_frame, text=f"⬇️ {wind_names[positions['opposite']]}家 (对家)", padding="3")
        opposite_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        self.opposite_player_display = scrolledtext.ScrolledText(
            opposite_frame,
            height=5,
            width=22,
            font=('Courier', 10)
        )
        self.opposite_player_display.pack(fill='both', expand=True)
        
        # 下家显示  
        next_frame = ttk.LabelFrame(title_frame, text=f"➡️ {wind_names[positions['next']]}家 (下家)", padding="3")
        next_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(5, 0))
        self.next_player_display = scrolledtext.ScrolledText(
            next_frame,
            height=5,
            width=22,
            font=('Courier', 10)
        )
        self.next_player_display.pack(fill='both', expand=True)
        
        # 配置权重
        title_frame.rowconfigure(0, weight=1)
        title_frame.rowconfigure(1, weight=1)
        title_frame.rowconfigure(2, weight=1)
        title_frame.columnconfigure(0, weight=1)
        
        # 初始化显示
        self._update_other_players_display()
    
    def _update_other_players_display(self):
        """更新其他三家出牌显示"""
        positions = self.turn_manager.get_relative_positions()
        
        # 更新上家显示
        self._update_single_player_display(
            self.prev_player_display,
            positions['prev'],
            self.public_discards[positions['prev']]
        )
        
        # 更新对家显示
        self._update_single_player_display(
            self.opposite_player_display,
            positions['opposite'],
            self.public_discards[positions['opposite']]
        )
        
        # 更新下家显示
        self._update_single_player_display(
            self.next_player_display,
            positions['next'],
            self.public_discards[positions['next']]
        )
    
    def _update_single_player_display(self, display_widget, position, discarded_tiles):
        """更新单个玩家的出牌显示"""
        display_widget.config(state='normal')
        display_widget.delete(1.0, tk.END)
        
        if discarded_tiles:
            # 按行显示，每行最多8张牌
            line_count = 0
            current_line = ""
            
            for tile in discarded_tiles[-20:]:  # 只显示最近20张
                if line_count >= 8:
                    display_widget.insert(tk.END, current_line + "\n")
                    current_line = str(tile) + " "
                    line_count = 1
                else:
                    current_line += str(tile) + " "
                    line_count += 1
            
            if current_line:
                display_widget.insert(tk.END, current_line)
            
            # 显示总数量
            total_count = len(discarded_tiles)
            if total_count > 20:
                display_widget.insert(tk.END, f"\n... 共 {total_count} 张")
        else:
            display_widget.insert(tk.END, "暂无出牌")
        
        display_widget.config(state='disabled')
        display_widget.see(tk.END)  # 滚动到最新内容

    # 其余方法保持与原版本相同，但添加日志记录...
    
    def _add_tile_to_current_hand(self, suit, value):
        """向当前玩家手牌添加牌
        - 轮到我时：牌进入我的手牌
        - 轮到其他家时：牌直接进入出牌选择框（不进入手牌）
        """
        tile = MahjongTile(suit, value)
        
        current_turn = self.turn_manager.current_turn
        my_pos = self.turn_manager.get_my_position()
        
        if current_turn == my_pos:
            # 轮到我：牌进入我的手牌
            self.player_hands[my_pos].append(tile)
            self.event_logger.log_event('draw', my_pos, tile, details={
                'action': 'manual_input',
                'record_mode': 'self'
            })
            self._update_hand_display()
            self._update_discard_combo()
            self._update_work_log(f"🎴 摸牌: {tile} (我的手牌)")
            self._real_time_analysis(my_pos)
        else:
            # 轮到其他家：牌直接进入出牌选择框
            wind_name = self.turn_manager.wind_names[current_turn]
            # 设置出牌下拉框为这张牌
            self.discard_combo['values'] = [str(tile)]
            self.discard_var.set(str(tile))
            # 记录到临时变量供出牌使用
            self._pending_other_discard = tile
            self._update_work_log(f"🎴 {wind_name}家出牌选择: {tile} (点击出牌确认)")
    
    def _switch_record_mode(self):
        """切换记录模式时更新UI显示"""
        mode = self.record_mode_var.get()
        if mode == "current":
            self._update_work_log("📋 切换到自动轮换模式: 当前轮到谁记谁")
        else:
            self._update_work_log("📋 切换到固定记录模式: 固定记手牌")
        # 更新手牌显示
        self._update_hand_display()
        self._update_discard_combo()
        self._update_other_players_display()
    
    def _on_player_selected(self):
        """当选择记录玩家时更新显示"""
        selected = self.record_player_var.get()
        wind_map = {'东': 'east', '南': 'south', '西': 'west', '北': 'north'}
        pos = wind_map.get(selected, 'east')
        self._update_work_log(f"📋 选择记录玩家: {selected}家")
        if self.record_mode_var.get() == "fixed":
            self._update_hand_display()
            self._update_discard_combo()
    
    def _record_for_selected_player(self):
        """为选中的玩家输入牌（固定记录模式专用）"""
        selected = self.record_player_var.get()
        wind_map = {'东': 'east', '南': 'south', '西': 'west', '北': 'north'}
        pos = wind_map.get(selected, 'east')
        
        # 弹出输入对话框
        input_win = tk.Toplevel(self.root)
        input_win.title(f"为{selected}家输入牌")
        input_win.geometry("400x300")
        input_win.transient(self.root)
        input_win.grab_set()
        
        ttk.Label(input_win, text=f"为 {selected}家 输入牌", font=('Arial', 12)).pack(pady=5)
        
        suit_var = tk.StringVar(value="万")
        val_var = tk.StringVar(value="1")
        
        suit_frame = ttk.Frame(input_win)
        suit_frame.pack(pady=5)
        ttk.Label(suit_frame, text="花色:").pack(side="left")
        for s in ['万', '筒', '条']:
            ttk.Radiobutton(suit_frame, text=s, variable=suit_var, value=s).pack(side="left", padx=2)
        ttk.Radiobutton(suit_frame, text="字", variable=suit_var, value="字").pack(side="left", padx=2)
        
        val_frame = ttk.Frame(input_win)
        val_frame.pack(pady=5)
        ttk.Label(val_frame, text="数值:").pack(side="left")
        
        val_combo = ttk.Combobox(val_frame, textvariable=val_var, values=[str(i) for i in range(1, 10)], width=5, state="readonly")
        val_combo.pack(side="left", padx=5)
        
        # 字牌选择
        honor_var = tk.StringVar(value="东")
        honor_frame = ttk.Frame(input_win)
        honor_frame.pack(pady=5)
        ttk.Label(honor_frame, text="字牌:").pack(side="left")
        honor_combo = ttk.Combobox(honor_frame, textvariable=honor_var, values=["东","南","西","北","白","发","中"], width=5, state="readonly")
        honor_combo.pack(side="left", padx=5)
        
        def do_input():
            suit_name = suit_var.get()
            if suit_name == "字":
                honor_map = {"东": ('honor', 1), "南": ('honor', 2), "西": ('honor', 3), 
                            "北": ('honor', 4), "白": ('honor', 5), "发": ('honor', 6), "中": ('honor', 7)}
                suit, value = honor_map[honor_var.get()]
            else:
                suit_map = {"万": 'man', "筒": 'pin', "条": 'sou'}
                suit = suit_map[suit_name]
                value = int(val_var.get())
            
            tile = MahjongTile(suit, value)
            self.player_hands[pos].append(tile)
            self.event_logger.log_event('draw', pos, tile, details={
                'action': 'manual_input',
                'record_mode': 'fixed'
            })
            
            my_pos = self.turn_manager.get_my_position()
            if pos == my_pos:
                self._update_hand_display()
                self._update_discard_combo()
            self._update_other_players_display()
            self._update_work_log(f"📝 {selected}家输入: {tile}")
            self._real_time_analysis(pos)
            input_win.destroy()
        
        ttk.Button(input_win, text="输入", command=do_input).pack(pady=10)
        input_win.bind('<Return>', lambda e: do_input())
    
    def _generate_random_hand(self):
        """生成13张随机手牌 - 修复生成逻辑"""
        my_pos = self.turn_manager.get_my_position()
        
        # 清空当前手牌
        self.player_hands[my_pos] = []
        
        # 生成完整的麻将牌池
        all_tiles = []
        
        # 数牌 (万筒条)
        for suit in ['man', 'pin', 'sou']:
            for value in range(1, 10):
                for _ in range(4):  # 每种牌4张
                    all_tiles.append(MahjongTile(suit, value))
        
        # 字牌
        for value in range(1, 8):
            for _ in range(4):  # 每种字牌4张
                all_tiles.append(MahjongTile('honor', value))
        
        # 随机打乱并选择13张
        random.shuffle(all_tiles)
        selected_tiles = all_tiles[:13]
        # 按字符串表示排序显示
        selected_tiles.sort(key=str)  # 使用字符串表示排序
        
        self.player_hands[my_pos] = selected_tiles
        
        # 记录事件
        self.event_logger.log_event('draw_initial', my_pos, details={
            'action': 'random_generation',
            'tile_count': len(selected_tiles)
        })
        
        self._update_hand_display()
        self._update_discard_combo()
        
        # 更新工作日志
        tiles_str = ' '.join(str(tile) for tile in selected_tiles)
        self._update_work_log(f"✅ 生成13张随机手牌: {tiles_str}")
        
        messagebox.showinfo("提示", f"已生成13张随机手牌！\n{tiles_str}")
    
    def _update_work_log(self, message):
        """更新工作日志显示 - 使用新的显示框"""
        timestamp = datetime.datetime.now().strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] {message}\n"
        
        # 添加到滚动文本框顶部
        self.work_log_display.config(state='normal')
        self.work_log_display.insert('1.0', log_entry)
        
        # 保留最新的50条记录
        lines = self.work_log_display.get('1.0', tk.END).split('\n')
        if len(lines) > 50:
            # 删除旧记录，保留最新的
            new_text = '\n'.join(lines[:50])
            self.work_log_display.delete('1.0', tk.END)
            self.work_log_display.insert('1.0', new_text)
        
        self.work_log_display.config(state='disabled')
        
        # 同时记录到事件日志
        self.event_logger.log_event('system_log', 'system', details={'message': message})
    
    # Other methods continue implementation...
    
    def _pon_action(self):
        """完整的碰牌操作"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 检查是否有对子可以碰
        tile_counts = Counter(hand)
        possible_pon_tiles = [tile for tile, count in tile_counts.items() if count >= 2]
        
        if not possible_pon_tiles:
            messagebox.showinfo("提示", "手牌中没有对子，无法碰牌")
            return
            
        # 创建选择对话框
        pon_window = tk.Toplevel(self.root)
        pon_window.title("选择碰牌")
        pon_window.geometry("400x300")
        
        ttk.Label(pon_window, text="请选择要碰的牌:", font=('Arial', 12, 'bold')).pack(pady=10)
        
        # 显示可能的碰牌选项
        for tile in possible_pon_tiles:
            btn_text = f"碰 {tile}"
            ttk.Button(
                pon_window,
                text=btn_text,
                command=lambda t=tile: self._confirm_pon(t, pon_window)
            ).pack(pady=5)
        
        ttk.Button(pon_window, text="取消", command=pon_window.destroy).pack(pady=10)
    
    def _confirm_pon(self, tile, window):
        """确认碰牌"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 从手牌移除2张
        for _ in range(2):
            hand.remove(tile)
        
        # 创建明牌组
        meld = {
            'type': 'pon',
            'tiles': [tile, tile, tile],  # 碰牌需要3张相同牌
            'source': self.turn_manager.current_turn,  # 牌来源
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.player_melds[my_pos].append(meld)
        
        # 记录碰牌事件
        self.event_logger.log_event('pon', my_pos, tile, details={
            'action': 'pon',
            'meld_count': len(self.player_melds[my_pos]),
            'remaining_hand': len(hand)
        })
        
        # 碰牌后轮到碰家（我）继续
        self.turn_manager.current_turn = my_pos
        
        # 更新显示
        self._update_hand_display()
        self._update_meld_display()
        self._update_current_position_display()
        self._update_button_states()
        
        # 更新工作日志
        self._update_work_log(f"🔥 碰牌: {tile} ({my_pos}家) - 轮到我继续出牌")
        
        window.destroy()
        
        # 分析手牌
        self._analyze_current_hand()
    
    def _kan_action(self):
        """杠牌操作"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 检查是否有刻子可以杠
        tile_counts = Counter(hand)
        possible_kan_tiles = [tile for tile, count in tile_counts.items() if count >= 3]
        
        if not possible_kan_tiles:
            messagebox.showinfo("提示", "手牌中没有刻子，无法杠牌")
            return
            
        # 类似碰牌的确认过程
        kan_window = tk.Toplevel(self.root)
        kan_window.title("选择杠牌")
        kan_window.geometry("400x300")
        
        ttk.Label(kan_window, text="请选择要杠的牌:", font=('Arial', 12, 'bold')).pack(pady=10)
        
        for tile in possible_kan_tiles:
            btn_text = f"杠 {tile}"
            ttk.Button(
                kan_window,
                text=btn_text,
                command=lambda t=tile: self._confirm_kan(t, kan_window)
            ).pack(pady=5)
        
        ttk.Button(kan_window, text="取消", command=kan_window.destroy).pack(pady=10)
    
    def _confirm_kan(self, tile, window):
        """确认杠牌"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 从手牌移除3张
        for _ in range(3):
            hand.remove(tile)
        
        # 创建明牌组
        meld = {
            'type': 'kan',
            'tiles': [tile, tile, tile, tile],
            'source': 'self',
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.player_melds[my_pos].append(meld)
        
        # 记录杠牌事件
        self.event_logger.log_event('kan', my_pos, tile, details={
            'action': 'kan',
            'meld_count': len(self.player_melds[my_pos]),
            'remaining_hand': len(hand)
        })
        
        window.destroy()
        
        # 杠牌后轮到杠家（我）继续摸牌
        self._update_hand_display()
        self._update_discard_combo()
        self._handle_kan_draw()
    
    def _handle_kan_draw(self):
        """处理杠后摸牌"""
        # 简化的杠后摸牌（在实际游戏中是摸岭上牌）
        self._update_work_log(f"🎲 杠后摸牌进行中...")
        self.turn_manager.current_turn = self.turn_manager.get_my_position()
        self._update_hand_display()
        self._update_current_position_display()
    
    def _chi_action(self):
        """吃牌操作"""
        messagebox.showinfo("吃牌", "吃牌功能（只能吃上家的牌）开发中...")
    
    def _update_meld_display(self):
        """更新明牌组显示"""
        my_pos = self.turn_manager.get_my_position()
        melds = self.player_melds[my_pos]
        
        self.meld_display_text.config(state='normal')
        self.meld_display_text.delete(1.0, tk.END)
        
        if melds:
            for i, meld in enumerate(melds, 1):
                meld_text = MahjongMeldsAnalyzer.convert_meld_to_text(meld)
                self.meld_display_text.insert(tk.END, f"{i}. {meld_text}\n")
        else:
            self.meld_display_text.insert(tk.END, "无明牌组")
            
        self.meld_display_text.config(state='disabled')
    
    def _analyze_current_hand(self):
        """分析包含明牌组的当前手牌"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        melds = self.player_melds[my_pos]
        
        analysis = MahjongMeldsAnalyzer.analyze_with_melds(hand, melds)
        
        # 显示分析结果
        analysis_text = f"\n📊 包含明牌组的手牌分析:\n"
        analysis_text += f"手牌数量: {len(hand)}\n"
        analysis_text += f"明牌组数量: {len(melds)}\n"
        if melds:
            analysis_text += "明牌组:\n"
            for i, meld in enumerate(melds, 1):
                analysis_text += f"  {i}. {MahjongMeldsAnalyzer.convert_meld_to_text(meld)}\n"
        
        analysis_text += f"\n向听数: {analysis['shanten']}\n"
        analysis_text += f"役种潜力: {', '.join(analysis['yaku_analysis'])}\n"
        
        self.analysis_text.insert(tk.END, analysis_text)
        self.analysis_text.see(tk.END)
    
    def _update_current_position_display(self):
        """更新当前轮到谁显示 - 醒目标签 + 工作日志"""
        if not hasattr(self, 'turn_manager'):
            return
            
        current_turn = self.turn_manager.current_turn
        positions = self.turn_manager.get_relative_positions()
        wind_names = self.turn_manager.wind_names
        
        is_my_turn = (current_turn == positions['self'])
        
        if current_turn == positions['self']:
            display_text = f"▶ 轮到我({wind_names[current_turn]})出牌"
            bg_color = '#4CAF50'  # 绿色=我的回合
            fg_color = 'white'
        elif current_turn == positions['next']:
            display_text = f"▶ 轮到下家({wind_names[current_turn]})出牌"
            bg_color = '#FF9800'  # 橙色=其他家
            fg_color = 'white'
        elif current_turn == positions['opposite']:
            display_text = f"▶ 轮到对家({wind_names[current_turn]})出牌"
            bg_color = '#FF9800'
            fg_color = 'white'
        elif current_turn == positions['prev']:
            display_text = f"▶ 轮到上家({wind_names[current_turn]})出牌"
            bg_color = '#FF9800'
            fg_color = 'white'
        else:
            display_text = f"▶ 轮到{wind_names[current_turn]}家出牌"
            bg_color = '#FF9800'
            fg_color = 'white'
        
        self.current_position_display = display_text
        
        # 更新醒目标签
        if hasattr(self, 'current_turn_label'):
            self.current_turn_label.config(
                text=display_text,
                bg=bg_color,
                fg=fg_color
            )
        
        # 同时更新工作日志标题
        if hasattr(self, 'work_log_text'):
            self.work_log_text.set(f"🎯 {display_text}\n{self.work_log_text.get()}")
    
    def _export_session_log(self):
        """导出当前会话日志"""
        filename = self.event_logger.export_log()
        messagebox.showinfo("导出成功", f"工作日志已导出到:\n{filename}")
        self._update_work_log(f"💾 工作日志导出: {filename}")
    
    def _show_statistics(self):
        """显示统计信息"""
        stats = self.event_logger.get_statistics()
        
        stats_window = tk.Toplevel(self.root)
        stats_window.title("游戏统计")
        stats_window.geometry("500x400")
        
        text_widget = scrolledtext.ScrolledText(
            stats_window, 
            font=('Courier', 10)
        )
        text_widget.pack(fill='both', expand=True)
        
        # 显示统计信息
        text_widget.insert(tk.END, "📊 游戏统计信息\n")
        text_widget.insert(tk.END, "="*40 + "\n\n")
        
        text_widget.insert(tk.END, f"总事件数: {stats.get('total_events', 0)}\n")
        text_widget.insert(tk.END, f"游戏时长: {stats.get('session_duration', 0):.1f}秒\n\n")
        
        text_widget.insert(tk.END, "按类型统计:\n")
        for event_type, count in stats.get('events_by_type', {}).items():
            text_widget.insert(tk.END, f"  {event_type}: {count}\n")
        
        text_widget.insert(tk.END, "\n按玩家统计:\n")
        for player, count in stats.get('events_by_player', {}).items():
            text_widget.insert(tk.END, f"  {player}: {count}\n")
    
    # 其余必要的方法...
    def _update_hand_display(self):
        """更新手牌显示 - 显示手牌+碰杠明牌，按花色分类"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        melds = self.player_melds[my_pos]
        
        self.current_hand_display.config(state='normal')
        self.current_hand_display.delete(1.0, tk.END)
        
        # 显示手牌数量
        hand_count = len(hand)
        meld_count = len(melds)
        total_count = hand_count + sum(len(m['tiles']) for m in melds)
        header = f"【手牌 {hand_count}张 + 明牌 {meld_count}组 = 共{total_count}张】\n"
        self.current_hand_display.insert(tk.END, header)
        
        if hand:
            # 使用智能整理显示
            organized_hand = MahjongHandOrganizer.organize_hand(hand)
            display_text = MahjongHandOrganizer.format_organized_display(organized_hand)
            self.current_hand_display.insert(tk.END, display_text)
        else:
            self.current_hand_display.insert(tk.END, "手牌为空")
        
        # 显示碰杠明牌组
        if melds:
            self.current_hand_display.insert(tk.END, "\n")
            self.current_hand_display.insert(tk.END, "── 碰杠明牌 ──\n")
            for i, meld in enumerate(melds, 1):
                meld_text = MahjongMeldsAnalyzer.convert_meld_to_text(meld)
                self.current_hand_display.insert(tk.END, f"  {i}. {meld_text}\n")
        
        self.current_hand_display.config(state='disabled')
    
    def _update_discard_combo(self):
        """更新出牌下拉框
        - 轮到我时：从我的手牌中读取
        - 轮到其他家时：清空（等待点击牌按钮选择）
        """
        current_turn = self.turn_manager.current_turn
        my_pos = self.turn_manager.get_my_position()
        
        if current_turn == my_pos:
            hand = self.player_hands[my_pos]
            tile_strs = [str(tile) for tile in sorted(hand, key=str)]
            self.discard_combo['values'] = tile_strs
        else:
            # 其他家回合：如果有待出的牌就显示，否则清空
            if hasattr(self, '_pending_other_discard') and self._pending_other_discard:
                self.discard_combo['values'] = [str(self._pending_other_discard)]
            else:
                self.discard_combo['values'] = []
        self.discard_var.set('')
    
    def _clear_current_hand(self):
        """清空当前手牌"""
        my_pos = self.turn_manager.get_my_position()
        self.player_hands[my_pos] = []
        
        # 记录事件
        self.event_logger.log_event('clear_hand', my_pos, details={'action': 'manual_clear'})
        
        self._update_hand_display()
        self._update_discard_combo()
    
    def _delete_tile(self):
        """删除手牌中的一张牌 - 弹出选择窗口"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        if not hand:
            messagebox.showwarning("提示", "手牌为空，没有可删除的牌")
            return
        
        popup = tk.Toplevel(self.root)
        popup.title("删除牌")
        popup.geometry("350x200")
        popup.transient(self.root)
        popup.grab_set()
        
        ttk.Label(popup, text="选择要删除的牌:", font=('Arial', 11, 'bold')).pack(pady=10)
        
        # 构建选项列表：每张牌都独立列出（重复牌分别显示）
        options = []
        sorted_hand = sorted(hand, key=str)
        for i, tile in enumerate(sorted_hand):
            options.append(f"#{i+1} {str(tile)}")
        
        delete_var = tk.StringVar()
        delete_combo = ttk.Combobox(popup, textvariable=delete_var, values=options, state="readonly", width=25)
        delete_combo.pack(pady=5)
        if options:
            delete_combo.current(0)
        
        def do_delete():
            sel = delete_var.get()
            if not sel:
                messagebox.showwarning("提示", "请选择要删除的牌", parent=popup)
                return
            try:
                # 解析选中项的索引
                idx = int(sel.split()[0].lstrip('#')) - 1
                if 0 <= idx < len(sorted_hand):
                    tile_to_remove = sorted_hand[idx]
                    hand.remove(tile_to_remove)
                    self.event_logger.log_event('remove_tile', my_pos, tile_to_remove)
                    self._update_hand_display()
                    self._update_discard_combo()
                    self._update_work_log(f"删除牌: {tile_to_remove}")
                    popup.destroy()
            except Exception as e:
                messagebox.showerror("错误", f"删除失败: {e}", parent=popup)
        
        btn_frame = ttk.Frame(popup)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="删除", command=do_delete).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="取消", command=popup.destroy).pack(side="left", padx=5)
    
    def _discard_tile(self):
        """出牌操作
        - 轮到我时：从手牌中移除选中的牌并打出
        - 轮到其他家时：将选择的牌记录为那家打出
        """
        selected_tile_str = self.discard_var.get()
        if not selected_tile_str:
            messagebox.showerror("错误", "请选择要出的牌")
            return
        
        current_turn = self.turn_manager.current_turn
        my_pos = self.turn_manager.get_my_position()
        
        if current_turn == my_pos:
            # === 我的出牌：从手牌中移除 ===
            hand = self.player_hands[my_pos]
            tile_to_discard = None
            for tile in hand:
                if str(tile) == selected_tile_str:
                    tile_to_discard = tile
                    break
            
            if not tile_to_discard:
                messagebox.showerror("错误", "找不到选中的牌")
                return
            
            # 从手牌移除
            hand.remove(tile_to_discard)
            
            # 添加到公开舍牌池
            self.public_discards[my_pos].append(tile_to_discard)
            
            # 记录事件
            self.event_logger.log_event('discard', my_pos, tile_to_discard, details={
                'action': 'manual_discard',
                'hand_count_before': len(hand) + 1,
                'hand_count_after': len(hand)
            })
            
            # 正常轮换到下一个玩家
            next_player = self.turn_manager.next_turn_normal()
            
            # 更新显示
            self._update_hand_display()
            self._update_discard_combo()
            self._update_current_position_display()
            self._update_other_players_display()
            
            # 更新工作日志
            next_pos_name = self.turn_manager.wind_names[next_player]
            self._update_work_log(f"🃏 我打出: {tile_to_discard} ➜ 轮到{next_pos_name}家")
        else:
            # === 其他家出牌：直接记录到那家的舍牌池 ===
            wind_name = self.turn_manager.wind_names[current_turn]
            
            # 解析牌
            tile_to_discard = None
            if hasattr(self, '_pending_other_discard') and str(self._pending_other_discard) == selected_tile_str:
                tile_to_discard = self._pending_other_discard
            else:
                # 尝试从字符串解析
                tile_to_discard = self._parse_tile_from_str(selected_tile_str)
            
            if not tile_to_discard:
                messagebox.showerror("错误", "无法解析选中的牌")
                return
            
            # 添加到该家的公开舍牌池
            self.public_discards[current_turn].append(tile_to_discard)
            
            # 记录事件
            self.event_logger.log_event('discard', current_turn, tile_to_discard, details={
                'action': 'other_player_discard',
                'recorded_by': 'self'
            })
            
            # 正常轮换到下一个玩家
            next_player = self.turn_manager.next_turn_normal()
            
            # 清空出牌选择框
            self._pending_other_discard = None
            self.discard_combo['values'] = []
            self.discard_var.set('')
            
            # 更新显示
            self._update_current_position_display()
            self._update_other_players_display()
            
            # 更新工作日志
            next_pos_name = self.turn_manager.wind_names[next_player]
            self._update_work_log(f"🃏 {wind_name}家打出: {tile_to_discard} ➜ 轮到{next_pos_name}家")
    
    def _parse_tile_from_str(self, tile_str):
        """从字符串解析牌对象"""
        # 尝试匹配如 "3万"、"7筒"、"2条"、"东" 等
        suit_map = {'万': 'man', '筒': 'pin', '条': 'sou'}
        honor_map = {'东': ('honor', 1), '南': ('honor', 2), '西': ('honor', 3),
                     '北': ('honor', 4), '白': ('honor', 5), '发': ('honor', 6), '中': ('honor', 7)}
        
        if tile_str in honor_map:
            suit, value = honor_map[tile_str]
            return MahjongTile(suit, value)
        
        for suffix, suit in suit_map.items():
            if tile_str.endswith(suffix):
                try:
                    value = int(tile_str[:-len(suffix)])
                    if 1 <= value <= 9:
                        return MahjongTile(suit, value)
                except ValueError:
                    pass
        
        return None
    
    def _real_time_analysis(self, position):
        """实时分析指定位置的手牌"""
        hand = self.player_hands[position]
        if not hand:
            return
            
        # 计算基本分析指标
        shanten = WinProbabilityCalculator.calculate_shanten(hand)
        win_prob = WinProbabilityCalculator.estimate_win_probability(hand)
        yaku_analysis = YakuAnalyzer.analyze_yaku(hand)
        
        # 生成分析提示
        analysis_tips = []
        
        if shanten == 0:
            analysis_tips.append("🎉 已听牌！")
        elif shanten == 1:
            analysis_tips.append("🎯 一向听")
        else:
            analysis_tips.append(f"📊 还需{shanten}张有效牌听牌")
        
        analysis_tips.append(f"和牌概率: {win_prob:.1%}")
        
        if yaku_analysis:
            analysis_tips.append(f"役种潜力: {', '.join(yaku_analysis[:3])}")  # 只显示前3个
        
        # 显示分析结果
        wind_name = self.turn_manager.wind_names[position]
        analysis_text = f"{wind_name}家手牌分析: {' | '.join(analysis_tips)}"
        
        # 添加到分析显示区
        self.analysis_text.insert('1.0', f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {analysis_text}\n")
        self.analysis_text.see('1.0')
    
    def _analyze_meld_opportunities(self, discarded_tile, source_position):
        """分析碰杠吃机会"""
        pass  # 简化版本，实际可以分析其他玩家是否可以碰杠
    
    def _handle_my_turn(self):
        """处理我的回合"""
        messagebox.showinfo("您的回合", "轮到您了！请摸牌或使用分析功能。")
    
    def _pon_action(self):
        """完整的碰牌操作"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 检查是否有对子可以碰
        tile_counts = Counter(hand)
        possible_pon_tiles = [tile for tile, count in tile_counts.items() if count >= 2]
        
        if not possible_pon_tiles:
            messagebox.showinfo("提示", "手牌中没有对子，无法碰牌")
            return
            
        # 创建选择对话框
        pon_window = tk.Toplevel(self.root)
        pon_window.title("选择碰牌")
        pon_window.geometry("400x300")
        
        ttk.Label(pon_window, text="请选择要碰的牌:", font=('Arial', 12, 'bold')).pack(pady=10)
        
        # 显示可能的碰牌选项
        for tile in possible_pon_tiles:
            btn_text = f"碰 {tile}"
            ttk.Button(
                pon_window,
                text=btn_text,
                command=lambda t=tile: self._confirm_pon(t, pon_window)
            ).pack(pady=5)
        
        ttk.Button(pon_window, text="取消", command=pon_window.destroy).pack(pady=10)
    
    def _kan_action(self):
        """杠牌操作"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        # 检查是否有刻子可以杠
        tile_counts = Counter(hand)
        possible_kan_tiles = [tile for tile, count in tile_counts.items() if count >= 3]
        
        if not possible_kan_tiles:
            messagebox.showinfo("提示", "手牌中没有刻子，无法杠牌")
            return
            
        # 类似碰牌的确认过程
        kan_window = tk.Toplevel(self.root)
        kan_window.title("选择杠牌")
        kan_window.geometry("400x300")
        
        ttk.Label(kan_window, text="请选择要杠的牌:", font=('Arial', 12, 'bold')).pack(pady=10)
        
        for tile in possible_kan_tiles:
            btn_text = f"杠 {tile}"
            ttk.Button(
                kan_window,
                text=btn_text,
                command=lambda t=tile: self._confirm_kan(t, kan_window)
            ).pack(pady=5)
        
        ttk.Button(kan_window, text="取消", command=kan_window.destroy).pack(pady=10)
    
    def _chi_action(self):
        """吃牌操作"""
        messagebox.showinfo("吃牌", "吃牌功能（只能吃上家的牌）开发中...")
    
    def _analyze_hand(self):
        """分析我的手牌 - 覆盖显示（不累积）"""
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        if not hand:
            messagebox.showerror("错误", "手牌为空，无法分析")
            return
        
        my_wind = self.turn_manager.wind_names[my_pos]
        analysis_text = f"{'='*45}\n📊 我({my_wind}家) 手牌分析\n{'='*45}\n"
        
        # 按花色分类显示手牌
        organized_hand = MahjongHandOrganizer.organize_hand(hand)
        display_text = MahjongHandOrganizer.format_organized_display(organized_hand)
        analysis_text += f"手牌({len(hand)}张):\n{display_text}\n\n"
        
        try:
            shanten = WinProbabilityCalculator.calculate_shanten(hand)
            
            if shanten == 0:
                analysis_text += "🎉 已听牌！\n"
                # 分析听什么牌
                winning_tiles = self._find_winning_tiles(hand)
                if winning_tiles:
                    analysis_text += f"听牌: {' '.join(str(t) for t in winning_tiles)}\n"
            elif shanten == 1:
                analysis_text += "🎯 一向听\n"
            else:
                analysis_text += f"向听数: {shanten}（还需{shanten}张有效牌）\n"
            
            win_prob = WinProbabilityCalculator.estimate_win_probability(hand)
            analysis_text += f"和牌概率: {win_prob:.2%}\n\n"
            
            # 役种分析
            yaku_analysis = YakuAnalyzer.analyze_yaku(hand)
            analysis_text += "── 役种分析 ──\n"
            if yaku_analysis:
                for yaku in yaku_analysis:
                    analysis_text += f"  ✅ {yaku}\n"
            else:
                analysis_text += "  ⚠️ 暂无确定役种\n"
            
            # 役种建议
            analysis_text += "\n── 做牌方向 ──\n"
            advice = self._analyze_yaku_potential(hand)
            for line in advice:
                analysis_text += f"  {line}\n"
            
        except Exception as e:
            analysis_text += f"分析出错: {e}\n"
        
        # 覆盖显示
        self.analysis_text.delete(1.0, tk.END)
        self.analysis_text.insert(tk.END, analysis_text)
        self.analysis_text.see(tk.END)
    
    def _find_winning_tiles(self, hand):
        """找出听牌时能和的牌"""
        winning_tiles = []
        all_possible = []
        for suit in ['man', 'pin', 'sou']:
            for val in range(1, 10):
                all_possible.append(MahjongTile(suit, val))
        for val in range(1, 8):
            all_possible.append(MahjongTile('honor', val))
        
        for tile in all_possible:
            test_hand = hand + [tile]
            if self._can_win(test_hand):
                winning_tiles.append(tile)
        
        return winning_tiles
    
    def _can_win(self, tiles):
        """简化判断14张牌能否和牌"""
        if len(tiles) != 14:
            return False
        tile_counts = Counter(tiles)
        # 七对子
        pairs = sum(1 for c in tile_counts.values() if c == 2)
        if pairs == 7:
            return True
        # 4面子1雀头
        for pair_tile in tile_counts:
            if tile_counts[pair_tile] >= 2:
                remaining = tiles.copy()
                remaining.remove(pair_tile)
                remaining.remove(pair_tile)
                if self._can_form_melds(remaining):
                    return True
        return False
    
    def _can_form_melds(self, tiles):
        """判断12张牌能否组成4个面子"""
        if len(tiles) != 12:
            return False
        sorted_tiles = sorted(tiles, key=lambda t: (t.suit, t.value))
        return self._try_form_melds(sorted_tiles, 4)
    
    def _try_form_melds(self, tiles, melds_needed):
        """递归尝试组成面子"""
        if melds_needed == 0:
            return len(tiles) == 0
        if len(tiles) < 3:
            return False
        first = tiles[0]
        # 尝试刻子
        if tiles.count(first) >= 3:
            new_tiles = tiles.copy()
            new_tiles.remove(first)
            new_tiles.remove(first)
            new_tiles.remove(first)
            if self._try_form_melds(new_tiles, melds_needed - 1):
                return True
        # 尝试顺子（数牌）
        if first.suit != 'honor':
            t2 = MahjongTile(first.suit, first.value + 1)
            t3 = MahjongTile(first.suit, first.value + 2)
            if first.value <= 7 and t2 in tiles and t3 in tiles:
                new_tiles = tiles.copy()
                new_tiles.remove(first)
                new_tiles.remove(t2)
                new_tiles.remove(t3)
                if self._try_form_melds(new_tiles, melds_needed - 1):
                    return True
        return False
    
    def _analyze_yaku_potential(self, hand):
        """分析手牌的役种潜力，给出建议"""
        advice = []
        tile_counts = Counter(hand)
        
        # 断幺九潜力
        yaochu_count = sum(c for t, c in tile_counts.items() if t.is_yaochu())
        if yaochu_count == 0:
            advice.append("✅ 断幺九：手牌无幺九牌，可做断幺九")
        elif yaochu_count <= 2:
            advice.append(f"💡 断幺九潜力：仅有{yaochu_count}张幺九牌，出掉即可")
        
        # 清一色/混一色潜力
        suits_present = set(t.suit for t in hand if t.suit != 'honor')
        honor_count = sum(c for t, c in tile_counts.items() if t.suit == 'honor')
        if len(suits_present) == 1:
            if honor_count == 0:
                advice.append("✅ 清一色潜力：手牌全部同一花色")
            else:
                advice.append("💡 混一色潜力：单一花色+字牌")
        elif len(suits_present) == 2 and honor_count > 0:
            advice.append("💡 混一色可能：考虑集中到一种花色+字牌")
        
        # 对子数（七对子/对对和潜力）
        pairs = sum(1 for c in tile_counts.values() if c == 2)
        triplets = sum(1 for c in tile_counts.values() if c >= 3)
        if pairs >= 4:
            advice.append(f"💡 七对子潜力：已有{pairs}个对子")
        if triplets >= 2:
            advice.append(f"💡 对对和潜力：已有{triplets}组刻子")
        
        # 役牌
        for val in [5, 6, 7]:
            dragon = MahjongTile('honor', val)
            if tile_counts.get(dragon, 0) >= 2:
                advice.append(f"💡 役牌潜力：{dragon}有{tile_counts[dragon]}张")
        
        # 三色同顺潜力
        for val in range(1, 8):
            found_suits = []
            for suit in ['man', 'pin', 'sou']:
                has_seq = all(MahjongTile(suit, val + i) in tile_counts for i in range(3))
                if has_seq:
                    found_suits.append(suit)
            if len(found_suits) >= 2:
                advice.append(f"💡 三色同顺潜力：{val}-{val+1}-{val+2}已有{len(found_suits)}色")
                break
        
        if not advice:
            advice.append("📌 优先做立直/断幺九，保证有役")
        
        return advice
    
    def _smart_discard_analysis(self):
        """智能出牌建议 - 基于何切实战理论深度优化算法，只推荐2-3张牌，覆盖显示
        
        核心评估维度（基于何切.txt实战教学体系）：
        1. 向听数变化（权重最高）：出后不能增加向听
        2. 进张数变化（最关键指标）：出后有效进张枚数
        3. 浮牌价值排序：19>28>37>456的切牌优先级
        4. 愚型/良型搭子识别：拆愚型优先于良型
        5. 五组理论：6组搭子时拆愚型降至5组
        6. 对子结构评估：2对>1对>3对的价值判断
        7. 改良进张评估：出牌后摸牌改良牌型的潜力
        8. 役种潜力影响：断幺九/一杯口/三色/混一色等
        9. 安全度评估：基于舍牌池现物数量判断放铳风险
        10. 字牌进攻/防守排序：客风>场风>自风>发>中>白
        """
        my_pos = self.turn_manager.get_my_position()
        hand = self.player_hands[my_pos]
        
        if not hand or len(hand) < 2:
            messagebox.showinfo("提示", "手牌太少，无法分析出牌建议")
            return
        
        my_wind = self.turn_manager.wind_names[my_pos]
        tile_counts = Counter(hand)
        
        # 计算当前向听数
        base_shanten = WinProbabilityCalculator.calculate_shanten(hand)
        
        # 汇总场上已知的牌消耗（舍牌池+别家碰杠明牌）
        known_used = self._get_known_used_counter(my_pos)
        
        # 当前手牌进张数（基准，扣除已知消耗）
        base_ukeire = self._count_ukeire(hand, known_used)
        
        # 汇总全场舍牌池（用于安全度评估）
        all_discarded = []
        for pos in self.public_discards:
            all_discarded.extend(self.public_discards[pos])
        discarded_counter = Counter(all_discarded)
        
        # 对每张唯一牌进行综合评分
        results = []
        for tile in tile_counts:
            count = tile_counts[tile]
            sim_hand = hand.copy()
            sim_hand.remove(tile)
            
            # === 核心评估 ===
            
            # 1. 出牌后向听数变化
            new_shanten = WinProbabilityCalculator.calculate_shanten(sim_hand)
            shanten_change = new_shanten - base_shanten
            
            # 2. 出牌后进张数（最关键指标，扣除已知消耗）
            new_ukeire = self._count_ukeire(sim_hand, known_used)
            ukeire_change = new_ukeire - base_ukeire  # 负数=进张减少
            
            # 3. 愚型搭子评分（越高越该出）
            kana_score = self._evaluate_kana_value(tile, hand, tile_counts)
            
            # 4. 改良进张评分（越高越不该出）
            improvement = self._evaluate_improvement_potential(tile, hand, tile_counts)
            
            # 5. 役种影响评分（越高越不该出）
            yaku_impact = self._evaluate_yaku_impact(tile, hand, tile_counts, count)
            
            # 6. 牌型价值评分（越高越不该出）
            type_value = self._evaluate_tile_type_value(tile, count, hand, tile_counts)
            
            # 7. 浮牌价值评分（越高越该出，19最高→456最低）
            float_value = self._evaluate_float_value(tile, hand, tile_counts)
            
            # 8. 安全度评分（越高越该出，现物多=安全）
            safety_score = self._evaluate_safety(tile, discarded_counter)
            
            # 9. 对子结构评分（越高越不该出，2对最优）
            pair_struct = self._evaluate_pair_structure(tile, hand, tile_counts)
            
            # 10. 五组理论评分（越高越该出，6组时拆愚型）
            five_block = self._evaluate_five_block(tile, hand, tile_counts)
            
            # 11. 复合型手牌结构评分（越高越不该出，保护长连/亚两面）
            compound = self._evaluate_compound_structure(tile, hand, tile_counts)
            
            # 12. 宝牌价值评分（宝牌不该出，越高越不该出）
            dora_tiles = self._get_current_dora_tiles()
            dora_value = 0
            if tile in dora_tiles:
                # 宝牌保护策略：
                # 1. 手中2张以上宝牌：打1张后仍留dora，保护大幅降低（对子中多余的宝牌）
                #    且如果拆掉后该花色段仍能形成顺子（如7889p拆8p→789p顺子），保护进一步降低
                # 2. 手中1张宝牌：正常保护，但考虑靠张能力
                if count >= 2:
                    # 检查拆掉1张宝牌后，该花色段是否仍能形成完整顺子
                    # 如7889p中8p是对子，拆掉1张8p后剩789p（完整顺子）
                    still_forms_shuntsu = self._dora_redundant_in_pair(tile, hand, tile_counts)
                    if still_forms_shuntsu:
                        # 宝牌对子中多余的牌，拆掉后结构不变 → 保护极低
                        dora_value = 0.5
                    else:
                        # 宝牌对子但拆掉后结构受损 → 中等保护
                        dora_value = 2.0
                else:
                    # 手中1张宝牌 → 正常保护，考虑靠张能力
                    kana_weakness = self._evaluate_dora_kana_weakness(tile, hand, tile_counts, known_used)
                    dora_value = 3.0 * kana_weakness
            
            # 13. dora路线价值评分（该牌在等待dora的坎张中→不该出）
            # 如2-4坎等3m(dora)，拆2m会损失dora路线
            # 仅当同段中有对子可拆出造相离两坎时才保护
            dora_route = 0
            if tile.suit != 'honor' and dora_tiles:
                val = tile.value
                suit = tile.suit
                for dora in dora_tiles:
                    if dora.suit != suit:
                        continue
                    dora_val = dora.value
                    # 检查该牌是否在等dora的坎张对中
                    # 如2-4坎等3m，2m和4m是坎张端，3m(dora)是中间
                    # 即abs(val - dora_val) == 1，且存在val±2的牌形成坎张
                    if abs(val - dora_val) == 1:
                        # 检查val±2方向是否有牌形成坎张
                        partner_val = val + 2 if val < dora_val else val - 2
                        if 1 <= partner_val <= 9:
                            partner_tile = MahjongTile(suit, partner_val)
                            if partner_tile in tile_counts:
                                # 仅当同连续段中有对子可拆出造相离两坎时才保护
                                # 避免过度保护普通dora坎张
                                # 检查同花色中与该牌在同一段(间隔<=2连接)的对子
                                has_pair_in_seg = False
                                suit_vals_all = []
                                for t_all, c_all in tile_counts.items():
                                    if t_all.suit == suit:
                                        suit_vals_all.extend([t_all.value] * c_all)
                                suit_vals_all.sort()
                                # 找到包含val的连续段
                                val_seg = [val]
                                if suit_vals_all:
                                    # 向左扩展
                                    for v in reversed(suit_vals_all):
                                        if v < val and val_seg[0] - v <= 2:
                                            val_seg.insert(0, v)
                                        elif v < val:
                                            break
                                    # 向右扩展
                                    for v in suit_vals_all:
                                        if v > val and v - val_seg[-1] <= 2:
                                            val_seg.append(v)
                                        elif v > val:
                                            break
                                # 检查段中是否有对子
                                for t2, c2 in tile_counts.items():
                                    if t2.suit == suit and c2 == 2:
                                        if t2.value in val_seg:
                                            has_pair_in_seg = True
                                            break
                                if has_pair_in_seg:
                                    dora_route = 6  # 该牌在等dora的坎张中，且可拆对子造相离两坎，保护
            
            # === 综合评分（越低越建议出）===
            # 听牌且进张=0时（向听数计算无法区分），compound为决定性维度，
            # 同时改良潜力转为负权重（出掉改良潜力高的牌后剩余结构仍优）
            is_tenpai_stuck = (base_shanten == 0 and base_ukeire == 0)
            
            if is_tenpai_stuck:
                w_kana = 0.5
                w_imp = -0.5
                w_yaku = 1.0
                w_type = 0.5
                w_compound = 6.0
            else:
                w_kana = 2.0
                w_imp = 2.0
                w_yaku = 2.5
                w_type = 1.5
                w_compound = 2.0
            
            total_score = (
                shanten_change * 50 +          # 向听变化：权重最高，出后增加向听直接排除
                ukeire_change * 3.0 +          # 进张数变化：每减少1张+3分
                -kana_score * w_kana +          # 愚型搭子：越高越该出（减分）
                improvement * w_imp +           # 改良潜力：听牌时反向（出掉改良潜力高的牌）
                yaku_impact * w_yaku +          # 役种影响：越高越不该出
                type_value * w_type +          # 牌型价值：辅助参考
                -float_value * 2.5 +           # 浮牌价值：19该出（减分），456不该出
                -safety_score * 1.8 +          # 安全度：现物多该出（减分）
                pair_struct * 1.5 +            # 对子结构：2对最优不该出
                -five_block * 1.5 +            # 五组理论：该拆时减分
                compound * w_compound +        # 复合型结构：保护长连/亚两面
                dora_value * 3.0 +             # 宝牌价值：dora不该出
                dora_route * 3.0               # dora路线价值：等dora的坎张不该出
            )
            
            # 生成详细理由
            reasons = self._generate_discard_reasons_v2(
                tile, count, shanten_change, ukeire_change, base_ukeire, new_ukeire,
                kana_score, improvement, yaku_impact, type_value, hand, tile_counts,
                float_value, safety_score, pair_struct, five_block, discarded_counter,
                compound
            )
            
            results.append({
                'tile': tile,
                'count': count,
                'shanten_change': shanten_change,
                'ukeire_change': ukeire_change,
                'base_ukeire': base_ukeire,
                'new_ukeire': new_ukeire,
                'kana_score': kana_score,
                'improvement': improvement,
                'yaku_impact': yaku_impact,
                'type_value': type_value,
                'float_value': float_value,
                'safety_score': safety_score,
                'pair_struct': pair_struct,
                'five_block': five_block,
                'total_score': total_score,
                'reasons': reasons
            })
        
        # 按综合评分排序（分数最低=最建议出）
        results.sort(key=lambda x: x['total_score'])
        
        # 只取前2名作为推荐（最建议+第二建议）
        top_recommend = results[:2]
        
        # 生成分析报告
        analysis_text = f"{'='*45}\n🧠 我({my_wind}家) 智能出牌建议\n{'='*45}\n"
        
        # 手牌分类显示
        organized_hand = MahjongHandOrganizer.organize_hand(hand)
        display_text = MahjongHandOrganizer.format_organized_display(organized_hand)
        analysis_text += f"手牌({len(hand)}张):\n{display_text}\n\n"
        
        # 宝牌显示
        dora_tiles = self._get_current_dora_tiles()
        if dora_tiles:
            dora_str = ' '.join(str(t) for t in dora_tiles)
            dora_in_hand = sum(1 for t in hand if t in dora_tiles)
            analysis_text += f"宝牌: {dora_str}  (手中{dora_in_hand}张)\n"
        
        # 向听数和进张数
        shanten_text = {0: "听牌", 1: "一向听", 2: "两向听", 3: "三向听"}.get(base_shanten, f"{base_shanten}向听")
        analysis_text += f"向听数: {shanten_text}  当前进张数: {base_ukeire}张\n"
        
        # 手牌结构摘要
        pairs = sum(1 for c in tile_counts.values() if c == 2)
        triplets = sum(1 for c in tile_counts.values() if c >= 3)
        analysis_text += f"对子: {pairs}组  刻子: {triplets}组  "
        
        # 搭子组数
        block_count = self._count_blocks(hand, tile_counts)
        analysis_text += f"搭子组数: {block_count}组"
        if block_count >= 6:
            analysis_text += " (超过5组，建议拆搭降至5组)"
        analysis_text += "\n\n"
        
        analysis_text += "── 推荐出牌（Top 2）──\n\n"
        
        medals = ["🥇", "🥈"]
        for i, r in enumerate(top_recommend):
            medal = medals[i] if i < 2 else ""
            tile_str = str(r['tile'])
            
            # 进张变化摘要
            ukeire_str = f"进张{r['new_ukeire']}张"
            if r['ukeire_change'] != 0:
                ukeire_str += f"({r['ukeire_change']:+d})"
            
            # 安全度标记
            safety_tag = ""
            if r['safety_score'] >= 7:
                safety_tag = " [安全]"
            elif r['safety_score'] <= 2 and r['shanten_change'] == 0:
                safety_tag = " [注意安全度]"
            
            analysis_text += f"{medal} 出 {tile_str}（手中{r['count']}张）[{ukeire_str}]{safety_tag}\n"
            for reason in r['reasons']:
                analysis_text += f"   {reason}\n"
            analysis_text += "\n"
        
        # 役种分析
        analysis_text += "── 役种分析 ──\n"
        yaku_analysis = YakuAnalyzer.analyze_yaku(hand)
        if yaku_analysis:
            for yaku in yaku_analysis:
                analysis_text += f"  ✅ {yaku}\n"
        else:
            analysis_text += "  ⚠️ 无确定役种，注意保证有役\n"
        
        # 做牌方向
        advice = self._analyze_yaku_potential(hand)
        if advice:
            analysis_text += "\n── 做牌方向 ──\n"
            for line in advice:
                analysis_text += f"  {line}\n"
        
        # 场况提示
        analysis_text += "\n── 场况提示 ──\n"
        total_discards = sum(len(v) for v in self.public_discards.values())
        if total_discards < 12:
            analysis_text += f"  序盘({total_discards}巡): 优先处理孤立浮牌，建立做牌方向\n"
        elif total_discards < 30:
            analysis_text += f"  中盘({total_discards}巡): 关注攻防转换，注意保留安全牌\n"
        else:
            analysis_text += f"  终盘({total_discards}巡): 防守优先，避免打生张放铳\n"
        
        # 覆盖显示
        self.analysis_text.delete(1.0, tk.END)
        self.analysis_text.insert(tk.END, analysis_text)
        self.analysis_text.see(tk.END)
        
        self._update_work_log(f"🧠 智能分析完成 - 推荐: {top_recommend[0]['tile']}")
    
    def _evaluate_float_value(self, tile, hand, tile_counts):
        """评估浮牌价值（0-10分，越高越该出）
        
        基于何切理论：浮牌切牌顺序 19>28>37>456
        - 1、9端牌：只能摸1种牌成搭，价值最低→优先切（评分9）
        - 2、8边张：可摸2种牌成搭，价值低→其次切（评分7）
        - 3、7中张：可摸4种牌成搭，改良能力强→较晚切（评分4）
        - 4、5、6中心：可摸5种牌成搭，价值最高→最后切（评分2）
        
        例外：dora宝牌浮牌优待（评分降低2分）
        """
        if tile.suit == 'honor':
            # 字牌浮牌由 _evaluate_tile_type_value 处理
            count = tile_counts.get(tile, 0)
            if count == 1:
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                if honor_name in [player_wind, round_wind]:
                    return 3  # 场风/自风，有役价值
                elif tile.value in [5, 6, 7]:
                    return 2  # 三元牌，有役价值
                else:
                    return 8  # 客风，最先处理
            return 0  # 对子/刻子不按浮牌处理
        
        val = tile.value
        count = tile_counts.get(tile, 0)
        
        if count >= 2:
            return 0  # 对子/刻子不按浮牌处理
        
        # 检查是否是真正的浮牌（孤立无连接）
        suit = tile.suit
        has_p1 = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
        has_n1 = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
        has_p2 = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
        has_n2 = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
        
        if has_p1 or has_n1 or has_p2 or has_n2:
            return 0  # 有连接，不是浮牌
        
        # 真正的孤立浮牌
        if val in [1, 9]:
            score = 9  # 端牌：只能摸1种牌成搭
        elif val in [2, 8]:
            score = 7  # 边张：可摸2种牌成搭
        elif val in [3, 7]:
            score = 4  # 中张：可摸4种牌成搭
        else:  # 4,5,6
            score = 2  # 中心：可摸5种牌成搭，价值最高
        
        # 例外：5数牌有赤宝牌价值
        if val == 5:
            score = max(0, score - 2)
        
        return score
    
    def _evaluate_safety(self, tile, discarded_counter):
        """评估牌的安全度（0-10分，越高越安全该出）
        
        基于何切理论防守排序：
        - 已出3张的字牌：最安全（评分10）
        - 已出2张的字牌：较安全（评分7）
        - 已出1张的字牌：一般安全（评分5）
        - 生张字牌：危险（评分1）
        - 数牌根据已出张数递减安全度
        
        放铳风险排序：字牌<19<28<37≈456
        """
        discarded_count = discarded_counter.get(tile, 0)
        remaining = 4 - discarded_count - 1  # 减去手中这张
        
        if tile.suit == 'honor':
            # 字牌放铳形式最少（双碰、单骑），相对安全
            if discarded_count >= 3:
                return 10  # 几乎不可能点炮
            elif discarded_count == 2:
                return 7
            elif discarded_count == 1:
                return 5
            else:
                # 生张字牌
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                # 生张的自风/场风/三元牌更危险（对手容易做双碰）
                if honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]:
                    return 0  # 高风险
                return 1  # 生张客风稍安全但也危险
        else:
            # 数牌放铳风险更高
            val = tile.value
            if discarded_count >= 3:
                return 8
            elif discarded_count == 2:
                return 5
            elif discarded_count == 1:
                return 3
            else:
                # 生张数牌
                if val in [1, 9]:
                    return 3  # 19放铳形式3种
                elif val in [2, 8]:
                    return 2  # 28放铳形式4种
                else:
                    return 1  # 3-7放铳形式5种，最危险
    
    def _evaluate_pair_structure(self, tile, hand, tile_counts):
        """评估对子结构价值（0-10分，越高越不该出）
        
        基于何切理论对子价值排序：2对>1对>3对
        - 2个对子：碰一个做刻子，剩一个做雀头，最优（评分高）
        - 1个对子：碰了雀头消失，效率低（评分中）
        - 3个对子：进张数少2张，效率最低（评分低→更该拆）
        
        例外：3对含役牌对子时优先保留
        """
        count = tile_counts.get(tile, 0)
        if count != 2:
            return 0  # 不是对子，不评估
        
        # 统计总对子数
        total_pairs = sum(1 for c in tile_counts.values() if c == 2)
        
        if total_pairs == 2:
            # 2个对子最优
            if tile.suit == 'honor':
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                if honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]:
                    return 9  # 役牌对子+2对结构，极不该出
            
            # 相离两坎含dora瞄准：拆对子造两坎+dora路线，降低保护
            has_sep_kana, has_dora_target = self._detect_separated_kana_pattern(tile, hand, tile_counts)
            if has_sep_kana and has_dora_target:
                return 2  # 拆对子造相离两坎含dora瞄准，该拆
            if has_sep_kana:
                return 4  # 相离两坎（无dora瞄准），可拆

            # 冗余对子检测：拆掉1张后该花色段仍含完整顺子（如3455s拆5s→345完整）
            # 这种对子是"多余的"，拆掉释放雀头给其他段，保护应降低
            if tile.suit != 'honor':
                is_redundant = self._dora_redundant_in_pair(tile, hand, tile_counts)
                if is_redundant:
                    return 3  # 冗余对子在2对结构中，可拆

            return 7  # 普通对子在2对结构中
        
        elif total_pairs == 1:
            # 只有1个对子，是唯一雀头候补
            return 6
        
        elif total_pairs >= 3:
            # 3个对子以上，效率降低
            # 检查是否含役牌对子
            has_yakuhai_pair = False
            for t, c in tile_counts.items():
                if c == 2 and t.suit == 'honor':
                    honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[t.value]
                    player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                    round_wind = self.round_wind_var.get()
                    if honor_name in [player_wind, round_wind] or t.value in [5, 6, 7]:
                        has_yakuhai_pair = True
                        break
            
            if has_yakuhai_pair:
                # 含役牌对子的3对结构，保留役牌对子
                if tile.suit == 'honor':
                    honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                    player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                    round_wind = self.round_wind_var.get()
                    if honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]:
                        return 8  # 役牌对子不该出
                # 普通对子在3对含役牌结构中
                # 三雀头最弱理论：搭子溢出时拆普通对子进张多2枚，降低保护
                block_count = self._count_blocks(hand, tile_counts)
                if block_count >= 6:
                    return 1  # 搭子溢出时，普通对子该拆（三雀头最弱）
                return 3  # 正常情况保留
            else:
                # 纯3对无役牌，拆一个
                # 最弱三雀头理论：搭子溢出时拆普通对子进张多2枚，降低保护
                block_count = self._count_blocks(hand, tile_counts)
                if block_count >= 6:
                    return 1  # 搭子溢出时，普通对子该拆（最弱三雀头）
                return 2  # 正常情况，更该出
        
        return 0
    
    def _dora_redundant_in_pair(self, tile, hand, tile_counts):
        """检查宝牌对子是否是"冗余的"——拆掉一张后该花色段仍能形成完整顺子
        
        如7889p中8p是对子(宝牌)，拆掉1张8p后剩789p（完整顺子）→ 返回True
        如4468s中4p是对子(宝牌)，拆掉1张4p后剩468s（不是顺子）→ 返回False
        """
        if tile.suit == 'honor':
            return False
        
        val = tile.value
        suit = tile.suit
        
        if tile_counts.get(tile, 0) < 2:
            return False  # 不是对子
        
        # 模拟拆掉1张该宝牌后，检查该花色段是否含完整顺子
        sim_counts = Counter(tile_counts)
        sim_counts[tile] -= 1
        if sim_counts[tile] == 0:
            del sim_counts[tile]
        
        # 获取该花色的所有值
        suit_vals = []
        for t, c in sim_counts.items():
            if t.suit == suit:
                suit_vals.extend([t.value] * c)
        suit_vals.sort()
        
        # 检查是否存在包含val的完整顺子（val-1, val, val+1 或 val, val+1, val+2 或 val-2, val-1, val）
        # 拆掉1张后val仍在手牌中（因为原来有2张）
        # 检查val能否与相邻牌组成顺子
        has_val = val in suit_vals
        
        if has_val:
            # 检查val-1, val, val+1
            v1 = MahjongTile(suit, val - 1) if val > 1 else None
            v2 = tile
            v3 = MahjongTile(suit, val + 1) if val < 9 else None
            if v1 and v3 and sim_counts.get(v1, 0) >= 1 and sim_counts.get(v2, 0) >= 1 and sim_counts.get(v3, 0) >= 1:
                return True
            # 检查val-2, val-1, val（如3455s拆5s后345完整）
            v_prev2 = MahjongTile(suit, val - 2) if val > 2 else None
            v_prev1 = MahjongTile(suit, val - 1) if val > 1 else None
            if v_prev2 and v_prev1 and sim_counts.get(v_prev2, 0) >= 1 and sim_counts.get(v_prev1, 0) >= 1 and sim_counts.get(v2, 0) >= 1:
                return True
            # 检查val, val+1, val+2（如3445s拆4s后456完整...不对应该是4556拆5后456）
            v_next1 = MahjongTile(suit, val + 1) if val < 9 else None
            v_next2 = MahjongTile(suit, val + 2) if val < 8 else None
            if v_next1 and v_next2 and sim_counts.get(v2, 0) >= 1 and sim_counts.get(v_next1, 0) >= 1 and sim_counts.get(v_next2, 0) >= 1:
                return True
        
        return False
    
    def _evaluate_dora_kana_weakness(self, tile, hand, tile_counts, known_used=None):
        """评估宝牌所在位置的靠张能力（返回0.3-1.0，越低表示靠张越弱→保护应降低）
        
        宝牌如果靠张牌很少（如8p只有7p和9p做靠张，且7p剩余少），则宝牌价值被稀释，
        保护权重应降低。这是"不贪dora"逻辑的量化体现。
        
        判定逻辑：
        1. 统计宝牌±1、±2的牌在手中和牌山中的剩余量
        2. 剩余量越少→靠张越弱→返回值越低
        3. dora指示牌本身也消耗牌山中的牌（指示牌翻开=该牌被消耗1张）
        """
        if tile.suit == 'honor':
            return 1.0  # 字牌宝牌不适用此逻辑
        
        val = tile.value
        suit = tile.suit
        
        # dora指示牌列表（它们在牌桌上翻开=消耗了1张）
        dora_indicators = self.current_dora_indicators
        
        # 统计靠张牌的剩余总量（手中+牌山中可摸的）
        kana_total = 0
        kana_slots = 0  # 有多少个靠张位
        
        for offset in [-2, -1, 1, 2]:
            neighbor_val = val + offset
            if neighbor_val < 1 or neighbor_val > 9:
                continue
            neighbor_tile = MahjongTile(suit, neighbor_val)
            
            # 手中有几张
            hand_count = tile_counts.get(neighbor_tile, 0)
            # 场上已消耗（舍牌池+碰杠）
            used_count = known_used.get(neighbor_tile, 0) if known_used else 0
            # dora指示牌消耗（指示牌本身翻开=消耗1张）
            indicator_count = sum(1 for ind in dora_indicators if ind == neighbor_tile)
            used_count += indicator_count
            # 剩余可摸
            remaining = max(0, 4 - hand_count - used_count)
            
            kana_total += remaining + hand_count * 0.5  # 手中的靠张价值略低（已在手上）
            kana_slots += 1
        
        if kana_slots == 0:
            return 1.0
        
        # 平均每个靠张位的可用牌量
        avg_kana = kana_total / kana_slots
        
        # 靠张能力评级：
        # avg_kana >= 3.0 → 靠张强 → 1.0（全额保护）
        # avg_kana >= 2.0 → 靠张中 → 0.8
        # avg_kana >= 1.0 → 靠张弱 → 0.5（宝牌价值被稀释）
        # avg_kana < 1.0 → 靠张极弱 → 0.3（不值得保留宝牌）
        if avg_kana >= 3.0:
            return 1.0
        elif avg_kana >= 2.0:
            return 0.8
        elif avg_kana >= 1.0:
            return 0.5
        else:
            return 0.3
    
    def _is_kana_isolated_end(self, val, seg):
        """检查一张牌是否是长连中的"坎张孤张端"
        
        坎张孤张端 = 该牌只通过坎张(间隔2)连接到段主体，且拆掉后段主体仍保持完整结构。
        如3566788p中3p只通过坎张35p连接，拆掉3p后剩566788p(567顺+68坎+8对)结构不变。
        
        判定条件：
        1. 该牌是段的端点(最小值或最大值)
        2. 该牌与相邻牌的间隔为2(坎张)，不是1(两面)
        3. 拆掉该牌后，段的其余部分不含孤立端(其余部分两端都是间隔1的连接)
        """
        seg_vals = sorted(set(seg))
        if val not in seg_vals:
            return False
        
        # 必须是段的端点
        if val != seg_vals[0] and val != seg_vals[-1]:
            return False
        
        # 检查与相邻牌的间隔
        if val == seg_vals[0]:
            # 左端点：检查与第二个值的间隔
            next_val = seg_vals[1]
            if next_val - val != 2:
                return False  # 间隔不是坎张(不是2)
            # 检查拆掉val后，第二个值是否变成新的孤张端
            # 即第二个值与第三个值的间隔是否也是2
            if len(seg_vals) >= 3:
                third_val = seg_vals[2]
                if third_val - next_val == 2:
                    return False  # 第二个值也会变成孤张端，不安全
            return True
        
        else:  # val == seg_vals[-1]
            # 右端点：检查与倒数第二个值的间隔
            prev_val = seg_vals[-2]
            if val - prev_val != 2:
                return False
            if len(seg_vals) >= 3:
                third_from_end = seg_vals[-3]
                if prev_val - third_from_end == 2:
                    return False
            return True
    
    def _count_kana_in_seg(self, seg):
        """统计段中坎张(间隔2)的数量
        
        如3566788p中: 3-5间隔2(坎张), 6-8间隔2(坎张)
        统计所有间隔为2的牌对（无论中间牌是否在段中）
        因为即使中间牌存在，该搭子仍代表一种愚型结构可能
        """
        seg_vals = sorted(set(seg))
        if len(seg_vals) < 2:
            return 0
        
        kana_count = 0
        for i in range(len(seg_vals)):
            for j in range(i+1, len(seg_vals)):
                if seg_vals[j] - seg_vals[i] == 2:
                    kana_count += 1
        return kana_count
    
    def _detect_separated_kana_pattern(self, tile, hand, tile_counts):
        """检测"相离两坎含dora瞄准"模式
        
        如2-4567-99m中拆9m→2-4坎(等3m=dora)+7-9坎(等8m)
        两个独立坎张，其中一坎瞄准dora，是正解级拆法。
        拆对子造相离两坎既瞄准dora又保留平和路线。
        
        返回: (has_pattern, has_dora_target)
        """
        count = tile_counts.get(tile, 0)
        if count != 2:
            return (False, False)
        
        val = tile.value
        suit = tile.suit
        if suit == 'honor':
            return (False, False)
        
        # 模拟拆掉1张对子后该花色的牌值
        sim_counts = dict(tile_counts)
        sim_counts[tile] = 1
        
        suit_vals = []
        for t, c in sim_counts.items():
            if t.suit == suit:
                suit_vals.extend([t.value] * c)
        suit_vals.sort()
        
        if len(suit_vals) < 4:
            return (False, False)
        
        # 将同花色分成连续段（间隔<=2算同段）
        segments = []
        if suit_vals:
            current_seg = [suit_vals[0]]
            for i in range(1, len(suit_vals)):
                if suit_vals[i] - suit_vals[i-1] <= 2:
                    current_seg.append(suit_vals[i])
                else:
                    segments.append(current_seg)
                    current_seg = [suit_vals[i]]
            segments.append(current_seg)
        
        # 找到包含val的段
        target_seg = None
        for seg in segments:
            if val in seg:
                target_seg = seg
                break
        
        if not target_seg:
            return (False, False)
        
        seg_vals = sorted(set(target_seg))
        if len(seg_vals) < 4:
            return (False, False)
        
        # 统计坎张对（间隔2的牌对）
        kana_pairs = []
        for i in range(len(seg_vals)):
            for j in range(i+1, len(seg_vals)):
                if seg_vals[j] - seg_vals[i] == 2:
                    kana_pairs.append((seg_vals[i], seg_vals[j]))
        
        if len(kana_pairs) < 2:
            return (False, False)
        
        # 检查是否有至少一个坎张瞄准dora
        dora_tiles = self._get_current_dora_tiles()
        has_dora_target = False
        if dora_tiles:
            for kana_low, kana_high in kana_pairs:
                wait_val = (kana_low + kana_high) // 2
                for dora in dora_tiles:
                    if dora.suit == suit and dora.value == wait_val:
                        has_dora_target = True
                        break
                if has_dora_target:
                    break
        
        return (True, has_dora_target)
    
    def _has_deformity_block(self, tile_counts):
        """检查手牌中是否存在"四枚畸形块"（对子+坎张/搭子挤在一起的结构）
        
        如4468(44对+68坎张)、446899(44+68+99)等
        这种结构需要优先改造，存在时不应拆外部独立搭子
        """
        for suit in ['man', 'pin', 'sou']:
            suit_vals = []
            for t, c in tile_counts.items():
                if t.suit == suit:
                    suit_vals.extend([t.value] * c)
            suit_vals.sort()
            
            if len(suit_vals) < 4:
                continue
            
            # 分段
            segments = []
            if suit_vals:
                current_seg = [suit_vals[0]]
                for i in range(1, len(suit_vals)):
                    if suit_vals[i] - suit_vals[i-1] <= 2:
                        current_seg.append(suit_vals[i])
                    else:
                        segments.append(current_seg)
                        current_seg = [suit_vals[i]]
                segments.append(current_seg)
            
            for seg in segments:
                if len(seg) < 4:
                    continue
                seg_vals = sorted(set(seg))
                dup_vals = [v for v in set(seg) if seg.count(v) >= 2]
                has_dup = len(dup_vals) > 0
                unique_count = len(seg_vals)
                
                # 四枚畸形块：含对子+非对子牌之间有间隔(坎张)
                if has_dup and len(dup_vals) >= 1:
                    non_dup_vals = [v for v in seg_vals if v not in dup_vals]
                    if len(non_dup_vals) >= 2:
                        non_dup_range = max(non_dup_vals) - min(non_dup_vals)
                        if non_dup_range >= 2:
                            return True
        return False
    
    def _evaluate_compound_structure(self, tile, hand, tile_counts):
        """评估牌在复合型手牌结构中的价值（0-15分，越高越不该出）
        
        复合型手牌 = 由连续牌组成的复杂形状，拆牌时应优先拆亚两面而非长连：
        - 长连/六连（如345678=345+678）：天然多面听，不应破坏，价值极高
        - 亚两面含对子（如3445=34+45含对子4）：拆端点保留对子+搭子，最佳拆法
        - 纯4连亚两面（如4567=45+67两个重叠两面）：拆端点可接受
        - 完整顺子（如345）：不该拆
        
        核心原则：遇到复合型手牌，不要急着破坏长连；迷茫时拆掉亚两面大多最优解
        """
        if tile.suit == 'honor':
            return 0
        
        val = tile.value
        suit = tile.suit
        count = tile_counts.get(tile, 0)
        
        # 获取该花色所有牌的值（展开重复牌）
        suit_vals = []
        for t, c in tile_counts.items():
            if t.suit == suit:
                suit_vals.extend([t.value] * c)
        suit_vals.sort()
        
        # 将同花色牌分成连续段（间隔<=2的算同段）
        segments = []
        if suit_vals:
            current_seg = [suit_vals[0]]
            for i in range(1, len(suit_vals)):
                if suit_vals[i] - suit_vals[i-1] <= 2:
                    current_seg.append(suit_vals[i])
                else:
                    segments.append(current_seg)
                    current_seg = [suit_vals[i]]
            segments.append(current_seg)
        
        # 暗刻/三枚复合评估：count>=3时评估暗刻所在段的复合价值
        # 如6777p是极强三枚复合（摸5p=dora、改良多、雀头源），不该拆
        # 如777p孤立暗刻则价值较低
        if count >= 3:
            for seg in segments:
                if val not in seg:
                    continue
                seg_vals_set = sorted(set(seg))
                # 检查暗刻是否有邻接牌（形成复合体）
                has_neighbor = any(
                    abs(v - val) <= 2 and v != val
                    for v in seg_vals_set
                )
                if has_neighbor:
                    # 暗刻+邻接牌 = 强力三枚复合（如6777p, 7778p等）
                    # 这是手牌中最强的部分之一，提供大量改良+dora进张+雀头
                    return 10
                else:
                    # 孤立暗刻，无邻接
                    return 2
            return 2
        
        score = 0
        
        for seg in segments:
            if val not in seg:
                continue
            
            seg_len = len(seg)
            seg_vals = sorted(set(seg))
            seg_range = seg_vals[-1] - seg_vals[0]
            unique_count = len(seg_vals)
            has_dup = any(seg.count(v) >= 2 for v in set(seg))
            dup_vals = [v for v in set(seg) if seg.count(v) >= 2]
            dup_count = len(dup_vals)
            
            # 六连/长连型（6+张，5+种不同值，如345678）
            if seg_len >= 6 and unique_count >= 5:
                # 检查是否是"坎张孤张端"：该牌只通过坎张(间隔2)连接到段主体
                # 如3566788p中3p只通过坎张35p连接，拆掉3p不破坏5678p核心结构
                is_kana_isolated = self._is_kana_isolated_end(val, seg)
                if is_kana_isolated:
                    # 检查该段中是否存在"双坎张负担"（两组以上坎张挤在一起）
                    # 如3566788p中同时有35p坎张和68p坎张，拆掉3p消掉一组愚型
                    kana_count_in_seg = self._count_kana_in_seg(seg)
                    if kana_count_in_seg >= 2:
                        score += 0  # 双坎张负担中的孤张端，拆掉消除一组愚型，最该出
                    else:
                        score += 2  # 单坎张孤张端，拆掉不影响核心，该出
                else:
                    # 检查是否是"暗刻旁孤张端"：端点牌通过两面(间隔1)连接到下一个值，
                    # 但下一个值是暗刻(count>=3)，暗刻本身是完整面子
                    # 如1-222-456-89s中1s连接到2s(暗刻)，拆掉1s不影响222+456+89核心
                    is_triplet_adjacent = False
                    if tile.suit != 'honor':
                        seg_vals_full = sorted(set(seg))
                        if val == seg_vals_full[0]:
                            # 左端点，检查右邻是否暗刻
                            next_val_check = seg_vals_full[1]
                            if next_val_check - val == 1:
                                # 两面连接，检查next_val是否是暗刻
                                next_tile = MahjongTile(suit, next_val_check)
                                if tile_counts.get(next_tile, 0) >= 3:
                                    is_triplet_adjacent = True
                        elif val == seg_vals_full[-1]:
                            # 右端点，检查左邻是否暗刻
                            prev_val_check = seg_vals_full[-2]
                            if val - prev_val_check == 1:
                                # 两面连接，检查prev_val是否是暗刻
                                prev_tile = MahjongTile(suit, prev_val_check)
                                if tile_counts.get(prev_tile, 0) >= 3:
                                    is_triplet_adjacent = True
                    
                    if is_triplet_adjacent:
                        score += 2  # 暗刻旁孤张端，拆掉不影响核心，该出
                    else:
                        score += 8  # 长连不该拆
            
            # 六连含对子（如334567或345567等）
            elif seg_len >= 6 and has_dup:
                # 细分：对子牌 vs 非对子牌
                if val in dup_vals:
                    # 先检查是否是"四枚畸形块"中的对子（如446899中的44）
                    # 四枚畸形块 = 对子+坎张/搭子挤在一起，拆对子后形成两坎好形
                    non_dup_vals = [v for v in seg_vals if v not in dup_vals]
                    is_deformity = False
                    if len(non_dup_vals) >= 2:
                        non_dup_range = max(non_dup_vals) - min(non_dup_vals)
                        if non_dup_range >= 2:
                            is_deformity = True
                    
                    if is_deformity:
                        # 如4468: 44对+68坎张，拆4后剩468两坎 → 该出
                        # 如446899: 44+68+99，拆4后剩46899两坎+宝牌对 → 该出
                        score += 0  # 四枚畸形块拆对子后形成两坎/好形，最该出
                    elif dup_count >= 2:
                        # 双对子复合体（如78899s=78+89+99双亚两面）
                        # 两个对子+少量单牌，非畸形块（非对子牌相邻）
                        # 找中间对子（非端点对子）
                        is_middle_dup = (val != seg_vals[0] and val != seg_vals[-1])
                        if is_middle_dup:
                            # 如78899s拆8s→7 99s，保留亚两面潜力
                            # 当手牌有外部对子可做雀头时，拆中间对子释放复合
                            total_pairs = sum(1 for c in tile_counts.values() if c == 2)
                            if total_pairs >= 3:
                                # 有外部雀头对子，拆中间对子最优
                                score += 1  # 该出
                            else:
                                score += 3  # 无外部雀头时谨慎
                        else:
                            # 端点对子（如78899s中9s），拆后保留亚两面但不如拆中间
                            score += 4  # 可出但不如拆中间对子
                    else:
                        score += 5  # 对子牌一般保留
                else:
                    # 非对子牌：检查是否是"坎张孤张端"
                    is_kana_isolated = self._is_kana_isolated_end(val, seg)
                    if is_kana_isolated:
                        score += 2  # 坎张孤张端，拆掉不影响核心结构，该出
                    else:
                        score += 7  # 非对子牌不该拆
            
            # 五连型（5张5种值，如34567）
            elif seg_len == 5 and unique_count == 5:
                if val == seg_vals[0] or val == seg_vals[-1]:
                    score += 6  # 拆端点
                else:
                    score += 8  # 拆中间更不该
            
            # 纯4连亚两面（4张4种值，如4567=45+67两个重叠两面）
            elif seg_len == 4 and unique_count == 4:
                if val == seg_vals[0] or val == seg_vals[-1]:
                    score += 4  # 拆端点可接受
                else:
                    score += 7  # 拆中间破坏两个两面
            
            # 含对子的4张3值型（如3445=34+45含对子4，亚两面含对子）
            elif seg_len == 4 and unique_count == 3 and has_dup and dup_count == 1:
                dup_val = dup_vals[0]
                if val == dup_val:
                    # 检查是否是"冗余对子"——拆掉1张后段仍含完整顺子
                    # 如7889p中8p对子，拆掉1张后剩789p（完整顺子）→ 对子中多余的牌
                    still_shuntsu = self._dora_redundant_in_pair(tile, hand, tile_counts)
                    if still_shuntsu:
                        # 细分：中膨型(如2334m，对子在中间) vs 边对子型(如7889p，对子在端)
                        # 中膨型拆对子→直接变完整顺子(如2334m拆3m→234m)，释放雀头给其他段
                        # 边对子型拆对子→也变顺子(如7889p拆8p→789p)，但价值不同
                        # 中膨型中，拆对子比拆端点更好（端点拆后留对子+搭子=锁死雀头）
                        is_middle_pair = (dup_val != seg_vals[0] and dup_val != seg_vals[-1])
                        if is_middle_pair:
                            # 中膨型拆对子→完整顺子，释放雀头，最优拆法
                            score += 0  # 最该出
                        else:
                            score += 2  # 边对子冗余，拆掉后形成顺子，该出
                    else:
                        # 对子拆掉后不形成完整顺子
                        # 但检查拆掉后是否保留有效坎张复合（如1135p拆1p→135p=13坎+35坎，改良多）
                        # vs 拆另一端（如1135p拆5p→113p=11对子+13坎，改良少）
                        # 仅在3对子+搭子溢出时给compound=0（三雀头最弱拆对子）
                        # 2对子时拆对子损失雀头，不给极低分
                        total_pairs_check = sum(1 for c in tile_counts.values() if c == 2)
                        block_count_check = self._count_blocks(hand, tile_counts)
                        sim_seg_vals = [v for v in seg_vals if v != dup_val]
                        if len(sim_seg_vals) >= 2:
                            sim_range = sim_seg_vals[-1] - sim_seg_vals[0]
                            if sim_range >= 2 and total_pairs_check >= 3 and block_count_check >= 6:
                                # 3对子+搭子溢出时，拆对子保留双坎张改良路线，该拆
                                score += 0  # 最该出
                            elif sim_range >= 2:
                                # 保留坎张复合但不是三雀头情况，中等偏低
                                score += 3  # 可出但有损失
                            else:
                                score += 5  # 拆对子损失对子
                        else:
                            score += 5  # 拆对子牌，损失对子
                else:
                    # 拆非对子端点（如3445拆5->344保留对子+搭子）
                    # 这是正解级别的拆法！给低分=该出
                    # 但在中膨型(如2334m)中拆端点(2m/4m)会留对子锁死雀头，不如拆对子
                    is_middle_pair_seg = (dup_val != seg_vals[0] and dup_val != seg_vals[-1])
                    if is_middle_pair_seg:
                        # 中膨型拆端点→留中间对子+搭子=锁死雀头，不如拆对子好
                        score += 4  # 可出但不如拆对子
                    else:
                        score += 2  # 边对子型拆端点=正解级拆法
            
            # 含对子的4张2值型（如4455=两个对子）
            elif seg_len == 4 and unique_count == 2 and has_dup:
                score += 4  # 两个对子，拆一个可接受
            
            # 完整顺子3连（如345）
            elif seg_len == 3 and unique_count == 3:
                score += 9  # 完整顺子不该拆
            
            # 含对子的3张（如445=对子+邻接，或334=对子+邻接，或7-99=坎张+对子）
            elif seg_len == 3 and has_dup:
                if val in dup_vals:
                    score += 4  # 对子可拆
                else:
                    # 非对子牌：检查是否通过坎张(间隔2)连接到对子
                    # 如7-99m中7m通过坎张7-9连接到99对子
                    # 拆掉后万子只剩对子做雀头，万子失去搭子能力
                    # 但7m是该出的——它只是坎张孤张端，拆掉不影响核心
                    is_kana_to_pair = False
                    if tile.suit != 'honor':
                        non_dup_val = val
                        dup_val_check = dup_vals[0]
                        if abs(non_dup_val - dup_val_check) == 2:
                            is_kana_to_pair = True
                    
                    if is_kana_to_pair:
                        score += 2  # 坎张孤张端连对子，拆掉释放对子做雀头，该出
                    else:
                        score += 6  # 非对子牌不该拆
            
            # 两面搭子（如45）
            elif seg_len == 2 and unique_count == 2 and seg_range == 1:
                if val in [1, 9]:
                    score += 3
                elif val in [2, 8]:
                    score += 3
                else:
                    score += 5  # 两面搭子不该轻易拆
            
            # 坎张搭子（如35间隔2）
            elif seg_len == 2 and unique_count == 2 and seg_range == 2:
                # 检查全场是否存在"四枚畸形块"（对子+坎张挤在一起）
                # 如果存在畸形块，此独立坎张搭子不该拆（问题在畸形块那边）
                has_deformity = self._has_deformity_block(tile_counts)
                if has_deformity:
                    score += 5  # 有畸形块需改造时，独立搭子不该拆
                else:
                    score += 1  # 无畸形块时，坎张可以拆
            
            # 含对子的5张型（如34455或33445，或78899双亚两面）
            elif seg_len == 5 and has_dup:
                if dup_count >= 2:
                    if val in dup_vals:
                        # 检查是否是双亚两面复合体（如78899s=78+89+99）
                        # 双对子+少量单牌，非畸形块（非对子牌相邻）
                        non_dup_vals_5 = [v for v in seg_vals if v not in dup_vals]
                        is_deformity_5 = False
                        if len(non_dup_vals_5) >= 2:
                            if max(non_dup_vals_5) - min(non_dup_vals_5) >= 2:
                                is_deformity_5 = True
                        
                        if is_deformity_5:
                            score += 1  # 畸形块中拆对子后形成两坎，该出
                        else:
                            # 双亚两面复合体（如78899s）
                            is_middle_dup_5 = (val != seg_vals[0] and val != seg_vals[-1])
                            if is_middle_dup_5:
                                # 中间对子（如78899s中8s），拆掉保留亚两面潜力
                                total_pairs_5 = sum(1 for c in tile_counts.values() if c == 2)
                                if total_pairs_5 >= 3:
                                    score += 1  # 有外部雀头时拆中间对子最优，该出
                                else:
                                    score += 3  # 无外部雀头时谨慎
                            else:
                                # 端点对子（如78899s中9s），拆后保留亚两面但不如拆中间
                                score += 4  # 可出但不如拆中间对子
                    else:
                        score += 6
                else:
                    score += 5
            
            # 孤立牌
            elif seg_len == 1:
                score += 0  # 孤立牌无复合结构价值
            
            # 孤立对子（段只有2张相同牌，无邻接连接，如99p独立对子）
            elif seg_len == 2 and unique_count == 1 and count == 2:
                block_count_now = self._count_blocks(hand, tile_counts)
                if block_count_now >= 6:
                    score += 0  # 搭子超载时，拆孤立对子直接减1搭，解决超载，该出
                else:
                    score += 3  # 非超载时，对子有雀头价值
            
            # 其他未匹配的情况
            else:
                score += 3  # 默认中等分
        
        # 三色同顺加成（含潜力三色：搭子也算）
        for seq_val in range(1, 8):
            if val < seq_val or val > seq_val + 2:
                continue
            found_suits = []
            potential_suits = []  # 含搭子潜力的花色
            for check_suit in ['man', 'pin', 'sou']:
                # 检查是否已有完整顺子
                has_seq = True
                for v in range(seq_val, seq_val + 3):
                    if tile_counts.get(MahjongTile(check_suit, v), 0) < 1:
                        has_seq = False
                        break
                if has_seq:
                    found_suits.append(check_suit)
                    potential_suits.append(check_suit)
                else:
                    # 检查是否有该三色的搭子潜力
                    # 条件：该花色在此区间有≥2张牌（在区间内）
                    # 或者有2张牌形成搭子且只需1张就能凑出该顺子
                    # 如68p等5p凑456p，虽然只有6p在[4,5,6]区间内
                    # 但6p+8p中6p在区间，搭子68p的进张5p正好能凑出456p
                    count_in_seq = sum(tile_counts.get(MahjongTile(check_suit, v), 0) for v in range(seq_val, seq_val + 3))
                    if count_in_seq >= 2:
                        # 有2张以上在此区间，有潜力
                        potential_suits.append(check_suit)
                    elif count_in_seq >= 1:
                        # 只有1张在此区间，检查是否有搭子能等进张凑出此顺子
                        # 找出此区间内已有的牌
                        in_seq_tiles = [v for v in range(seq_val, seq_val + 3) if tile_counts.get(MahjongTile(check_suit, v), 0) >= 1]
                        for in_val in in_seq_tiles:
                            # 检查是否有搭子（相邻或坎张）包含此区间内外的牌
                            # 如6p在[4,5,6]区间，68p搭子等5p凑456p
                            for offset in [-2, -1, 1, 2]:
                                partner_val = in_val + offset
                                if 1 <= partner_val <= 9 and partner_val not in range(seq_val, seq_val + 3):
                                    if tile_counts.get(MahjongTile(check_suit, partner_val), 0) >= 1:
                                        # 检查这个搭子等到的牌能否凑出此区间顺子
                                        # 68p等5p(5在区间[4,5,6]内)→能凑456p
                                        wait_val = (in_val + partner_val) // 2 if abs(in_val - partner_val) == 2 else None
                                        if abs(in_val - partner_val) == 2 and wait_val in range(seq_val, seq_val + 3):
                                            # 坎张搭子等到的牌在此区间→能凑出三色
                                            potential_suits.append(check_suit)
                                            break
                                        # 两面搭子等到的牌在此区间
                                        elif abs(in_val - partner_val) == 1:
                                            # 如56p等4p或7p，4p在区间[4,5,6]内→能凑456p
                                            wait1 = min(in_val, partner_val) - 1
                                            wait2 = max(in_val, partner_val) + 1
                                            if wait1 in range(seq_val, seq_val + 3) or wait2 in range(seq_val, seq_val + 3):
                                                potential_suits.append(check_suit)
                                                break
                            if check_suit in potential_suits:
                                break
            # 完整三色：2花色已有完整顺子
            if len(found_suits) >= 2 and suit in found_suits:
                # 当base score低（该出的牌）时，三色保护降低
                if score <= 2:
                    score += 2  # 该出的牌有三色但不该被过度保护
                else:
                    score += 4  # 已有完整三色，更强
                break
            # 潜力三色：至少2花色有潜力（含搭子等进张凑出）
            if len(potential_suits) >= 2 and suit in potential_suits:
                # 当base score极低（畸形块等该出的牌）时，三色潜力不应过度保护
                if score <= 1:
                    pass  # 畸形块/最该出的牌，三色潜力完全不加成
                else:
                    score += 2  # 参与三色潜力（搭子也算）
                break
        
        return min(score, 15)
    
    def _evaluate_five_block(self, tile, hand, tile_counts):
        """评估五组理论拆搭需求（0-10分，越高越该出）
        
        基于何切五组理论：
        - 手牌有6组搭子时，优先拆掉1组愚型降至5组
        - 愚型搭子只有1个时，必须拆那个愚型
        - 有坎张对/边张对时，必须拆
        - 全两面或多个愚型+两面对子时，可选保留6组
        """
        # 统计搭子组数
        block_count = self._count_blocks(hand, tile_counts)
        
        if block_count < 6:
            return 0  # 不到6组，不需要拆
        
        # 检查这张牌所在的搭子类型
        if tile.suit == 'honor':
            count = tile_counts.get(tile, 0)
            if count == 1:
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                if honor_name not in [player_wind, round_wind] and tile.value not in [5, 6, 7]:
                    return 7  # 客风单张在6组时优先拆
            # 客风暗刻拆一张激活断幺九路线：count==3，非役牌，拆后留对子，
            # 且拆后手牌剩余幺九牌<=3张（只剩此对子+1张可自然处理的幺九），该拆
            if count == 3:
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                is_yakuhai = honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]
                if not is_yakuhai:
                    # 检查拆掉一张后，手牌剩余幺九牌数量
                    yaochu_after = sum(c for t, c in tile_counts.items() if t.is_yaochu()) - 1
                    if yaochu_after <= 3:
                        return 8  # 拆客风暗刻激活断幺九路线，该拆
            return 0
        
        val = tile.value
        suit = tile.suit
        count = tile_counts.get(tile, 0)
        
        if count >= 2:
            # 相离两坎含dora瞄准：拆对子造两坎+dora路线，优先拆
            if count == 2:
                has_sep_kana, has_dora_target = self._detect_separated_kana_pattern(tile, hand, tile_counts)
                if has_sep_kana and has_dora_target:
                    return 8  # 拆对子造相离两坎含dora瞄准，该拆
            # 三雀头最弱理论：3对子+搭子溢出时，拆普通对子瞬间进张多2枚
            if count == 2:
                total_pairs = sum(1 for c in tile_counts.values() if c == 2)
                if total_pairs >= 3:
                    # 检查是否是dora宝牌对子（不能拆）
                    dora_tiles = self._get_current_dora_tiles()
                    if tile in dora_tiles:
                        return 0  # dora对子绝对不拆
                    # 检查是否是役牌对子（优先保留）
                    if tile.suit == 'honor':
                        honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                        player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                        round_wind = self.round_wind_var.get()
                        if honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]:
                            return 0  # 役牌对子优先保留
                    # 普通对子在3对子+搭子溢出时，应该拆（三雀头最弱）
                    return 8
            return 0  # 刻子不拆
        
        # 判断搭子类型
        has_p1 = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
        has_n1 = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
        has_p2 = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
        has_n2 = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
        
        # 顺子的一部分不拆
        if has_p1 and has_n1:
            return 0
        if has_p1 and MahjongTile(suit, val - 2) in tile_counts:
            return 0
        if has_n1 and MahjongTile(suit, val + 2) in tile_counts:
            return 0
        
        # 两面搭子
        if (has_p1 and not has_p2) or (has_n1 and not has_n2):
            # 检查是否连接到暗刻——如1s连2s暗刻，不是有效两面，拆掉不影响核心
            is_adjacent_to_triplet = False
            if has_n1 and not has_p1:
                next_tile_check = MahjongTile(suit, val + 1)
                if tile_counts.get(next_tile_check, 0) >= 3:
                    is_adjacent_to_triplet = True
            if has_p1 and not has_n1:
                prev_tile_check = MahjongTile(suit, val - 1)
                if tile_counts.get(prev_tile_check, 0) >= 3:
                    is_adjacent_to_triplet = True
            
            if is_adjacent_to_triplet:
                return 8  # 连接到暗刻的端点牌，不是有效搭子，该拆
            
            # 检查是否是真正的两面（如34万，可摸2万或5万）
            if val in [2, 8]:
                return 2  # 23或78是边张，算愚型
            return 1  # 两面搭子，五组理论例外可保留
        
        # 愚型搭子（坎张、边张）
        if has_p2 or has_n2:
            base_score = 8  # 愚型优先拆
        elif val in [1, 9]:
            base_score = 9  # 端牌浮牌优先拆
        elif val in [2, 8]:
            base_score = 7
        elif val in [3, 7]:
            base_score = 5
        else:
            base_score = 3
        
        # 统计全局愚型搭子数量（判断是否"只有一个愚型"的情况）
        kana_count = 0
        for t, c in tile_counts.items():
            if c == 1 and t.suit != 'honor':
                tv = t.value
                ts = t.suit
                tp1 = MahjongTile(ts, tv - 1) in tile_counts if tv > 1 else False
                tn1 = MahjongTile(ts, tv + 1) in tile_counts if tv < 9 else False
                tp2 = MahjongTile(ts, tv - 2) in tile_counts if tv > 2 else False
                tn2 = MahjongTile(ts, tv + 2) in tile_counts if tv < 8 else False
                # 愚型判定：坎张或边张
                if (tp2 and not tp1) or (tn2 and not tn1):
                    kana_count += 1
                elif (tv in [1, 9] and (tp1 or tn1)):
                    kana_count += 1  # 边张
                elif (tv == 2 and tp1 and not tn1) or (tv == 8 and tn1 and not tp1):
                    kana_count += 1  # 边张
        
        # 只有1个愚型时，必须拆那个愚型
        if kana_count <= 1 and base_score >= 5:
            return 10
        
        return base_score
    
    def _count_blocks(self, hand, tile_counts):
        """统计手牌的搭子组数（面子+搭子+对子的总组数）
        
        用于五组理论判断：手牌13张理论上需要4面子+1雀头=5组
        超过5组意味着搭子过多，需要拆
        """
        blocks = 0
        used = set()
        
        # 先识别顺子
        for suit in ['man', 'pin', 'sou']:
            for val in range(1, 8):
                t1 = MahjongTile(suit, val)
                t2 = MahjongTile(suit, val + 1)
                t3 = MahjongTile(suit, val + 2)
                if (t1 in tile_counts and t2 in tile_counts and t3 in tile_counts and
                    tile_counts[t1] >= 1 and tile_counts[t2] >= 1 and tile_counts[t3] >= 1):
                    # 标记使用过的牌
                    for t in [t1, t2, t3]:
                        if t not in used:
                            used.add(t)
                    blocks += 1
        
        # 再识别刻子
        for t, c in tile_counts.items():
            if c >= 3 and t not in used:
                blocks += 1
                used.add(t)
        
        # 再识别对子
        for t, c in tile_counts.items():
            if c == 2 and t not in used:
                blocks += 1
                used.add(t)
        
        # 剩余的孤立牌各算1组
        for t, c in tile_counts.items():
            if t not in used:
                actual = min(c, 1)
                blocks += actual
                used.add(t)
        
        return blocks
    
    def _count_ukeire(self, hand, known_used=None):
        """计算手牌的有效进张数（模拟摸牌后向听数是否减少）
        
        参数 known_used: Counter对象，记录场上已出的牌+别家碰杠占用的牌
        如果传入，将扣除这些已知消耗的牌，计算真实的剩余可摸枚数
        """
        if not hand:
            return 0
        
        current_shanten = WinProbabilityCalculator.calculate_shanten(hand)
        ukeire_count = 0
        
        # 已知的牌消耗（手牌+场上舍牌+碰杠明牌）
        if known_used is None:
            known_used = Counter()
        
        # 遍历所有可能的进张牌
        for suit in ['man', 'pin', 'sou']:
            for val in range(1, 10):
                test_tile = MahjongTile(suit, val)
                hand_count = hand.count(test_tile)
                used_count = known_used.get(test_tile, 0)
                total_known = hand_count + used_count
                if total_known >= 4:
                    continue
                remaining = 4 - total_known  # 真实剩余可摸枚数
                
                test_hand = hand + [test_tile]
                new_shanten = WinProbabilityCalculator.calculate_shanten(test_hand)
                if new_shanten < current_shanten:
                    ukeire_count += remaining
        
        # 字牌
        for val in range(1, 8):
            test_tile = MahjongTile('honor', val)
            hand_count = hand.count(test_tile)
            used_count = known_used.get(test_tile, 0)
            total_known = hand_count + used_count
            if total_known >= 4:
                continue
            remaining = 4 - total_known
            
            test_hand = hand + [test_tile]
            new_shanten = WinProbabilityCalculator.calculate_shanten(test_hand)
            if new_shanten < current_shanten:
                ukeire_count += remaining
        
        return ukeire_count
    
    def _get_known_used_counter(self, my_pos):
        """汇总场上已知的牌消耗（舍牌池+别家碰杠明牌），返回Counter
        
        用于进张计算时扣除已被消耗的牌，使进张数反映真实可摸枚数
        """
        known_used = Counter()
        
        # 全场舍牌池
        for pos in self.public_discards:
            known_used.update(self.public_discards[pos])
        
        # 别家碰杠明牌（不含自家，自家明牌已在手牌中体现）
        for pos in self.player_melds:
            if pos == my_pos:
                continue  # 自家明牌已在 player_hands 体系内处理
            for meld in self.player_melds[pos]:
                for t in meld.get('tiles', []):
                    known_used[t] += 1
        
        return known_used
    
    def _evaluate_kana_value(self, tile, hand, tile_counts):
        """评估牌的愚型程度（0-10分，越高越该出）
        
        愚型搭子 = 进张面窄、效率低的牌型组合：
        - 坎张搭子（如57万，需要6万才能成顺子）
        - 边张搭子（如12万需要3万，89万需要7万）
        - 孤立老头牌（单张1、9）
        - 单张非场风自风的字牌
        """
        if tile.suit == 'honor':
            count = tile_counts.get(tile, 0)
            if count == 1:
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                if honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]:
                    return 3
                return 8
            elif count == 2:
                return 2
            return 0
        
        val = tile.value
        suit = tile.suit
        count = tile_counts.get(tile, 0)
        
        if count >= 3:
            return 0
        
        has_prev1 = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
        has_next1 = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
        has_prev2 = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
        has_next2 = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
        
        if count == 2:
            if not has_prev1 and not has_next1 and not has_prev2 and not has_next2:
                return 3
            return 1
        
        if val in [1, 9]:
            if has_next1 or has_prev1:
                return 6  # 边张搭子
            elif has_next2 or has_prev2:
                return 7  # 坎张搭子
            else:
                return 9  # 孤立老头牌
        
        elif val in [2, 8]:
            if has_prev1 and has_next1:
                return 0  # 两面搭子
            elif has_next1 or has_prev1:
                if val == 2 and has_next1 and MahjongTile(suit, 3) in tile_counts:
                    return 0  # 23连子
                if val == 8 and has_prev1 and MahjongTile(suit, 7) in tile_counts:
                    return 0  # 78连子
                return 4
            if has_next2 or has_prev2:
                return 6  # 坎张
            return 7  # 孤立边张
        
        else:  # 3-7中张
            if has_prev1 and has_next1:
                return 0  # 两面搭子
            elif has_prev1 or has_next1:
                if has_prev1 and MahjongTile(suit, val - 2) in tile_counts:
                    return 0  # 顺子的一部分
                if has_next1 and MahjongTile(suit, val + 2) in tile_counts:
                    return 0  # 顺子的一部分
                return 3  # 单纯邻接
            elif has_prev2 and has_next2:
                return 2  # 中张间隔
            elif has_prev2 or has_next2:
                return 5  # 坎张（如35、57）
            else:
                same_suit = sum(c for t, c in tile_counts.items() if t.suit == suit)
                if same_suit <= 2:
                    return 7  # 孤立中张，花色少
                return 5  # 孤立中张，但花色多
    
    def _evaluate_improvement_potential(self, tile, hand, tile_counts):
        """评估出牌后改良进张的潜力（0-10分，越高越不该出）
        
        改良进张 = 摸到某张牌后牌型变好的可能性
        如237万出5万后，摸8万能形成2378万→两面听牌
        """
        if tile.suit == 'honor':
            count = tile_counts.get(tile, 0)
            if count >= 2:
                return 5
            return 1
        
        val = tile.value
        suit = tile.suit
        count = tile_counts.get(tile, 0)
        
        if count >= 3:
            return 8
        
        score = 0
        
        # 检查周围牌的改良可能性
        for offset in [-3, -2, -1, 1, 2, 3]:
            neighbor_val = val + offset
            if 1 <= neighbor_val <= 9:
                neighbor = MahjongTile(suit, neighbor_val)
                if neighbor not in tile_counts or tile_counts[neighbor] < 4:
                    # 模拟摸到这张牌后的改良效果
                    sim_hand = hand + [neighbor]
                    sim_hand.remove(tile)
                    new_shanten = WinProbabilityCalculator.calculate_shanten(sim_hand)
                    orig_shanten = WinProbabilityCalculator.calculate_shanten(hand)
                    if new_shanten < orig_shanten:
                        score += 2  # 有效改良进张
                    elif new_shanten == orig_shanten:
                        score += 1
        
        # 红5价值（5万/5筒/5条有赤宝牌进张价值）
        if val == 5:
            score += 2
        
        # 对子的雀头候补价值
        if count == 2:
            score += 3
        
        return min(score, 10)
    
    def _evaluate_yaku_impact(self, tile, hand, tile_counts, count):
        """评估出牌对役种潜力的影响（0-10分，越高越不该出）"""
        score = 0
        
        # 断幺九影响
        yaochu_count = sum(c for t, c in tile_counts.items() if t.is_yaochu())
        if tile.is_yaochu():
            if yaochu_count <= 3:
                score -= 3  # 出此牌有助于做断幺九（减分=更该出）
        
        # 有暗刻的役牌不能做断幺
        has_honor_triplet = any(
            c >= 3 and t.suit == 'honor' 
            for t, c in tile_counts.items()
        )
        if has_honor_triplet and tile.is_yaochu():
            score -= 2  # 更该出
        
        # 一杯口影响
        for suit in ['man', 'pin', 'sou']:
            suit_tiles = [t for t in hand if t.suit == suit]
            suit_counts = Counter(suit_tiles)
            for val in range(1, 8):
                seq = [MahjongTile(suit, val), MahjongTile(suit, val+1), MahjongTile(suit, val+2)]
                if all(suit_counts.get(t, 0) >= 2 for t in seq):
                    if tile in seq:
                        score += 6  # 极不该出
                    break
                if all(suit_counts.get(t, 0) >= 1 for t in seq):
                    if (suit_counts.get(seq[0], 0) >= 2 or suit_counts.get(seq[1], 0) >= 2 or 
                        suit_counts.get(seq[2], 0) >= 2):
                        if tile in seq and count == 1:
                            score += 3
        
        # 三色同顺影响
        for val in range(1, 8):
            found_suits = []
            for suit in ['man', 'pin', 'sou']:
                seq = [MahjongTile(suit, val), MahjongTile(suit, val+1), MahjongTile(suit, val+2)]
                if all(tile_counts.get(t, 0) >= 1 for t in seq):
                    found_suits.append(suit)
            if len(found_suits) >= 2:
                seq = [MahjongTile(tile.suit, val), MahjongTile(tile.suit, val+1), MahjongTile(tile.suit, val+2)]
                if tile in seq:
                    score += 4
                break
        
        # 役牌对子/刻子（仅限真正的役牌：场风/自风/三元牌）
        if tile.suit == 'honor' and count >= 2:
            honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
            player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
            round_wind = self.round_wind_var.get()
            is_yakuhai = honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]
            if is_yakuhai:
                score += 5  # 役牌对子/刻子有役价值，不该出
            elif count == 3:
                # 客风暗刻：检查是否可激活断幺九路线
                block_count = self._count_blocks(hand, tile_counts)
                if block_count >= 6:
                    yaochu_after = sum(c for t, c in tile_counts.items() if t.is_yaochu()) - 1
                    if yaochu_after <= 3:
                        score -= 3  # 拆客风暗刻激活断幺九路线，更该出
        
        # 清一色/混一色影响
        suits_present = set(t.suit for t in hand if t.suit != 'honor')
        if len(suits_present) == 1 and tile.suit != 'honor':
            score += 3
        
        return max(score, 0)
    
    def _generate_discard_reasons_v2(self, tile, count, shanten_change, 
                                      ukeire_change, base_ukeire, new_ukeire,
                                      kana_score, improvement, yaku_impact, 
                                      type_value, hand, tile_counts,
                                      float_value=0, safety_score=0, 
                                      pair_struct=0, five_block=0,
                                      discarded_counter=None, compound=0):
        """生成多样化的出牌推荐理由（V3版 - 基于何切.txt实战教学体系）"""
        reasons = []
        
        if discarded_counter is None:
            discarded_counter = Counter()
        
        # 1. 向听数和进张数影响
        if shanten_change > 0:
            reasons.append("❌ 出后向听数增加，不推荐")
        elif shanten_change == 0:
            if ukeire_change < 0:
                reasons.append(f"⚠️ 不影响向听，但进张减少{abs(ukeire_change)}张")
            elif ukeire_change == 0:
                reasons.append(f"✅ 不影响向听数，进张数不变({new_ukeire}张)")
            else:
                reasons.append(f"✅ 不影响向听，进张增加{ukeire_change}张")
        
        # 2. 浮牌价值分析（基于19>28>37>456理论）
        if tile.suit != 'honor' and count == 1:
            val = tile.value
            suit = tile.suit
            suit_name = {'man': '万', 'pin': '筒', 'sou': '条'}[suit]
            
            has_p1 = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
            has_n1 = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
            has_p2 = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
            has_n2 = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
            
            is_float = not (has_p1 or has_n1 or has_p2 or has_n2)
            
            if is_float:
                if val in [1, 9]:
                    reasons.append(f"📌 孤立{val}{suit_name}(端牌) - 只能摸1种牌成搭，优先切")
                elif val in [2, 8]:
                    reasons.append(f"📌 孤立{val}{suit_name}(边张) - 可摸2种牌成搭，价值低")
                elif val in [3, 7]:
                    reasons.append(f"📌 孤立{val}{suit_name}(中张) - 可摸4种牌成搭，改良能力强")
                else:
                    reasons.append(f"📌 孤立{val}{suit_name}(中心) - 可摸5种牌成搭，价值最高尽量留")
        
        # 3. 搭子类型分析（愚型/良型）+ 字牌进攻排序
        if tile.suit == 'honor':
            honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
            player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
            round_wind = self.round_wind_var.get()
            is_yakuhai = honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]
            is_guest_wind = tile.value in [1, 2, 3, 4] and not is_yakuhai
            discarded_count = discarded_counter.get(tile, 0)
            
            if count == 1:
                if is_guest_wind:
                    reasons.append(f"📌 单张{honor_name}(客风) - 进攻最先处理，防守看现物({discarded_count}张)")
                elif honor_name == round_wind:
                    reasons.append(f"📌 单张{honor_name}(场风) - 进攻第二切，可留待碰牌")
                elif honor_name == player_wind:
                    reasons.append(f"📌 单张{honor_name}(自风) - 有役价值，晚于客风场风")
                elif tile.value == 6:
                    reasons.append(f"📌 单张{honor_name}(发) - 三元牌可碰得役，晚于风牌")
                elif tile.value == 7:
                    reasons.append(f"📌 单张{honor_name}(中) - 三元牌可碰得役，价值较高")
                elif tile.value == 5:
                    reasons.append(f"📌 单张{honor_name}(白) - 三元牌价值最高，最晚切")
                if discarded_count >= 3:
                    reasons.append(f"🛡️ 场上已出{discarded_count}张{honor_name}，几乎不可能点炮")
                elif discarded_count == 0:
                    reasons.append(f"⚠️ {honor_name}生张，防守时注意可能被双碰听")
            elif count == 2:
                if is_yakuhai:
                    reasons.append(f"📌 {honor_name}对子 - 役牌对子，碰了就有役，保留")
                else:
                    reasons.append(f"📌 {honor_name}对子 - 客风对子，可做雀头或碰牌")
            elif count >= 3:
                if is_yakuhai:
                    reasons.append(f"📌 {honor_name}暗刻({count}张) - 役牌核心，不建议出")
                else:
                    # 客风暗刻：检查是否可拆激活断幺九
                    block_count_check = self._count_blocks(hand, tile_counts)
                    yaochu_check = sum(c for t, c in tile_counts.items() if t.is_yaochu())
                    if block_count_check >= 6 and yaochu_check - 1 <= 3:
                        reasons.append(f"📌 {honor_name}客风暗刻({count}张) - 可拆一张激活断幺九，留对子后续可继续拆")
                    else:
                        reasons.append(f"📌 {honor_name}暗刻({count}张) - 客风暗刻，无役价值")
        else:
            val = tile.value
            suit = tile.suit
            suit_name = {'man': '万', 'pin': '筒', 'sou': '条'}[suit]
            
            if count >= 3:
                reasons.append(f"📌 {tile}刻子，做牌核心不建议出")
            elif count == 2:
                has_prev = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
                has_next = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
                if has_prev or has_next:
                    reasons.append(f"📌 {tile}对子有连接，雀头+搭子双重价值")
                else:
                    reasons.append(f"📌 {tile}孤立对子，可做雀头候补")
            else:
                has_p1 = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
                has_n1 = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
                has_p2 = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
                has_n2 = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
                
                if has_p1 and has_n1:
                    reasons.append(f"📌 {tile}在两面搭子中，进张面宽(良型)")
                elif has_p1 and MahjongTile(suit, val-2) in tile_counts:
                    reasons.append(f"📌 {tile}在顺子中，不该出")
                elif has_n1 and MahjongTile(suit, val+2) in tile_counts:
                    reasons.append(f"📌 {tile}在顺子中，不该出")
                elif has_p2 or has_n2:
                    if has_p2:
                        reasons.append(f"📌 {tile}与{val-2}{suit_name}形成坎张({val-2}-{val})，愚型搭子")
                    else:
                        reasons.append(f"📌 {tile}与{val+2}{suit_name}形成坎张({val}-{val+2})，愚型搭子")
                elif val in [1, 9]:
                    if has_n1 or has_p1:
                        reasons.append(f"📌 {tile}边张搭子，进张面窄(愚型)")
                    else:
                        reasons.append(f"📌 孤立{tile}，老头牌无连接")
                elif has_p1 or has_n1:
                    reasons.append(f"📌 {tile}有邻接牌，半良型")
                else:
                    same_suit = sum(c for t, c in tile_counts.items() if t.suit == suit)
                    if same_suit <= 2:
                        reasons.append(f"📌 孤立{tile}，同花色仅{same_suit}张")
                    else:
                        reasons.append(f"📌 孤立{tile}，但有同花色改良空间")
        
        # 4. 五组理论分析
        if five_block >= 8:
            if count == 2:
                reasons.append("📐 五组理论：手牌超5组搭子，拆此对子可造相离两坎+释放搭子压力")
            elif tile.suit == 'honor' and count >= 3:
                # 客风暗刻拆一张激活断幺九路线
                honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                is_yakuhai = honor_name in [player_wind, round_wind] or tile.value in [5, 6, 7]
                if not is_yakuhai:
                    yaochu_after = sum(c for t, c in tile_counts.items() if t.is_yaochu()) - 1
                    if yaochu_after <= 3:
                        reasons.append("📐 五组理论：拆客风暗刻激活断幺九路线，留对子后续可继续拆，解锁副露权")
                    else:
                        reasons.append("📐 五组理论：手牌超5组搭子，此牌所在愚型优先拆")
                else:
                    reasons.append("📐 五组理论：手牌超5组搭子，此牌所在愚型优先拆")
            else:
                # 检查是否是连接到暗刻的端点牌
                if tile.suit != 'honor':
                    val_fb = tile.value
                    suit_fb = tile.suit
                    is_triplet_adj_fb = False
                    if val_fb < 9:
                        next_t = MahjongTile(suit_fb, val_fb + 1)
                        if tile_counts.get(next_t, 0) >= 3 and not MahjongTile(suit_fb, val_fb - 1) in tile_counts:
                            is_triplet_adj_fb = True
                    if val_fb > 1:
                        prev_t = MahjongTile(suit_fb, val_fb - 1)
                        if tile_counts.get(prev_t, 0) >= 3 and not MahjongTile(suit_fb, val_fb + 1) in tile_counts:
                            is_triplet_adj_fb = True
                    if is_triplet_adj_fb:
                        reasons.append("📐 五组理论：手牌超5组搭子，此牌连暗刻非有效搭子，优先拆")
                    else:
                        reasons.append("📐 五组理论：手牌超5组搭子，此牌所在愚型优先拆")
                else:
                    reasons.append("📐 五组理论：手牌超5组搭子，此牌所在愚型优先拆")
        elif five_block >= 5:
            reasons.append("📐 五组理论：手牌搭子偏多，可考虑拆此牌减组")
        
        # 5. 对子结构分析
        total_pairs = sum(1 for c in tile_counts.values() if c == 2)
        if pair_struct >= 7:
            reasons.append(f"📊 对子结构：当前{total_pairs}对，2对最优(碰一留一做雀头)，不该拆")
        elif pair_struct <= 2 and total_pairs >= 3 and count == 2:
            reasons.append(f"📊 对子结构：{total_pairs}对过多(3对效率最低)，可拆此对减负")
        
        # 6. 改良进张分析
        if improvement >= 7:
            reasons.append("💡 改良潜力极高，保留可拓宽进张路线")
        elif improvement >= 5:
            reasons.append("💡 有较好改良潜力，出后会减少改良路线")
        elif improvement >= 3:
            reasons.append("💡 有一定改良空间")
        elif improvement <= 1 and tile.suit != 'honor':
            reasons.append("💡 改良空间有限，切的代价低")
        
        # 7. 役种影响
        yaochu_count = sum(c for t, c in tile_counts.items() if t.is_yaochu())
        has_honor_triplet = any(c >= 3 and t.suit == 'honor' for t, c in tile_counts.items())
        
        if tile.is_yaochu():
            if has_honor_triplet:
                reasons.append("💡 有字牌暗刻不能做断幺，此幺九牌进张价值低")
            elif yaochu_count <= 3:
                reasons.append(f"💡 出此牌有助于做断幺九(剩余幺九{yaochu_count-1}张)")
        else:
            if yaochu_count == 0:
                reasons.append("💡 手牌已无幺九，断幺九成立")
        
        # 一杯口
        for suit in ['man', 'pin', 'sou']:
            suit_counts = Counter(t for t in hand if t.suit == suit)
            for val in range(1, 8):
                seq = [MahjongTile(suit, val), MahjongTile(suit, val+1), MahjongTile(suit, val+2)]
                if all(suit_counts.get(t, 0) >= 2 for t in seq):
                    if tile in seq:
                        reasons.append("💡 此牌在一杯口潜力中，出会破坏一杯口")
                    break
        
        # 8. 安全度分析
        if safety_score >= 8:
            disc_count = discarded_counter.get(tile, 0)
            reasons.append(f"🛡️ 安全度高：场上已出{disc_count}张，放铳风险极低")
        elif safety_score >= 5:
            disc_count = discarded_counter.get(tile, 0)
            reasons.append(f"🛡️ 较安全：场上已出{disc_count}张")
        elif safety_score <= 1:
            if tile.suit == 'honor':
                reasons.append("⚠️ 生张字牌：对手可能双碰听，防守慎打")
            else:
                reasons.append("⚠️ 生张数牌：放铳风险高，中盘后慎打")
        
        # 9. 场上出张统计与剩余枚数
        disc_count = discarded_counter.get(tile, 0)
        # 统别家碰杠占用的该牌数量
        meld_used = 0
        for pos in self.player_melds:
            if pos == self.turn_manager.get_my_position():
                continue
            for meld in self.player_melds[pos]:
                for t in meld.get('tiles', []):
                    if t == tile:
                        meld_used += 1
        total_used = disc_count + meld_used
        remaining = 4 - count - total_used  # 总4张 - 手中 - 场上已出 - 别家碰杠
        if total_used > 0:
            reason_str = f"📊 场上已出{disc_count}张"
            if meld_used > 0:
                reason_str += f"+别家碰杠{meld_used}张"
            reason_str += f"，剩余可摸约{remaining}张"
            if remaining <= 1:
                reason_str += "(几乎摸不到，进张价值极低)"
            elif remaining <= 2:
                reason_str += "(进张概率较低)"
            reasons.append(reason_str)
        else:
            reasons.append(f"📊 此牌场上未出现，剩余可摸约{remaining}张(生张)")
        
        # 10. 宝牌价值
        if tile.suit != 'honor' and tile.value == 5:
            reasons.append("💡 5数牌有赤宝牌进张价值")
        
        # 10.5 本局宝牌（dora）
        dora_tiles = self._get_current_dora_tiles()
        if tile in dora_tiles:
            if count >= 2:
                still_shuntsu = self._dora_redundant_in_pair(tile, hand, tile_counts)
                if still_shuntsu:
                    reasons.append("⭐ 宝牌对子中多余的牌：拆掉后手中仍留dora且形成顺子，不贪dora优先好形进张")
                else:
                    reasons.append("⭐ 此牌为本局宝牌(dora)对子，打出会损失宝牌价值")
            else:
                reasons.append("⭐ 此牌为本局宝牌(dora)，打出会损失宝牌价值")
        
        # 10.6 dora路线价值（该牌在等dora的坎张中）
        if tile.suit != 'honor' and dora_tiles:
            val = tile.value
            suit = tile.suit
            for dora in dora_tiles:
                if dora.suit != suit:
                    continue
                dora_val = dora.value
                if abs(val - dora_val) == 1:
                    partner_val = val + 2 if val < dora_val else val - 2
                    if 1 <= partner_val <= 9:
                        partner_tile = MahjongTile(suit, partner_val)
                        if partner_tile in tile_counts:
                            # 仅当同连续段中有对子可拆出造相离两坎时才显示
                            has_pair_in_seg = False
                            suit_vals_all = []
                            for t_all, c_all in tile_counts.items():
                                if t_all.suit == suit:
                                    suit_vals_all.extend([t_all.value] * c_all)
                            suit_vals_all.sort()
                            val_seg = [val]
                            if suit_vals_all:
                                for v in reversed(suit_vals_all):
                                    if v < val and val_seg[0] - v <= 2:
                                        val_seg.insert(0, v)
                                    elif v < val:
                                        break
                                for v in suit_vals_all:
                                    if v > val and v - val_seg[-1] <= 2:
                                        val_seg.append(v)
                                    elif v > val:
                                        break
                            for t2, c2 in tile_counts.items():
                                if t2.suit == suit and c2 == 2:
                                    if t2.value in val_seg:
                                        has_pair_in_seg = True
                                        break
                            if has_pair_in_seg:
                                reasons.append(f"⭐ 此牌在等dora({dora})的坎张中，拆掉会损失dora路线")
                                break
        
        # 10.7 三色同顺潜力
        if tile.suit != 'honor':
            for seq_val in range(1, 8):
                if tile.value < seq_val or tile.value > seq_val + 2:
                    continue
                potential_suits = []
                for check_suit in ['man', 'pin', 'sou']:
                    has_seq = True
                    for v in range(seq_val, seq_val + 3):
                        if tile_counts.get(MahjongTile(check_suit, v), 0) < 1:
                            has_seq = False
                            break
                    count_in_seq = sum(tile_counts.get(MahjongTile(check_suit, v), 0) for v in range(seq_val, seq_val + 3))
                    if has_seq or count_in_seq >= 2:
                        potential_suits.append(check_suit)
                    elif count_in_seq >= 1:
                        in_seq_tiles = [v for v in range(seq_val, seq_val + 3) if tile_counts.get(MahjongTile(check_suit, v), 0) >= 1]
                        for in_val in in_seq_tiles:
                            for offset in [-2, -1, 1, 2]:
                                partner_val = in_val + offset
                                if 1 <= partner_val <= 9 and partner_val not in range(seq_val, seq_val + 3):
                                    if tile_counts.get(MahjongTile(check_suit, partner_val), 0) >= 1:
                                        wait_val = (in_val + partner_val) // 2 if abs(in_val - partner_val) == 2 else None
                                        if abs(in_val - partner_val) == 2 and wait_val in range(seq_val, seq_val + 3):
                                            potential_suits.append(check_suit)
                                            break
                                        elif abs(in_val - partner_val) == 1:
                                            wait1 = min(in_val, partner_val) - 1
                                            wait2 = max(in_val, partner_val) + 1
                                            if wait1 in range(seq_val, seq_val + 3) or wait2 in range(seq_val, seq_val + 3):
                                                potential_suits.append(check_suit)
                                                break
                            if check_suit in potential_suits:
                                break
                if len(potential_suits) >= 2 and tile.suit in potential_suits:
                    reasons.append(f"🌈 参与三色同顺潜力({seq_val}-{seq_val+2})，拆后会损失三色机会")
                    break
        
        # 10.8 相离两坎含dora瞄准模式（独立检测，不依赖compound值）
        if tile.suit != 'honor' and tile_counts.get(tile, 0) == 2:
            has_sep_kana, has_dora_target = self._detect_separated_kana_pattern(tile, hand, tile_counts)
            if has_sep_kana and has_dora_target:
                reasons.append("📐 相离两坎含dora瞄准：拆对子造两坎(如24坎+79坎)，其中一坎瞄准dora，保留平和路线")
            elif has_sep_kana:
                reasons.append("📐 相离两坎：拆对子造两组独立坎张，改良路线宽")
        
        # 11. 复合型手牌结构分析
        if compound >= 8:
            if tile.suit != 'honor' and tile_counts.get(tile, 0) >= 3:
                # 三枚复合体（如6777p等暗刻+邻接牌）
                reasons.append("📐 三枚复合体：暗刻+邻接牌，提供大量改良+dora进张+雀头源，不该拆")
            else:
                reasons.append("📐 复合型结构：此牌在长连/完整顺子中，不该拆")
        elif compound >= 5:
            reasons.append("📐 复合型结构：此牌在复合搭子中，拆需谨慎")
        elif compound == 0:
            # compound=0 可能有多种原因，区分显示
            if tile.suit != 'honor' and tile_counts.get(tile, 0) == 2:
                # 对子拆掉后compound=0有两种情况
                val = tile.value
                suit = tile.suit
                # 检查是否是中膨型（对子在中间，拆后变完整顺子）
                suit_vals_list = []
                for t, c in tile_counts.items():
                    if t.suit == suit:
                        suit_vals_list.extend([t.value] * c)
                suit_vals_list.sort()
                # 找到该牌所在的段
                seg_of_tile = []
                if suit_vals_list:
                    current_s = [suit_vals_list[0]]
                    for i in range(1, len(suit_vals_list)):
                        if suit_vals_list[i] - suit_vals_list[i-1] <= 2:
                            current_s.append(suit_vals_list[i])
                        else:
                            if val in current_s:
                                seg_of_tile = current_s
                                break
                            current_s = [suit_vals_list[i]]
                    if not seg_of_tile and val in current_s:
                        seg_of_tile = current_s
                seg_unique = sorted(set(seg_of_tile))
                dup_val = val
                is_middle = (dup_val != seg_unique[0] and dup_val != seg_unique[-1]) if len(seg_unique) >= 3 else False
                
                # 相离两坎检测已移至10.8节独立检测，此处不再重复
                if is_middle:
                    reasons.append("📐 中膨型浮牌：对子拆掉后直接变完整顺子，释放雀头给其他强复合段")
                elif len(seg_unique) == 1:
                    # 孤立对子（段只有2张相同牌，无邻接连接）
                    block_count_now = self._count_blocks(hand, tile_counts)
                    if block_count_now >= 6:
                        reasons.append("📐 孤立对子超载：搭子超5组，拆此孤立对子直接减1搭解决超载，优于扔孤张")
                    else:
                        reasons.append("📐 三雀头拆对：对子拆掉后保留双坎张改良路线，三雀头最弱+五搭子时该拆")
                else:
                    reasons.append("📐 三雀头拆对：对子拆掉后保留双坎张改良路线，三雀头最弱+五搭子时该拆")
            else:
                # 双坎张负担中的孤张端
                reasons.append("📐 双坎张负担：此牌为坎张孤张端，拆掉消除一组愚型且不破坏核心结构")
        elif compound <= 4 and compound >= 3:
            # compound 3-4: 中膨型拆端点（留对子锁死雀头）或三枚复合孤立暗刻
            if tile.suit != 'honor' and tile_counts.get(tile, 0) >= 3:
                reasons.append("📐 孤立暗刻：无邻接牌的暗刻，改良空间有限")
            else:
                reasons.append("📐 中膨型端点：拆后留中间对子+搭子，会锁死雀头，不如拆对子")
        elif compound <= 2 and compound > 0:
            # 更详细的复合结构分析
            if tile.suit != 'honor':
                val = tile.value
                suit = tile.suit
                count = tile_counts.get(tile, 0)
                if count == 2:
                    # 检查是否是双亚两面复合体的中间对子（如78899s中8s）
                    # vs 四枚畸形块中的对子（如4468中4s）
                    suit_vals_list = []
                    for t, c in tile_counts.items():
                        if t.suit == suit:
                            suit_vals_list.extend([t.value] * c)
                    suit_vals_list.sort()
                    seg_of_tile = []
                    if suit_vals_list:
                        current_s = [suit_vals_list[0]]
                        for i in range(1, len(suit_vals_list)):
                            if suit_vals_list[i] - suit_vals_list[i-1] <= 2:
                                current_s.append(suit_vals_list[i])
                            else:
                                if val in current_s:
                                    seg_of_tile = current_s
                                    break
                                current_s = [suit_vals_list[i]]
                        if not seg_of_tile and val in current_s:
                            seg_of_tile = current_s
                    seg_unique = sorted(set(seg_of_tile))
                    dup_vals_in_seg = [v for v in seg_unique if seg_of_tile.count(v) >= 2]
                    # 双亚两面：2+对子+中间对子（如78899s）
                    is_middle_dup = (val != seg_unique[0] and val != seg_unique[-1]) if len(seg_unique) >= 3 else False
                    if len(dup_vals_in_seg) >= 2 and is_middle_dup:
                        reasons.append("📐 双亚两面拆中：双对子复合体中间对子，拆掉保留亚两面潜力+释放雀头给外部对子")
                    else:
                        reasons.append("📐 四枚畸形块：对子+坎张冗余结构，拆对子后形成两坎好形")
                else:
                    # 非对子牌compound=2：可能是暗刻旁孤张端、坎张孤张端连对子、或亚两面端点
                    # 检查是否是暗刻旁孤张端（连接到暗刻的端点牌）
                    is_triplet_adjacent_reason = False
                    has_n1_reason = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
                    has_p1_reason = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
                    if has_n1_reason and not has_p1_reason:
                        if tile_counts.get(MahjongTile(suit, val + 1), 0) >= 3:
                            is_triplet_adjacent_reason = True
                    if has_p1_reason and not has_n1_reason:
                        if tile_counts.get(MahjongTile(suit, val - 1), 0) >= 3:
                            is_triplet_adjacent_reason = True
                    
                    if is_triplet_adjacent_reason:
                        reasons.append("📐 暗刻旁孤张端：连接到暗刻的端点牌，拆掉不影响暗刻+核心结构")
                    else:
                        # 检查是否是坎张孤张端连对子（如7-99m中7m）
                        is_kana_to_pair_reason = False
                        has_n2_reason = MahjongTile(suit, val + 2) in tile_counts if val < 8 else False
                        has_p2_reason = MahjongTile(suit, val - 2) in tile_counts if val > 2 else False
                        if has_n2_reason and tile_counts.get(MahjongTile(suit, val + 2), 0) >= 2:
                            is_kana_to_pair_reason = True
                        if has_p2_reason and tile_counts.get(MahjongTile(suit, val - 2), 0) >= 2:
                            is_kana_to_pair_reason = True
                        
                        if is_kana_to_pair_reason:
                            reasons.append("📐 坎张孤张端连对子：通过坎张连接到对子，拆掉释放对子做雀头")
                        else:
                            reasons.append("📐 复合型结构：此牌为亚两面端点，拆后保留对子+搭子")
        
        return reasons
    
    def _generate_discard_reasons(self, tile, count, shanten_change, 
                                   connectivity, type_value, advance_loss, 
                                   hand, tile_counts):
        """生成多样化的出牌推荐理由"""
        reasons = []
        
        # 1. 向听数影响
        if shanten_change > 0:
            reasons.append("❌ 出后向听数增加，会变差")
        elif shanten_change == 0:
            reasons.append("✅ 不影响向听数")
        
        # 2. 连接性分析
        if tile.suit == 'honor':
            if count == 1:
                reasons.append("📌 单张字牌，无连接价值")
            elif count == 2:
                reasons.append("📌 对子字牌，可碰可留")
            elif count >= 3:
                reasons.append("📌 刻子字牌，役牌价值高")
        else:
            if connectivity <= 2:
                reasons.append("📌 孤立牌，周围无连接")
            elif connectivity <= 4:
                # 检查具体连接情况
                val = tile.value
                suit = tile.suit
                has_prev = MahjongTile(suit, val - 1) in tile_counts if val > 1 else False
                has_next = MahjongTile(suit, val + 1) in tile_counts if val < 9 else False
                if has_prev and has_next:
                    reasons.append(f"📌 两面搭子，可进{val-1}或{val+1}")
                elif has_prev or has_next:
                    reasons.append("📌 边张搭子，进张面窄")
                else:
                    reasons.append("📌 弱连接，有间隔牌")
            else:
                reasons.append("📌 强连接牌，是面子核心")
        
        # 3. 牌型价值分析
        if tile.suit == 'honor':
            honor_name = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}[tile.value]
            if tile.value in [5, 6, 7]:
                if count >= 3:
                    reasons.append(f"📌 {honor_name}刻子=役牌，不建议出")
                elif count == 2:
                    reasons.append(f"📌 {honor_name}对子，碰了就有役")
                else:
                    reasons.append(f"📌 单张{honor_name}，无役牌价值")
            else:
                player_wind = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind = self.round_wind_var.get()
                is_yakuhai = (honor_name == player_wind or honor_name == round_wind)
                if is_yakuhai and count >= 2:
                    reasons.append(f"📌 {honor_name}是场风/自风，碰了有役")
                elif count >= 3:
                    reasons.append(f"📌 {honor_name}刻子，可做役牌")
                elif count == 1:
                    reasons.append(f"📌 单张{honor_name}风牌，非场风自风")
        else:
            val = tile.value
            if val in [1, 9]:
                if count == 1:
                    reasons.append("📌 老头牌单张，做牌效率低")
                elif count == 2:
                    reasons.append("📌 老头牌对子，可碰但范围窄")
            elif val in [2, 8]:
                if count == 1:
                    reasons.append("📌 边张牌，只能做边张搭子")
            elif val in [3, 4, 5, 6, 7]:
                if count >= 3:
                    reasons.append("📌 中张刻子，做牌核心")
                elif count == 2:
                    reasons.append("📌 中张对子，进张面宽")
                else:
                    reasons.append("📌 中张单张，进张潜力大")
        
        # 4. 进张损失
        if advance_loss >= 8:
            reasons.append("⚠️ 出后大幅减少进张路径")
        elif advance_loss >= 5:
            reasons.append("⚠️ 出后减少部分进张路径")
        elif advance_loss <= 2:
            reasons.append("✅ 出后对进张影响小")
        
        # 5. 做牌方向影响
        # 检查是否影响断幺九
        yaochu_count = sum(c for t, c in tile_counts.items() if t.is_yaochu())
        if tile.is_yaochu() and yaochu_count <= 2:
            reasons.append("💡 出此牌有助于做断幺九")
        
        # 检查是否影响清一色/混一色
        suits_present = set(t.suit for t in hand if t.suit != 'honor')
        if len(suits_present) == 2 and tile.suit != 'honor':
            # 出这个花色的牌有助于集中到另一种
            other_suit_count = sum(c for t, c in tile_counts.items() if t.suit != tile.suit and t.suit != 'honor')
            if other_suit_count > sum(c for t, c in tile_counts.items() if t.suit == tile.suit):
                reasons.append("💡 出此牌有助于集中花色做混一色")
        
        return reasons
    
    def _evaluate_connectivity(self, tile, hand, tile_counts):
        """评估牌的连接性（0-10分，越高越不该出）"""
        if tile.suit == 'honor':
            count = tile_counts.get(tile, 0)
            if count >= 3:
                return 10
            elif count == 2:
                return 6
            else:
                return 0
        
        score = 0
        val = tile.value
        suit = tile.suit
        
        for offset in [-2, -1, 1, 2]:
            neighbor_val = val + offset
            if 1 <= neighbor_val <= 9:
                neighbor = MahjongTile(suit, neighbor_val)
                if neighbor in tile_counts:
                    dist = abs(offset)
                    if dist == 1:
                        score += 3
                    else:
                        score += 1
        
        same_suit_count = sum(c for t, c in tile_counts.items() if t.suit == suit)
        if same_suit_count >= 5:
            score += 2
        
        count = tile_counts.get(tile, 0)
        if count >= 3:
            score += 5
        elif count == 2:
            score += 3
        
        return min(score, 10)
    
    def _evaluate_tile_type_value(self, tile, count, hand=None, tile_counts=None):
        """评估牌型价值（0-10分，越高越不该出）"""
        if tile.suit == 'honor':
            if tile.value in [5, 6, 7]:  # 白发中
                if count >= 3: return 10
                elif count == 2: return 7
                else: return 2
            else:  # 风牌
                player_wind_name = self.turn_manager.wind_names.get(self.turn_manager.get_my_position(), '')
                round_wind_name = self.round_wind_var.get()
                wind_map = {'东': 1, '南': 2, '西': 3, '北': 4}
                if tile.value == wind_map.get(player_wind_name) or tile.value == wind_map.get(round_wind_name):
                    if count >= 3: return 9
                    elif count == 2: return 6
                    else: return 3
                else:
                    if count >= 3:
                        # 客风暗刻：检查是否在搭子超载+可激活断幺九路线
                        if hand is not None and tile_counts is not None:
                            block_count = self._count_blocks(hand, tile_counts)
                            if block_count >= 6:
                                yaochu_after = sum(c for t, c in tile_counts.items() if t.is_yaochu()) - 1
                                if yaochu_after <= 3:
                                    return 2  # 拆客风暗刻激活断幺九，该出
                        return 7
                    elif count == 2: return 4
                    else: return 1
        
        val = tile.value
        if val in [1, 9]:
            if count >= 3: return 8
            elif count == 2: return 4
            else: return 1
        elif val in [2, 8]:
            if count >= 3: return 7
            elif count == 2: return 5
            else: return 3
        else:
            if count >= 3: return 9
            elif count == 2: return 6
            else: return 5
    
    def _evaluate_advance_loss(self, tile, original_hand, sim_hand):
        """评估出牌后进张路径损失（0-10分）"""
        orig_shanten = WinProbabilityCalculator.calculate_shanten(original_hand)
        new_shanten = WinProbabilityCalculator.calculate_shanten(sim_hand)
        
        if new_shanten > orig_shanten:
            return 10
        
        orig_waiting = self._count_effective_tiles(original_hand)
        new_waiting = self._count_effective_tiles(sim_hand)
        
        loss = orig_waiting - new_waiting
        return min(max(loss * 2, 0), 10)
    
    def _count_effective_tiles(self, hand):
        """计算有效进张数"""
        count = 0
        tile_counts = Counter(hand)
        
        for tile in tile_counts:
            if tile.suit == 'honor':
                if tile_counts[tile] == 2:
                    count += 2
            else:
                val = tile.value
                suit = tile.suit
                if tile_counts[tile] == 2:
                    count += 2
                if tile_counts[tile] == 1:
                    count += 3
                if val <= 7:
                    t2 = MahjongTile(suit, val + 1)
                    t3 = MahjongTile(suit, val + 2)
                    if t2 in tile_counts and t3 not in tile_counts:
                        count += 1
                if val >= 3:
                    t2 = MahjongTile(suit, val - 1)
                    t3 = MahjongTile(suit, val - 2)
                    if t2 in tile_counts and t3 not in tile_counts:
                        count += 1
        return count
    
    def _declare_win(self):
        """宣布和牌"""
        messagebox.showinfo("和牌", "🎉 恭喜和牌！")
        self.event_logger.log_event('win', self.turn_manager.get_my_position(), details={'action': 'declare_win'})
    
    def _show_event_log(self):
        """显示事件日志"""
        log_window = tk.Toplevel(self.root)
        log_window.title("事件日志")
        log_window.geometry("600x400")
        
        text_widget = scrolledtext.ScrolledText(
            log_window,
            font=('Courier', 10)
        )
        text_widget.pack(fill='both', expand=True)
        
        for event in self.event_logger.events:
            timestamp = event['timestamp'][11:19]  # 只显示时分秒
            event_type = event['type']
            actor = event['actor']
            tile = event.get('tile', '')
            action = event.get('details', {}).get('action', '')
            
            text_widget.insert(tk.END, f"[{timestamp}] {event_type}: {actor} {tile} ({action})\n")
    
    def _update_button_states(self):
        """更新按钮状态"""
        # 可以根据游戏状态启用/禁用某些按钮
        current_pos = self.turn_manager.current_turn
        my_pos = self.turn_manager.get_my_position()
        
        # 如果是我的回合，启用相关按钮
        is_my_turn = current_pos == my_pos
        
        state = 'normal' if is_my_turn else 'disabled'
        
        # 注意：这里只是示例，实际中需要找到具体的按钮组件
        # 由于代码复杂度，我们在基本功能中简化此逻辑
        pass
    
    def _analyze_meld_opportunities(self, discarded_tile, source_position):
        """分析碰杠吃机会"""
        pass  # 简化版本，实际可以分析其他玩家是否可以碰杠
    
    def _clear_analysis_display(self):
        """清空分析显示"""
        self.analysis_text.delete(1.0, tk.END)
    
    def _on_wind_changed(self, event=None):
        """当风位改变时更新"""
        player_wind = self.player_wind_var.get()
        round_wind = self.round_wind_var.get()
        is_dealer = self.is_dealer_var.get()
        
        # 设置玩家风位
        self.turn_manager.set_player_wind(player_wind)
        self.turn_manager.set_dealer_status(is_dealer)
        
        # 更新风位关系显示
        self._update_wind_relations_display()
        self._update_current_position_display()
        
        # 更新工作日志
        self._update_work_log(f"风位设置: 自风[{player_wind}] 场风[{round_wind}] 庄家[{'是' if is_dealer else '否'}]")
    
    def _start_new_game(self):
        """开始新游戏"""
        # 重置所有状态
        self.turn_manager.reset_game()
        
        # 清空所有手牌
        for pos in self.player_hands:
            self.player_hands[pos] = []
            self.public_discards[pos] = []
            self.player_melds[pos] = []
        
        # 清空显示
        self._update_hand_display()
        self._update_discard_combo()
        self._update_meld_display()
        self.analysis_text.delete(1.0, tk.END)
        self.auto_status_text.delete(1.0, tk.END)
        
        # 清空dora指示牌设置
        self.current_dora_indicators = []
        if hasattr(self, 'dora_display_var'):
            self.dora_display_var.set("宝牌: 未设置")
        
        # 将回合设为自己的位置，方便先输入手牌
        # 等点"开始"后再交给东家出牌
        self.turn_manager.reset_rotation()
        
        # 更新显示
        self._update_current_position_display()
        self._update_button_states()
        
        # 记录新游戏开始
        self.event_logger = EnhancedEventLogger()
        self.event_logger.log_event('new_game', 'system', details={'player_wind': self.player_wind_var.get()})
        
        self._update_work_log("🎮 新游戏开始! 请输入手牌，然后点'开始'")
        
        messagebox.showinfo("新游戏", "已重置游戏状态！\n请输入手牌，然后点'开始'按钮开始游戏。")

    @staticmethod
    def _calc_dora_from_indicator(indicator):
        """根据dora指示牌计算实际宝牌
        
        日麻规则：指示牌的"下一张"即为宝牌
        - 数牌1-8: +1 (如指示3万→宝牌4万)
        - 数牌9: 绕回1 (如指示9万→宝牌1万)
        - 风牌: 东→南→西→北→东 (循环)
        - 三元牌: 白→发→中→白 (循环)
        """
        if indicator.suit == 'honor':
            val = indicator.value
            if val <= 4:  # 风牌 东西南北
                return MahjongTile('honor', val % 4 + 1)
            else:  # 三元牌 白发中
                return MahjongTile('honor', (val - 5) % 3 + 5)
        else:
            # 数牌
            new_val = indicator.value + 1
            if new_val > 9:
                new_val = 1
            return MahjongTile(indicator.suit, new_val)
    
    def _get_current_dora_tiles(self):
        """根据当前dora指示牌列表，计算所有实际宝牌列表"""
        return [self._calc_dora_from_indicator(ind) for ind in self.current_dora_indicators]
    
    def _select_dora_tiles(self):
        """选择本局dora指示牌 - 弹出选择窗口"""
        popup = tk.Toplevel(self.root)
        popup.title("选择宝牌指示牌")
        popup.geometry("420x480")
        popup.transient(self.root)
        popup.grab_set()
        
        ttk.Label(popup, text="选择本局宝牌指示牌（表宝牌指示牌）", font=('Arial', 11, 'bold')).pack(pady=8)
        ttk.Label(popup, text="选定后程序自动计算实际宝牌", font=('Arial', 9)).pack()
        
        # 预览标签
        dora_preview_var = tk.StringVar(value="宝牌: 未设置")
        dora_preview_label = ttk.Label(popup, textvariable=dora_preview_var, font=('Arial', 10, 'bold'), foreground='red')
        dora_preview_label.pack(pady=5)
        
        # 构建所有牌的列表
        all_tiles = []
        for suit in ['man', 'pin', 'sou']:
            for val in range(1, 10):
                all_tiles.append(MahjongTile(suit, val))
        for val in range(1, 8):
            all_tiles.append(MahjongTile('honor', val))
        
        # 复选框变量
        check_vars = {}
        
        # 万子
        man_frame = ttk.LabelFrame(popup, text="万", padding="3")
        man_frame.pack(fill="x", padx=5, pady=2)
        for i, tile in enumerate(all_tiles[:9]):
            var = tk.BooleanVar()
            check_vars[tile] = var
            ttk.Checkbutton(man_frame, text=str(tile), variable=var).grid(row=i//5, column=i%5, padx=2, pady=1)
        
        # 筒子
        pin_frame = ttk.LabelFrame(popup, text="筒", padding="3")
        pin_frame.pack(fill="x", padx=5, pady=2)
        for i, tile in enumerate(all_tiles[9:18]):
            var = tk.BooleanVar()
            check_vars[tile] = var
            ttk.Checkbutton(pin_frame, text=str(tile), variable=var).grid(row=i//5, column=i%5, padx=2, pady=1)
        
        # 条子
        sou_frame = ttk.LabelFrame(popup, text="条", padding="3")
        sou_frame.pack(fill="x", padx=5, pady=2)
        for i, tile in enumerate(all_tiles[18:27]):
            var = tk.BooleanVar()
            check_vars[tile] = var
            ttk.Checkbutton(sou_frame, text=str(tile), variable=var).grid(row=i//5, column=i%5, padx=2, pady=1)
        
        # 字牌
        honor_frame = ttk.LabelFrame(popup, text="字", padding="3")
        honor_frame.pack(fill="x", padx=5, pady=2)
        for i, tile in enumerate(all_tiles[27:]):
            var = tk.BooleanVar()
            check_vars[tile] = var
            ttk.Checkbutton(honor_frame, text=str(tile), variable=var).grid(row=0, column=i, padx=2, pady=1)
        
        # 如果已有选中的指示牌，回显
        for tile in self.current_dora_indicators:
            if tile in check_vars:
                check_vars[tile].set(True)
        
        def update_preview():
            selected = [tile for tile, var in check_vars.items() if var.get()]
            if selected:
                dora_tiles = [self._calc_dora_from_indicator(t) for t in selected]
                dora_str = ' '.join(str(t) for t in dora_tiles)
                dora_preview_var.set(f"宝牌: {dora_str}")
            else:
                dora_preview_var.set("宝牌: 未设置")
        
        # 绑定复选框变化事件来更新预览
        for var in check_vars.values():
            var.trace_add('write', lambda *_: update_preview())
        update_preview()
        
        def do_confirm():
            self.current_dora_indicators = [tile for tile, var in check_vars.items() if var.get()]
            dora_tiles = self._get_current_dora_tiles()
            if dora_tiles:
                dora_str = ' '.join(str(t) for t in dora_tiles)
                self.dora_display_var.set(f"宝牌: {dora_str}")
            else:
                self.dora_display_var.set("宝牌: 未设置")
            ind_str = ' '.join(str(t) for t in self.current_dora_indicators) if self.current_dora_indicators else '未设置'
            self._update_work_log(f"宝牌指示牌设置: {ind_str} → 宝牌: {dora_str if dora_tiles else '未设置'}")
            popup.destroy()
        
        btn_frame = ttk.Frame(popup)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="确定", command=do_confirm).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="取消", command=popup.destroy).pack(side="left", padx=5)

    def _start_game(self):
        """开始按钮：手牌输入完成后，将出牌权交给庄家（东家）"""
        # 庄家始终是东家，设置当前轮到东家出牌
        self.turn_manager.current_turn = 'east'
        # 更新显示
        self._update_current_position_display()
        self._update_discard_combo()
        is_dealer = self.is_dealer_var.get()
        if is_dealer:
            self._update_work_log("▶ 游戏开始！我是庄家(东家)，轮到我出牌")
        else:
            self._update_work_log("▶ 游戏开始！庄家(东家)先出牌，等待记录")

    def _show_about(self):
        """关于按钮：弹出说明窗口，显示项目信息"""
        about_win = tk.Toplevel(self.root)
        about_win.title("关于")
        about_win.geometry("420x220")
        about_win.resizable(False, False)
        about_win.transient(self.root)
        about_win.grab_set()

        tk.Label(about_win, text="日麻记牌器增强版 v3.2", font=('Arial', 16, 'bold')).pack(pady=(20, 5))
        tk.Label(about_win, text="基于何切实战理论的智能出牌分析工具", font=('Arial', 10)).pack(pady=2)

        link_frame = tk.Frame(about_win)
        link_frame.pack(pady=15)
        tk.Label(link_frame, text="GitHub 项目地址：", font=('Arial', 10)).pack(side="left")
        link_label = tk.Label(link_frame, text="https://github.com/qiumingyue034-byte/-", font=('Arial', 10), fg="#0066cc", cursor="hand2")
        link_label.pack(side="left")
        link_label.bind("<Button-1>", lambda e: self._open_url("https://github.com/qiumingyue034-byte/-"))

        tk.Button(about_win, text="关闭", command=about_win.destroy, width=10).pack(pady=15)

    @staticmethod
    def _open_url(url):
        """用系统默认浏览器打开URL"""
        import webbrowser
        webbrowser.open(url)

    def _update_wind_relations_display(self):
        """更新风位关系显示"""
        if not hasattr(self, 'wind_relations_text'):
            return
            
        positions = self.turn_manager.get_relative_positions()
        wind_names = self.turn_manager.wind_names
        
        self.wind_relations_text.config(state='normal')
        self.wind_relations_text.delete(1.0, tk.END)
        
        self.wind_relations_text.insert(tk.END, "=== 风位关系 ===\n\n")
        
        # 显示关系
        relations = self.wind_analyzer.get_wind_relations(
            self.player_wind_var.get(),
            self.round_wind_var.get()
        )
        
        for key, value in relations.items():
            self.wind_relations_text.insert(tk.END, f"{key}: {value}\n")
        
        # 显示位置对应
        self.wind_relations_text.insert(tk.END, "\n=== 位置对应 ===\n\n")
        
        for pos_key, pos_value in positions.items():
            wind_name = wind_names[pos_value]
            self.wind_relations_text.insert(tk.END, f"{pos_key}: {wind_name}家\n")
        
        self.wind_relations_text.config(state='disabled')
    
    def _next_player(self):
        """下一位玩家"""
        current = self.turn_manager.current_turn
        next_pos = self.turn_manager.next_turn_normal()
        
        # 记录事件
        self.event_logger.log_event('turn_change', next_pos, details={
            'previous': current,
            'action': 'manual_next'
        })
        
        self._update_current_position_display()
        self._update_button_states()
        
        next_name = self.turn_manager.wind_names[next_pos]
        self._update_work_log(f"⏭️ 手动轮换: {current}家 → {next_name}家")
        
        # 如果轮到我，提示录入
        if next_pos == self.turn_manager.get_my_position():
            self._handle_my_turn()
        
        messagebox.showinfo("轮换", f"轮到{next_name}家")
    
    def _reset_rotation(self):
        """重置轮换到第一位"""
        self.turn_manager.reset_rotation()
        self._update_current_position_display()
        self._update_button_states()
        
        first_player = self.turn_manager.wind_names[self.turn_manager.current_turn]
        self._update_work_log(f"🔄 重置轮换到第一位: {first_player}家")
        
        messagebox.showinfo("重置", f"已重置轮换到第一位玩家: {first_player}家")
    
    def _start_auto_rotation(self):
        """启动自动轮换系统"""
        if self.setup_auto_rotation_system not in self.__dict__:
            self.setup_auto_rotation_system()
            
        self.auto_rotation_enabled = True
        self._update_auto_rotation_display()
        self._schedule_next_auto_rotation()
        
        self._update_work_log("🤖 自动轮换已启动")
        messagebox.showinfo("自动轮换", "已启动自动轮换系统，将按顺序为四家自动记录！")
    
    def _stop_auto_rotation(self):
        """停止自动轮换系统"""
        self.auto_rotation_enabled = False
        if hasattr(self, 'auto_rotation_after_id'):
            self.root.after_cancel(self.auto_rotation_after_id)
        
        self._update_auto_rotation_display()
        self._update_work_log("⏸️ 自动轮换已停止")
        messagebox.showinfo("自动轮换", "已停止自动轮换系统")
    
    def _schedule_next_auto_rotation(self):
        """安排下一次自动轮换"""
        if not self.auto_rotation_enabled:
            return
            
        # 取消之前的调度
        if hasattr(self, 'auto_rotation_after_id'):
            self.root.after_cancel(self.auto_rotation_after_id)
        
        # 安排下一次轮换
        self.auto_rotation_after_id = self.root.after(
            self.rotation_speed, 
            self._perform_auto_rotation
        )
    
    def _perform_auto_rotation(self):
        """执行自动轮换"""
        if not self.auto_rotation_enabled:
            return
            
        # 检查是否有强制轮换事件（碰杠吃）
        if self.forced_meld_change:
            self.forced_meld_change = False
            # 继续执行碰杠吃后的轮换逻辑
            self._handle_auto_rotation_for_meld()
            return
        
        # 正常轮换
        current_pos = self.turn_manager.current_turn
        next_pos = self.turn_manager.next_turn_normal()
        
        # 更新显示和状态
        self._update_current_position_display()
        self._update_button_states()
        self._update_auto_rotation_display()
        
        # 记录轮换事件
        next_wind = self.turn_manager.wind_names[next_pos]
        self._update_work_log(f"🔄 自动轮换: {current_pos}家 → {next_wind}家")
        
        # 如果轮到我，进行特殊处理
        if next_pos == self.turn_manager.get_my_position():
            self._handle_auto_my_turn()
        
        # 安排下一次轮换
        self._schedule_next_auto_rotation()
    
    def _handle_auto_my_turn(self):
        """处理我的回合（在自动轮换中）- 增强版自动出牌逻辑"""
        my_pos = self.turn_manager.get_my_position()
        current_hand = self.player_hands[my_pos]
        
        # 如果手牌为空，先生成初始手牌（13张）
        if len(current_hand) == 0:
            self._generate_random_hand()
            return
            
        # 摸一张新牌（模拟摸牌）
        all_tiles = []
        for suit in ['man', 'pin', 'sou']:
            for value in range(1, 10):
                all_tiles.append(MahjongTile(suit, value))
        for value in range(1, 8):  # 字牌
            all_tiles.append(MahjongTile('honor', value))
        
        import random
        random.shuffle(all_tiles)
        new_tile = all_tiles[0]
        
        # 添加到当前手牌
        current_hand.append(new_tile)
        self._update_hand_display()
        self._update_discard_combo()
        
        # 记录摸牌事件
        self.event_logger.log_event('draw', my_pos, new_tile, details={'action': 'auto_draw'})
        
        # 提示和自动分析
        self._update_work_log(f"🎲 自动摸牌: {new_tile}")
        analysis_result = self._perform_hand_analysis(current_hand)
        
        # 自动选择最佳出牌
        if len(current_hand) == 14:  # 摸牌后应该是14张
            # 基于分析结果选择要出的牌
            tile_to_discard = self._select_best_discard_tile(current_hand, analysis_result)
            if tile_to_discard:
                # 自动出牌
                self._auto_discard_tile(tile_to_discard, my_pos)
            else:
                # 如果没有找到合适的牌，选择第一张
                tile_to_discard = current_hand[0]
                self._auto_discard_tile(tile_to_discard, my_pos)
        
    def _select_best_discard_tile(self, hand, analysis_result):
        """基于分析结果选择最佳出牌"""
        if not hand:
            return None
            
        # 简化的出牌策略
        tile_counts = Counter(hand)
        
        # 1. 优先出单张字牌（没有配对的）
        single_honors = [tile for tile, count in tile_counts.items() 
                        if tile.suit == 'honor' and count == 1]
        if single_honors:
            return single_honors[0]
        
        # 2. 优先出边张（1、9）的单张
        single_terminals = [tile for tile, count in tile_counts.items() 
                           if tile.suit != 'honor' and count == 1 and (tile.value == 1 or tile.value == 9)]
        if single_terminals:
            return single_terminals[0]
        
        # 3. 优先出单张
        single_tiles = [tile for tile, count in tile_counts.items() if count == 1]
        if single_tiles:
            return single_tiles[0]
        
        # 4. 如果没有单张，出一张重复的牌
        return hand[0]
    
    def _auto_discard_tile(self, tile_to_discard, my_pos):
        """自动出牌"""
        hand = self.player_hands[my_pos]
        
        # 从手牌移除
        hand.remove(tile_to_discard)
        
        # 添加到公开舍牌池
        self.public_discards[my_pos].append(tile_to_discard)
        
        # 记录事件
        self.event_logger.log_event('discard', my_pos, tile_to_discard, details={
            'action': 'auto_discard',
            'hand_count_before': len(hand) + 1,
            'hand_count_after': len(hand)
        })
        
        # 分析碰杠吃机会
        self._analyze_meld_opportunities(tile_to_discard, my_pos)
        
        # 正常轮换到下一个玩家
        next_player = self.turn_manager.next_turn_normal()
        
        # 更新显示
        self._update_hand_display()
        self._update_discard_combo()
        self._update_current_position_display()
        self._update_button_states()
        
        # 更新工作日志
        next_pos_name = self.turn_manager.wind_names[next_player]
        self._update_work_log(f"🃏 自动出牌: {tile_to_discard} ➜ 轮到下家({next_pos_name}家)")
        
        # 短暂提示自动出牌
        self._show_auto_action_message(f"自动出牌: {tile_to_discard}")
    
    def _show_auto_action_message(self, message):
        """显示自动操作消息（无阻塞）"""
        # 创建一个临时显示，2秒后自动消失
        temp_window = tk.Toplevel(self.root)
        temp_window.title("自动操作")
        temp_window.geometry("300x100")
        temp_window.attributes("-topmost", True)
        
        ttk.Label(temp_window, text=message, font=('Arial', 12)).pack(pady=20)
        
        # 2秒后自动关闭
        self.root.after(2000, temp_window.destroy)
        
    def _handle_auto_rotation_for_meld(self):
        """处理碰杠吃后的自动轮换"""
        # 重置强制轮换标记
        self.forced_meld_change = False
        
        # 碰杠吃后，轮到操作家继续
        if self.turn_manager.current_turn == self.turn_manager.get_my_position():
            self._handle_auto_my_turn()
        
        # 安排下一次轮换
        self._schedule_next_auto_rotation()
    
    def _update_auto_rotation_display(self):
        """更新自动轮换状态显示"""
        self.auto_status_text.config(state='normal')
        self.auto_status_text.delete(1.0, tk.END)
        
        status = "✅ 已启用" if self.auto_rotation_enabled else "❌ 已停止"
        mode = "一轮模式" if self.rotation_mode == 'round' else "无限模式"
        
        self.auto_status_text.insert(tk.END, f"自动轮换状态: {status}\n")
        self.auto_status_text.insert(tk.END, f"当前模式: {mode}\n\n")
        
        current_wind = self.turn_manager.wind_names[self.turn_manager.current_turn]
        my_wind = self.turn_manager.wind_names[self.turn_manager.get_my_position()]
        
        self.auto_status_text.insert(tk.END, f"当前轮到: {current_wind}家\n")
        self.auto_status_text.insert(tk.END, f"我是: {my_wind}家\n\n")
        
        if self.auto_rotation_enabled:
            self.auto_status_text.insert(tk.END, f"下次轮换剩余: {self.rotation_speed/1000}秒\n")
        
        self.auto_status_text.config(state='disabled')


def main():
    """主函数"""
    app = CompleteMahjongRecordEnhancedGUI()
    app.root.mainloop()

if __name__ == "__main__":
    main()