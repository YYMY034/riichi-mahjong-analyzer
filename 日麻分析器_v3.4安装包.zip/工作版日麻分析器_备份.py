#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整版日麻分析器
基于改进版增加：
- 三家出牌记录功能（记牌器）
- 碰杠吃建议系统
- 智能防守分析

使用方法：通过模式切换按钮选择输入对象
"""

import tkinter as tk
from tkinter import ttk, messagebox
import random
from collections import Counter
import time
import threading
import math

# 导入分析模块
from mahjong_analyzer_complete import MahjongTile, YakuAnalyzer, WinProbabilityCalculator
from 增强版出牌分析器 import get_enhanced_discard_advice
from wind_analyzer import WindAnalyzer

class FireworksAnimation:
    """烟花动画类"""
    
    def __init__(self, canvas):
        self.canvas = canvas
        self.particles = []
        self.active = False
        
    def create_burst(self, x, y, color):
        """在指定位置创建烟花爆炸效果"""
        num_particles = random.randint(20, 30)
        for _ in range(num_particles):
            angle = random.uniform(0, 2 * 3.14159)
            speed = random.uniform(2, 6)
            vx = speed * math.cos(angle)
            vy = speed * math.sin(angle)
            life = random.randint(40, 60)
            size = random.randint(2, 4)
            
            self.particles.append({
                'x': x, 'y': y,
                'vx': vx, 'vy': vy,
                'life': life, 'max_life': life,
                'color': color, 'size': size,
                'alpha': 1.0
            })
    
    def update(self):
        """更新烟花粒子"""
        for particle in self.particles[:]:
            # 更新位置
            particle['x'] += particle['vx']
            particle['y'] += particle['vy']
            particle['vy'] += 0.1  # 重力
            
            # 更新生命周期
            particle['life'] -= 1
            particle['alpha'] = particle['life'] / particle['max_life']
            
            # 移除死亡粒子
            if particle['life'] <= 0:
                self.particles.remove(particle)
        
        self.draw()
        
        # 如果有活动粒子，继续更新
        if self.particles:
            self.canvas.after(50, self.update)
    
    def draw(self):
        """绘制烟花粒子"""
        # 清除画布
        self.canvas.create_rectangle(0, 0, self.canvas.winfo_width(), self.canvas.winfo_height(), fill="black", outline="black")
        
        for particle in self.particles:
            x, y = particle['x'], particle['y']
            size = particle['size']
            alpha = particle['alpha']
            
            # 根据alpha调整颜色亮度
            if alpha > 0:
                color = particle['color']
                # 创建有透明效果的烟花
                self.canvas.create_oval(
                    x - size, y - size, x + size, y + size,
                    fill=color, outline=color, width=0
                )

class ImprovedMahjongGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("日麻分析器 (改进版)")
        self.root.geometry("1000x800")
        
        # 当前手牌
        self.current_hand = []
        self.fireworks = None
        
        # 创建界面
        self._setup_ui()
        
    def _setup_ui(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=("nsew"))
        
        # 手牌输入区域
        hand_frame = ttk.LabelFrame(main_frame, text="📋 手牌输入", padding="10")
        hand_frame.grid(row=0, column=0, sticky=("ew"), pady=5)
        
        # 当前手牌显示
        self.hand_display = tk.Text(hand_frame, height=2, width=90, wrap="char")
        self.hand_display.grid(row=0, column=0, columnspan=20, pady=(0, 10), sticky="ew")
        
        # 数牌按钮 (万筒条)
        row = 1
        col = 0
        for idx, (suit, suit_name) in enumerate([('man', '万'), ('pin', '筒'), ('sou', '条')]):
            ttk.Label(hand_frame, text=f"{suit_name}:").grid(row=row, column=col, sticky="w")
            col += 1
            for num in range(1, 10):
                btn = ttk.Button(hand_frame, text=str(num), width=2,
                               command=lambda s=suit, n=num: self._add_tile(s, n))
                btn.grid(row=row, column=col, padx=1)
                col += 1
            row += 1
            col = 0
        
        # 字牌按钮 - 仅中文显示，无1234567
        honor_names = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}
        ttk.Label(hand_frame, text="字:").grid(row=1, column=10, sticky="w")
        col = 11
        for num, name in honor_names.items():
            btn = ttk.Button(hand_frame, text=name, width=2,
                           command=lambda n=num: self._add_tile('honor', n))
            btn.grid(row=1, column=col, padx=1)
            col += 1
            
        # 控制按钮
        ctrl_frame = ttk.Frame(hand_frame)
        ctrl_frame.grid(row=6, column=0, columnspan=20, pady=10)
        ttk.Button(ctrl_frame, text="清空", command=self._clear_hand).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="随机13张", command=self._generate_random_hand).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="删除牌", command=self._delete_tile).pack(side="left", padx=3)
        
        # 环境设置
        env_frame = ttk.LabelFrame(main_frame, text="🌍 环境设置", padding=10)
        env_frame.grid(row=1, column=0, sticky="ew", pady=5)
        ttk.Label(env_frame, text="门风:").grid(row=0, column=0)
        self.player_wind = ttk.Combobox(env_frame, values=["东", "南", "西", "北"], width=5)
        self.player_wind.set("东"); self.player_wind.grid(row=0, column=1)
        ttk.Label(env_frame, text="场风:").grid(row=0, column=2)
        self.round_wind = ttk.Combobox(env_frame, values=["东", "南", "西", "北"], width=5)
        self.round_wind.set("东"); self.round_wind.grid(row=0, column=3)
        self.dealer_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(env_frame, text="庄家", variable=self.dealer_var).grid(row=0, column=4)
        
        # 分析按钮和控制
        btn_frame = ttk.Frame(main_frame)
        btn_frame.grid(row=2, column=0, pady=5, sticky="ew")
        
        ttk.Button(btn_frame, text="🔍 分析", command=self.analyze).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🎉 赢了！", command=self.celebrate_win, style="Win.TButton").pack(side="left", padx=5)
        
        # 结果显示
        result_frame = ttk.LabelFrame(main_frame, text="📊 分析结果", padding="10")
        result_frame.grid(row=3, column=0, sticky=("nsew"))
        self.result_text = tk.Text(result_frame, height=15, width=120, wrap="word")
        scrollbar = ttk.Scrollbar(result_frame, orient="vertical", command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=scrollbar.set)
        self.result_text.grid(row=0, column=0, sticky=("nsew"))
        scrollbar.grid(row=0, column=1, sticky=("ns"))
        main_frame.columnconfigure(0, weight=1); result_frame.columnconfigure(0, weight=1)
        
    def _add_tile(self, suit, value):
        tile = MahjongTile(suit, value)
        self.current_hand.append(tile)
        self._update_display()
        
    def _clear_hand(self):
        self.current_hand = []
        self._update_display()
        
    def _update_display(self):
        self.hand_display.delete(1.0, tk.END)
        if self.current_hand:
            organized = self._organize_hand_tiles()
            display_str = " | ".join(organized)
            count_str = f"（共{len(self.current_hand)}张）"
            self.hand_display.insert(tk.END, f"{display_str} {count_str}")
    
    def _organize_hand_tiles(self):
        """理牌功能：按对子、刻子、顺子组合分组
        返回格式示例：['234万', '55万', '333筒', '东东东', '白板']"""
        if not self.current_hand:
            return []
        
        tiles = sorted(self.current_hand)
        tile_counts = Counter(tiles)
        organized_groups = []
        
        # 辅助函数：从某个value开始移除3个数
        def has_and_remove_sequence(values_list, start):
            seq = [start, start+1, start+2]
            if all(values_list.count(v) >= 1 for v in seq):
                for v in seq:
                    values_list.remove(v)
                return True
            return False
        
        # 先处理数牌（万筒条）
        for suit in ['man', 'pin', 'sou']:
            suit_name = {'man': '万', 'pin': '筒', 'sou': '条'}[suit]
            
            # 直接获得该花色的值列表
            values = []
            for tile, count in tile_counts.items():
                if tile.suit == suit and count > 0:
                    values.extend([tile.value] * count)
            values.sort()
            
            while values:
                v = values[0]
                cnt = values.count(v)
                
                # 刻子优先
                if cnt >= 3:
                    organized_groups.append(f"{v}{v}{v}{suit_name}")
                    for _ in range(3):
                        values.remove(v)
                elif cnt == 2:
                    organized_groups.append(f"{v}{v}{suit_name}")
                    for _ in range(2):
                        values.remove(v)
                else:  # 单张
                    # 看能否组成顺子
                    if 1 <= v <= 7 and has_and_remove_sequence(values, v):
                        organized_groups.append(f"{v}{v+1}{v+2}{suit_name}")
                    else:
                        organized_groups.append(f"{v}{suit_name}")
                        values.remove(v)
        
        # 字牌
        honor_map = {1:'东', 2:'南', 3:'西', 4:'北', 5:'白', 6:'发', 7:'中'}
        for tile in sorted(self.current_hand):
            if tile.suit == 'honor' and tile_counts.get(tile, 0) > 0:
                name = honor_map[tile.value]
                count = tile_counts[tile]
                if count >= 3:
                    organized_groups.append(f"{name}{name}{name}")
                elif count == 2:
                    organized_groups.append(f"{name}{name}")
                else:
                    organized_groups.append(f"{name}")
                # 清除计数，避免重复
                tile_counts[tile] = 0
        
        return organized_groups

    def _analyze_development_suggestions(self, hand_tiles, player_wind, round_wind):
        """智能分析发展建议，避免无脑推荐"""
        from collections import Counter
        
        if not hand_tiles:
            return []
            
        suggestions = []
        tile_counts = Counter(hand_tiles)
        
        # 分析当前手牌结构
        sequences = 0
        pairs = 0
        yaochu_count = 0  # 幺九牌数量
        honor_count = 0   # 字牌数量
        suit_distribution = Counter(tile.suit for tile in hand_tiles if tile.suit != 'honor')
        
        # 统计分析
        for tile in hand_tiles:
            if tile.is_yaochu():
                yaochu_count += 1
            if tile.suit == 'honor':
                honor_count += 1
                
        # 检查对子数量
        pairs = sum(1 for count in tile_counts.values() if count == 2)
        triplets = sum(1 for count in tile_counts.values() if count >= 3)
        
        # 估算顺子数量（简化）
        for suit in ['man', 'pin', 'sou']:
            suit_tiles = [t for t in hand_tiles if t.suit == suit]
            if len(suit_tiles) >= 3:
                suit_values = sorted([t.value for t in suit_tiles])
                # 简单检查是否有连续的数字
                for i in range(len(suit_values) - 2):
                    if suit_values[i+2] == suit_values[i] + 2:
                        sequences += 1
                        break
        
        # 智能建议生成
        
        # 1. 七对子建议（只有当对子较多且顺子较少时才推荐）
        if pairs >= 3 and sequences <= 1:
            missing_pairs = 7 - pairs
            if missing_pairs <= 4:
                suggestions.append(f"七对子路线：已有{pairs}个对子，还需{missing_pairs}个对子")
            else:
                suggestions.append("七对子路线：长期发展可能，需要较多对子")
        elif pairs >= 2 and sequences == 0:
            suggestions.append("七对子路线：适合门清状态下发展")
        
        # 2. 断幺九建议（只有当幺九牌较少时才推荐）
        simple_count = len(hand_tiles) - yaochu_count
        if yaochu_count <= 3 and simple_count >= 8:
            suggestions.append(f"断幺九路线：当前{simple_count}张中张牌，较适合发展")
        elif yaochu_count == 0:
            suggestions.append("断幺九路线：已成型，保持中张牌发展")
        
        # 3. 役牌发展建议
        honor_potential = self._check_honor_potential(hand_tiles, player_wind, round_wind)
        if honor_potential:
            suggestions.extend(honor_potential)
        
        # 4. 一色发展建议
        if suit_distribution:
            max_suit_count = max(suit_distribution.values())
            if max_suit_count >= 6:
                suit_name = {'man': '万', 'pin': '筒', 'sou': '条'}[max(suit_distribution.keys())]
                if max_suit_count >= 8:
                    suggestions.append(f"清一色路线：{suit_name}牌充足，发展潜力大")
                else:
                    suggestions.append(f"混一色路线：向{suit_name}一色发展")
        
        # 5. 通用建议
        if not suggestions:
            if honor_count >= 2:
                suggestions.append("役牌路线：利用现有字牌发展")
            elif len(hand_tiles) >= 10:
                suggestions.append("优化结构：清理孤立牌，加强组合")
            else:
                suggestions.append("快速进张：优先完善现有搭子")
        
        return suggestions
    
    def _check_honor_potential(self, hand_tiles, player_wind, round_wind):
        """检查役牌潜力"""
        from collections import Counter
        
        suggestions = []
        tile_counts = Counter(hand_tiles)
        
        # 风牌映射
        wind_map = {'东': 1, '南': 2, '西': 3, '北': 4}
        
        # 检查自风牌
        if player_wind in wind_map:
            wind_value = wind_map[player_wind]
            wind_tile = MahjongTile('honor', wind_value)
            count = tile_counts.get(wind_tile, 0)
            if count >= 2:
                suggestions.append(f"{player_wind}风牌役牌：已有{count}张，可发展刻子")
        
        # 检查场风牌
        if round_wind in wind_map:
            wind_value = wind_map[round_wind]
            wind_tile = MahjongTile('honor', wind_value)
            count = tile_counts.get(wind_tile, 0)
            if count >= 2:
                suggestions.append(f"{round_wind}风牌役牌：已有{count}张，可发展刻子")
        
        # 检查三元牌（白板、发财、红中）
        dragon_names = {5: '白板', 6: '发财', 7: '红中'}
        for value, name in dragon_names.items():
            dragon_tile = MahjongTile('honor', value)
            count = tile_counts.get(dragon_tile, 0)
            if count >= 2:
                suggestions.append(f"{name}役牌：已有{count}张，可发展刻子")
        
        return suggestions
            
    def _generate_random_hand(self):
        full_deck = []
        for suit in ['man', 'pin', 'sou']:
            for value in range(1, 10):
                for _ in range(4):
                    full_deck.append(MahjongTile(suit, value))
        honor_values = [1, 2, 3, 4, 5, 6, 7]
        for value in honor_values:
            for _ in range(4):
                full_deck.append(MahjongTile('honor', value))
        random.shuffle(full_deck)
        self.current_hand = full_deck[:13]
        self._update_display()
        
    def _delete_tile(self):
        if len(self.current_hand) == 0:
            messagebox.showwarning("", "请先添加手牌")
            return
        popup = tk.Toplevel(self.root)
        popup.title("删除牌")
        popup.geometry("300x150")
        
        options = []
        for i, tile in enumerate(self.current_hand):
            options.append(f"#{i+1} {str(tile)}")
            
        ttk.Label(popup, text="选择要删除的牌:").pack(pady=10)
        delete_combo = ttk.Combobox(popup, values=options, state="readonly", width=25)
        delete_combo.pack(pady=5)
        
        def do_delete():
            sel = delete_combo.get()
            if not sel:
                return
            try:
                idx = int(sel[1:].split()[0]) - 1
                if 0 <= idx < len(self.current_hand):
                    self.current_hand.pop(idx)
                    self._update_display()
                    popup.destroy()
            except Exception as e:
                messagebox.showerror("", "删除失败")
                
        ttk.Button(popup, text="删除", command=do_delete).pack(pady=5)
        
    def analyze(self):
        if not self.current_hand:
            messagebox.showwarning("", "请先输入手牌")
            return
        self.result_text.delete(1.0, tk.END)
        try:
            player_wind = self.player_wind.get()
            round_wind = self.round_wind.get()
            is_dealer = self.dealer_var.get()
            hand_size = len(self.current_hand)
            
            # 风牌分析
            wind_analyzer = WindAnalyzer(player_wind, round_wind)
            wind_analysis = wind_analyzer.analyze_wind_tiles(self.current_hand)
            
            self.result_text.insert(tk.END, f"🎴 手牌分析\n{'='*50}\n")
            self.result_text.insert(tk.END, f"📋 手牌：{' '.join(str(t) for t in self.current_hand)}")
            self.result_text.insert(tk.END, f"（{hand_size}张）\n\n")
            
            # 🎐 新增：风牌分析显示
            self.result_text.insert(tk.END, f"🎐 {wind_analyzer.get_wind_summary(self.current_hand)}\n\n")
            
            self.result_text.insert(tk.END, "🏆 役种分析：\n")
            yaku_analyzer = YakuAnalyzer(self.current_hand, player_wind, round_wind, is_dealer)
            yaku_result = yaku_analyzer.analyze_yaku(is_winning_hand=(hand_size == 14))
            if yaku_result['total_han'] > 0:
                for yaku in yaku_result['yaku']:
                    self.result_text.insert(tk.END, f"  • {yaku['name']} ({yaku['han']}番)\n")
                self.result_text.insert(tk.END, f"  → 总共 {yaku_result['total_han']} 番\n")
            else:
                self.result_text.insert(tk.END, "  ❌ 当前手牌无役\n")
                # 智能分析发展建议
                dev_suggestions = self._analyze_development_suggestions(self.current_hand, player_wind, round_wind)
                if dev_suggestions:
                    self.result_text.insert(tk.END, "  → 建议发展路线:\n")
                    for suggestion in dev_suggestions[:3]:  # 最多显示3条建议
                        self.result_text.insert(tk.END, f"    • {suggestion}\n")
                else:
                    self.result_text.insert(tk.END, "  → 建议寻找役牌或优化手牌结构\n")
                
            # 🎯 新增：风牌建议
            if wind_analysis['recommendations']:
                self.result_text.insert(tk.END, f"\n🎯 风牌策略建议：\n")
                for rec in wind_analysis['recommendations'][:3]:  # 最多显示3条建议
                    self.result_text.insert(tk.END, f"  • {rec}\n")
                
            # 14张时才能分析打出哪张（先自摸，再打出）
            if hand_size == 14:
                self.result_text.insert(tk.END, "\n🎯 从14张中选择1张打出:\n")
                
                # 直接分析当前14张手牌的最佳切牌
                enhanced_advice = get_enhanced_discard_advice(
                    self.current_hand,
                    player_wind=player_wind,
                    round_wind=round_wind,
                    is_dealer=is_dealer
                )
                
                if 'error' not in enhanced_advice and enhanced_advice.get('best_discard'):
                    best_discard = enhanced_advice['best_discard']
                    best_result = enhanced_advice
                    
                    self.result_text.insert(tk.END, f"  🎯 推荐打出：{best_discard}\n")
                    self.result_text.insert(tk.END, f"  📊 评分：{best_result['score']:.1f}\n")
                    if best_result.get('probability_change'):
                        self.result_text.insert(tk.END, f"  📈 概率变化：{best_result['probability_change']:+.1f}%\n")
                    if best_result.get('details'):
                        self.result_text.insert(tk.END, "\n详情：\n")
                        for d in best_result['details'][:3]:
                            self.result_text.insert(tk.END, f"  · {d}\n")
                else:
                    self.result_text.insert(tk.END, "  ❌ 打牌分析异常，建议检查手牌\n")
                    self.result_text.insert(tk.END, f"  错误信息：{enhanced_advice.get('error', '未知错误')}\n")
                
                # 添加：同时显示理牌后的手牌
                organized = self._organize_hand_tiles()
                if organized:
                    self.result_text.insert(tk.END, f"\n📋 理牌显示：\n  {organized}\n")
            elif hand_size == 13:
                self.result_text.insert(tk.END, "\n💡 提示：请先摸牌至14张，再分析打哪张\n")
            else:
                self.result_text.insert(tk.END, f"\n状态：当前{hand_size}张，需继续摸牌\n")
        except Exception as e:
            self.result_text.insert(tk.END, f"❌ 分析出错：{str(e)}\n")
            messagebox.showerror("错误", str(e))
            
    def celebrate_win(self):
        """庆祝赢了的方法"""
        # 显示胜利消息
        player_wind = self.player_wind.get()
        round_wind = self.round_wind.get()
        is_dealer = self.dealer_var.get()
        
        # 分析当前手牌以显示获胜信息
        try:
            yaku_analyzer = YakuAnalyzer(self.current_hand, player_wind, round_wind, is_dealer)
            yaku_result = yaku_analyzer.analyze_yaku(is_winning_hand=True)
            
            if yaku_result['total_han'] > 0:
                win_message = f"🎉 恭喜胡了！🎉\n"
                win_message += f"点点 {yaku_result['total_han']} 番\n"
                win_message += "获得役种:\n"
                for yaku in yaku_result['yaku']:
                    win_message += f"  • {yaku['name']} ({yaku['han']}番)\n"
            else:
                win_message = "🎉 恭喜赢了！🎉\n（虽然程序分析无役，但恭喜你的手气！）"
        except:
            win_message = "🎉 恭喜赢了！🎉"
            
        # 创建庆祝窗口
        win_popup = tk.Toplevel(self.root)
        win_popup.title("庆祝胜利！")
        win_popup.geometry("600x400")
        win_popup.configure(bg="black")
        
        # 添加胜利消息
        msg_frame = ttk.Frame(win_popup)
        msg_frame.pack(pady=10)
        
        msg_label = tk.Label(
            msg_frame,
            text=win_message,
            font=("微软雅黑", 16, "bold"),
            fg="gold",
            bg="black",
            justify="center"
        )
        msg_label.pack()
        
        # 创建画布用于烟花效果
        canvas = tk.Canvas(win_popup, width=600, height=300, bg="black")
        canvas.pack(pady=10)
        
        # 初始化烟花动画
        fireworks = FireworksAnimation(canvas)
        
        # 开始烟花效果
        def start_fireworks():
            colors = ["red", "orange", "gold", "yellow", "pink", "purple", "blue"]
            
            # 创建多个烟花爆炸
            def create_bursts():
                if win_popup.winfo_exists():  # 检查窗口是否还存在
                    for _ in range(3):  # 一次创建3个烟花
                        x = random.randint(100, 500)
                        y = random.randint(80, 200)
                        color = random.choice(colors)
                        fireworks.create_burst(x, y, color)
                    
                    fireworks.update()
                    
                    # 500ms后再次创建烟花
                    if win_popup.winfo_exists():
                        win_popup.after(500, create_bursts)
            
            create_bursts()
        
        # 关闭按钮
        def close_celebration():
            win_popup.destroy()
        
        close_btn = ttk.Button(
            win_popup,
            text="关闭",
            command=close_celebration
        )
        close_btn.pack(pady=10)
        
        # 延迟开始烟花
        win_popup.after(500, start_fireworks)
        
        # 自动关闭（可选）
        def auto_close():
            if win_popup.winfo_exists():
                win_popup.destroy()
        
        win_popup.after(10000, auto_close)  # 10秒后自动关闭
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = ImprovedMahjongGUI()
    app.run()