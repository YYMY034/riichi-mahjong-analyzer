#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风位分析与回合管理系统
严格按照用户要求的麻将规则实现
"""

from typing import Dict, List, Optional, Tuple


class MahjongTurnManager:
    """行动方位管理系统
    
    严格遵循用户要求的规则：
    1. 座位顺时针固定序列：东 → 南 → 西 → 北
    2. 以「自家风位」作为基准，动态计算下家、上家、对家
    3. 普通出牌流程：自家出牌完毕，行动权交给自家的下家  
    4. 碰：别人打出牌，自家碰，下一个行动人 = 自家
    5. 吃：只能吃下家打出的牌，自家吃，下一个行动人 = 自家
    6. 抢明杠（别人打出牌自家杠）：下一个行动人 = 自家
    7. 补杠、暗杠：下一个行动人 = 自家
    """
    
    def __init__(self):
        # 初始设置
        self.current_turn = 'east'  # 当前行动方位
        self.player_wind = '东'     # 玩家的门风
        
        # 风位映射 - 严格按顺时针顺序
        # 东→南→西→北→东
        self.wind_order = ['east', 'south', 'west', 'north']
        self.wind_names = {'east': '东', 'south': '南', 'west': '西', 'north': '北'}
        
        # 基于玩家门风的相对位置映射
        # 格式：{玩家门风: {'self': 实际方位, 'next': 下家, 'opposite': 对家, 'prev': 上家}}
        self.position_map = {
            '东': {'self': 'east', 'next': 'south', 'opposite': 'west', 'prev': 'north'},
            '南': {'self': 'south', 'next': 'west', 'opposite': 'north', 'prev': 'east'},
            '西': {'self': 'west', 'next': 'north', 'opposite': 'east', 'prev': 'south'},
            '北': {'self': 'north', 'next': 'east', 'opposite': 'south', 'prev': 'west'}
        }
    
    def set_player_wind(self, wind: str) -> None:
        """设置玩家的门风，自动重新计算各家位置"""
        if wind not in ['东', '南', '西', '北']:
            raise ValueError("门风必须是东、南、西、北之一")
        
        self.player_wind = wind
        
        # 自动更新当前轮到谁 - 确保与显示一致
        my_position = self.get_my_position()
        self.current_turn = my_position
    
    def set_dealer_status(self, is_dealer: bool) -> None:
        """设置庄家状态（用于兼容旧代码）"""
        # 在这个简化版本中，庄家状态主要用于显示
        # 默认东是庄家，但这可以被覆盖
        if is_dealer and self.player_wind != '东':
            # 如果我是庄家但不是东风位，可能需要调整逻辑
            pass  # 简化处理
    
    def get_my_position(self) -> str:
        """获取我的实际方位"""
        return self.position_map[self.player_wind]['self']
    
    def get_relative_positions(self) -> Dict[str, str]:
        """获取相对位置关系字典"""
        return self.position_map[self.player_wind]
    
    def get_next_position(self, current_pos: str) -> str:
        """获取顺时针下一个位置（普通流程）"""
        current_idx = self.wind_order.index(current_pos)
        next_idx = (current_idx + 1) % 4
        return self.wind_order[next_idx]
    
    def get_prev_position(self, current_pos: str) -> str:
        """获取逆时针前一个位置"""
        current_idx = self.wind_order.index(current_pos)
        prev_idx = (current_idx - 1) % 4
        return self.wind_order[prev_idx]
    
    def next_turn_normal(self) -> str:
        """普通流程：顺时针轮换到下一个行动方"""
        self.current_turn = self.get_next_position(self.current_turn)
        return self.current_turn
    
    def next_turn_after_pon(self, actor_pos: str, source_pos: str) -> str:
        """碰之后：下一个行动方是碰家本身
        ⚠️硬性约束：覆盖正常轮换逻辑，直接设为碰家
        """
        self.current_turn = actor_pos  # 直接设置为碰家
        return self.current_turn
    
    def next_turn_after_chi(self, actor_pos: str) -> str:
        """吃之后：下一个行动方是吃家本身
        ⚠️硬性约束：覆盖正常轮换逻辑，直接设为吃家
        """
        self.current_turn = actor_pos  # 直接设置为吃家
        return self.current_turn
    
    def next_turn_after_kan(self, actor_pos: str, kan_type: str = 'open') -> str:
        """杠之后：下一个行动方是杠家本身
        ⚠️硬性约束：无论何种杠，下一个行动方都是杠家
        
        Args:
            actor_pos: 杠家位置
            kan_type: 杠类型 ('open'=明杠, 'closed'=暗杠, 'added'=加杠)
        """
        self.current_turn = actor_pos  # 直接设置为杠家
        return self.current_turn
    
    def get_current_player_display_name(self) -> str:
        """获取当前行动方的显示名称（相对位置）"""
        current_turn = self.current_turn
        positions = self.get_relative_positions()
        
        if current_turn == positions['self']:
            return f"我({self.wind_names[current_turn]})"
        elif current_turn == positions['next']:
            return f"下家({self.wind_names[current_turn]})"
        elif current_turn == positions['opposite']:
            return f"对家({self.wind_names[current_turn]})"
        elif current_turn == positions['prev']:
            return f"上家({self.wind_names[current_turn]})"
        else:
            return f"{self.wind_names[current_turn]}家"
    
    def who_is_my_next(self) -> str:
        """谁是我的下家（顺时针下家）"""
        positions = self.get_relative_positions()
        return positions['next']
    
    def who_is_my_prev(self) -> str:
        """谁是我的上家（逆时针上家）"""
        positions = self.get_relative_positions()
        return positions['prev']
    
    def who_is_my_opposite(self) -> str:
        """谁是我的对家"""
        positions = self.get_relative_positions()
        return positions['opposite']
    
    def reset_game(self) -> None:
        """重置游戏状态"""
        self.current_turn = 'east'  # 重置为东家开始
        
    def reset_rotation(self) -> None:
        """重置轮回到第一位"""
        # 重置到我的位置开始
        self.current_turn = self.get_my_position()


class WindAnalyzer:
    """风位分析器 - 专门处理风位相关的计算和分析"""
    
    def __init__(self):
        # 风向定义
        self.wind_names = {'east': '东', 'south': '南', 'west': '西', 'north': '北'}
        self.wind_chars = {'东': 'east', '南': 'south', '西': 'west', '北': 'north'}
        
        # 相对位置关系定义
        self.relative_positions = {
            '东': {'self': 'east', 'next': 'south', 'opposite': 'west', 'prev': 'north'},
            '南': {'self': 'south', 'next': 'west', 'opposite': 'north', 'prev': 'east'},
            '西': {'self': 'west', 'next': 'north', 'opposite': 'east', 'prev': 'south'},
            '北': {'self': 'north', 'next': 'east', 'opposite': 'south', 'prev': 'west'}
        }
    
    def analyze_wind_relationships(self, player_wind: str) -> Dict[str, str]:
        """分析风位关系 - 返回完整的关系表"""
        if player_wind not in self.relative_positions:
            raise ValueError("无效的门风")
        
        return self.relative_positions[player_wind]
    
    def get_chinese_display(self, position_relationships: Dict[str, str]) -> Dict[str, str]:
        """获取中文显示格式"""
        display_map = {}
        for rel_key, pos_key in position_relationships.items():
            display_map[rel_key] = self.wind_names[pos_key]
        return display_map
    
    def validate_wind_sequence(self) -> bool:
        """验证风位顺序是否正确（顺时针）"""
        expected_order = ['east', 'south', 'west', 'north']
        
        # 检查每个风向的下家是否正确
        for i, wind in enumerate(expected_order):
            next_idx = (i + 1) % 4
            expected_next = expected_order[next_idx]
            
            for player_wind, positions in self.relative_positions.items():
                if positions['self'] == wind:
                    if positions['next'] != expected_next:
                        return False
                    break
        return True
    
    def get_wind_direction_text(self) -> str:
        """获取风向方位说明文本"""
        return "座位顺时针固定序列：东 → 南 → 西 → 北"
    
    @staticmethod
    def get_wind_relations(player_wind: str, round_wind: str) -> Dict[str, str]:
        """获取风位关系（兼容旧代码）"""
        return {
            '我的门风': player_wind,
            '场风': round_wind,
            '当前局数': f"{player_wind}{round_wind}局",
            '东风局': '场风为东' if round_wind == '东' else '否',
            '南风局': '场风为南' if round_wind == '南' else '否',
            '自风一致': '是' if player_wind == round_wind else '否',
            '三元牌提示': '注意中发白的使用'
        }
    
    def format_relationship_table(self, player_wind: str) -> str:
        """格式化为关系表文本 - 符合用户要求"""
        positions = self.analyze_wind_relationships(player_wind)
        display = self.get_chinese_display(positions)
        
        table_text = f"自家 = {player_wind}\n\n"
        table_text += f"自家：{display['self']}\n"
        table_text += f"下家：{display['next']}\n"
        table_text += f"对家：{display['opposite']}\n"
        table_text += f"上家：{display['prev']}\n"
        
        return table_text


# 导出常用类
turn_manager = MahjongTurnManager
wind_analyzer = WindAnalyzer

__all__ = ['MahjongTurnManager', 'WindAnalyzer', 'turn_manager', 'wind_analyzer']