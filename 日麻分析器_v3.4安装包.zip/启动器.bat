@echo off
chcp 65001 >nul
cls

echo =============================================
echo        日麻分析器启动器 v3.2
echo =============================================
echo.
echo 请选择要启动的版本:
echo.
echo   [1] 日麻记牌器增强版 (智能分析+碰杠吃+何切理论)
echo   [2] 工作版日麻分析器 (基础分析+烟花动画)
echo   [3] AI增强版日麻分析器  -- 开发中
echo.
echo =============================================

set /p choice="请输入数字 (1-3): "

if "%choice%"=="1" (
    cls
    echo.
    echo 正在启动日麻记牌器增强版...
    echo.
    python "日麻记牌器增强版.py"
    if errorlevel 1 (
        echo.
        echo [错误] 启动失败！请确认已安装 Python 3.6+
        echo 下载地址: https://www.python.org/downloads/
        echo.
        pause
    )
    exit
)

if "%choice%"=="2" (
    cls
    echo.
    echo 正在启动工作版日麻分析器...
    echo.
    python "工作版日麻分析器_备份.py"
    if errorlevel 1 (
        echo.
        echo [错误] 启动失败！请确认已安装 Python 3.6+
        echo 下载地址: https://www.python.org/downloads/
        echo.
        pause
    )
    exit
)

if "%choice%"=="3" (
    cls
    echo.
    echo =============================================
    echo    AI增强版日麻分析器 -- 开发中
    echo =============================================
    echo.
    echo 该版本正在开发中，敬请期待！
    echo.
    echo 即将推出:
    echo    - AI智能分析建议
    echo    - 高级防守战术
    echo    - 实时胜率计算
    echo    - AI对手行为预测
    echo.
    echo =============================================
    echo.
    pause
    exit
)

echo.
echo 无效选择，请输入 1、2 或 3
echo.
pause
