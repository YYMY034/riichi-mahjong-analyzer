#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日麻分析器全场景测试集 v3.5
包含所有历史测试场景，用于验证算法修改后的兼容性

使用方法:
  python test_all_scenarios.py

场景清单:
  1. 4567m 99m | 68p | 4468s 99s (dora=9s) → 正解切4s (四枚畸形块)
  2. 34567p | 1123s 78899s (dora=5p) → 正解切8s (双亚两面复合体)
  3. 2m 4567m 99m | 678p | 11s 45s (dora=3m) → 正解切9m (相离两坎含dora瞄准)
  4. 33m 5789m | 11p 35p | 67s | 北北 (dora=北) → 正解切1p (三雀头最弱)
  5. 7m 99m | 67p | 1s 222s 456s 89s (dora=8s) → 正解切1s (孤立老头牌)
  6. 23m 67m | 3p 44p 99p | 33s 5s | 中中 (dora=8m) → 正解切9p (搭子溢出拆愚型)
  7. 88m | 44p 67p | 34s 9s 88s | 北北北 (dora=2m) → 正解切北 (拆客风暗刻激活断幺九)
  8. 4557m | 3566788p | 234s (dora=2s) → 正解切3p (双坎张负担孤张端)
  9. 344789m | 7889p | 3456s (dora=8p) → 正解切8p (宝牌对子冗余)
 10. 4567m | 345667p | 3455s (dora=2p) → 正解切5s (亚两面端点拆)
"""

import sys
sys.path.insert(0, r"c:\Users\YYMY\Documents\Catpaw\Catpaw实际麻将")

from 日麻记牌器增强版 import CompleteMahjongRecordEnhancedGUI, MahjongTile, WinProbabilityCalculator
from collections import Counter

def test_scenario(name, hand_tiles, dora_indicator, expected_tile):
    """测试一个场景
    
    Args:
        name: 场景名称
        hand_tiles: 手牌列表 [(suit, value), ...]
        dora_indicator: dora指示牌 (suit, value)
        expected_tile: 正解牌 (suit, value)
    
    Returns:
        bool: 是否通过
    """
    gui = CompleteMahjongRecordEnhancedGUI()
    gui.current_dora_indicators = [MahjongTile(dora_indicator[0], dora_indicator[1])]
    
    hand = [MahjongTile(s, v) for s, v in hand_tiles]
    tile_counts = Counter(hand)
    
    # 计算真实的向听数和进张数
    base_shanten = WinProbabilityCalculator.calculate_shanten(hand)
    base_ukeire = gui._count_ukeire(hand, Counter())
    is_tenpai_stuck = (base_shanten == 0 and base_ukeire == 0)
    
    # 计算每张牌的总分
    results = []
    for tile in tile_counts:
        count = tile_counts[tile]
        sim_hand = hand.copy()
        sim_hand.remove(tile)
        
        new_shanten = WinProbabilityCalculator.calculate_shanten(sim_hand)
        shanten_change = new_shanten - base_shanten
        new_ukeire = gui._count_ukeire(sim_hand, Counter())
        ukeire_change = new_ukeire - base_ukeire
        
        kana_score = gui._evaluate_kana_value(tile, hand, tile_counts)
        improvement = gui._evaluate_improvement_potential(tile, hand, tile_counts)
        yaku_impact = gui._evaluate_yaku_impact(tile, hand, tile_counts, count)
        type_value = gui._evaluate_tile_type_value(tile, count, hand, tile_counts)
        float_value = gui._evaluate_float_value(tile, hand, tile_counts)
        pair_struct = gui._evaluate_pair_structure(tile, hand, tile_counts)
        five_block = gui._evaluate_five_block(tile, hand, tile_counts)
        compound = gui._evaluate_compound_structure(tile, hand, tile_counts)
        
        dora_tiles = gui._get_current_dora_tiles()
        dora_value = 0
        if tile in dora_tiles:
            if count >= 2:
                still = gui._dora_redundant_in_pair(tile, hand, tile_counts)
                dora_value = 0.5 if still else 2.0
            else:
                dora_value = 3.0
        
        # dora_route计算
        dora_route = 0
        if tile.suit != 'honor' and dora_tiles:
            val = tile.value
            suit = tile.suit
            for dora in dora_tiles:
                if dora.suit != suit:
                    continue
                dora_val = dora.value
                if abs(val - dora_val) == 1:
                    partner_val = val + 2 if val < dora_val else val - 2
                    if 1 <= partner_val <= 9:
                        partner_tile = MahjongTile(suit, partner_val)
                        if partner_tile in tile_counts:
                            has_pair_in_seg = False
                            suit_vals_all = []
                            for t_all, c_all in tile_counts.items():
                                if t_all.suit == suit:
                                    suit_vals_all.extend([t_all.value] * c_all)
                            suit_vals_all.sort()
                            val_seg = [val]
                            if suit_vals_all:
                                for v in reversed(suit_vals_all):
                                    if v < val and val_seg[0] - v <= 2:
                                        val_seg.insert(0, v)
                                    elif v < val:
                                        break
                                for v in suit_vals_all:
                                    if v > val and v - val_seg[-1] <= 2:
                                        val_seg.append(v)
                                    elif v > val:
                                        break
                            for t2, c2 in tile_counts.items():
                                if t2.suit == suit and c2 == 2:
                                    if t2.value in val_seg:
                                        has_pair_in_seg = True
                                        break
                            if has_pair_in_seg:
                                dora_route = 6
        
        # 坎张连暗刻保护
        kana_ankan_protect = 0
        if tile.suit != 'honor' and count == 1:
            val_t = tile.value
            suit_t = tile.suit
            if val_t + 2 <= 9 and tile_counts.get(MahjongTile(suit_t, val_t + 2), 0) >= 3:
                kana_ankan_protect = 8
            elif val_t - 2 >= 1 and tile_counts.get(MahjongTile(suit_t, val_t - 2), 0) >= 3:
                kana_ankan_protect = 8
        
        # 四连复合型破坏惩罚
        ren4_break_penalty = 0
        if tile.suit != 'honor' and is_tenpai_stuck:
            for other_suit in ['man', 'pin', 'sou']:
                if other_suit == tile.suit:
                    continue
                other_vals = []
                for t_oth, c_oth in tile_counts.items():
                    if t_oth.suit == other_suit:
                        other_vals.extend([t_oth.value] * c_oth)
                other_vals.sort()
                for i in range(len(other_vals) - 3):
                    seg4 = other_vals[i:i+4]
                    if (seg4[1] - seg4[0] == 1 and seg4[2] - seg4[1] == 1 and 
                        seg4[3] - seg4[2] == 1):
                        end_val = seg4[-1]
                        end_tile = MahjongTile(other_suit, end_val)
                        end_before = gui._evaluate_compound_structure(end_tile, hand, tile_counts)
                        sim_hand = [t for t in hand if t != tile]
                        sim_tc = Counter(sim_hand)
                        end_after = gui._evaluate_compound_structure(end_tile, sim_hand, sim_tc)
                        if end_after < end_before:
                            ren4_break_penalty += (end_before - end_after) * 10
                        break
        
        # 根据向听数选择权重
        if is_tenpai_stuck:
            w_kana = 0.5
            w_imp = -0.5
            w_yaku = 1.0
            w_type = 0.5
            w_compound = 6.0
            w_five = 0.0
        else:
            w_kana = 2.0
            w_imp = 2.0
            w_yaku = 2.5
            w_type = 1.5
            w_compound = 2.0
            w_five = 1.5
        
        total = (
            shanten_change * 50 +
            ukeire_change * 3.0 +
            -kana_score * w_kana +
            improvement * w_imp +
            yaku_impact * w_yaku +
            type_value * w_type +
            -float_value * 2.5 +
            pair_struct * 1.5 +
            -five_block * w_five +
            compound * w_compound +
            kana_ankan_protect * 3.0 +
            dora_value * 3.0 +
            dora_route * 3.0 +
            ren4_break_penalty
        )
        
        results.append((tile, total, {
            'kana': kana_score, 'imp': improvement, 'yaku': yaku_impact,
            'type': type_value, 'float': float_value, 'pair': pair_struct,
            'five': five_block, 'compound': compound, 'dora': dora_value,
            'shanten': shanten_change, 'ukeire': ukeire_change, 'route': dora_route,
            'ankan_prot': kana_ankan_protect
        }))
    
    results.sort(key=lambda x: x[1])
    
    expected = MahjongTile(expected_tile[0], expected_tile[1])
    # 过滤掉shanten_change > 0的牌（出后增加向听的排除）
    valid_results = [r for r in results if r[2]['shanten'] <= 0]
    if not valid_results:
        valid_results = results
    
    top_tile = valid_results[0][0]
    top_score = valid_results[0][1]
    
    # 正解在top2内即可通过
    top2_tiles = [str(r[0]) for r in valid_results[:2]]
    expected_in_top2 = str(expected) in top2_tiles
    
    # 正解在top1则完美通过
    success = (str(top_tile) == str(expected))
    
    status = "✅ PASS" if expected_in_top2 else "❌ FAIL"
    if expected_in_top2 and not success:
        status = "✅ PASS(top2)"
    print(f"{status} - {name}")
    print(f"  期望: {expected}  实际: {top_tile} (得分{top_score:.1f})")
    print(f"  向听={base_shanten} 进张={base_ukeire} stuck={is_tenpai_stuck}")
    
    if not success:
        print(f"  Top 3:")
        for i, (t, s, detail) in enumerate(valid_results[:3]):
            print(f"    {i+1}. {t} = {s:.1f}  {detail}")
    
    gui.root.destroy()
    return expected_in_top2


if __name__ == '__main__':
    passed = 0
    total = 0
    
    # === 场景1: 四枚畸形块 ===
    # 手牌: 4567m 99m | 68p | 4468s 99s (14张)
    # dora=9s (指示牌8s), 正解切4s
    total += 1
    if test_scenario(
        "场景1: 4567m 99m | 68p | 4468s 99s, dora=9s, 正解切4s",
        [('man', 4), ('man', 5), ('man', 6), ('man', 7), ('man', 9), ('man', 9),
         ('pin', 6), ('pin', 8),
         ('sou', 4), ('sou', 4), ('sou', 6), ('sou', 8), ('sou', 9), ('sou', 9)],
        ('sou', 8),  # dora指示牌8s → dora=9s
        ('sou', 4)   # 正解切4s
    ): passed += 1
    
    # === 场景2: 双亚两面复合体 ===
    # 手牌: 34567p | 1123s 78899s (14张)
    # dora=5p (指示牌4p), 正解切8s
    total += 1
    if test_scenario(
        "场景2: 34567p | 1123s 78899s, dora=5p, 正解切8s",
        [('pin', 3), ('pin', 4), ('pin', 5), ('pin', 6), ('pin', 7),
         ('sou', 1), ('sou', 1), ('sou', 2), ('sou', 3),
         ('sou', 7), ('sou', 8), ('sou', 8), ('sou', 9), ('sou', 9)],
        ('pin', 4),
        ('sou', 8)
    ): passed += 1
    
    # === 场景3: 相离两坎含dora瞄准 ===
    # 手牌: 2m 4567m 99m | 678p | 11s 45s (14张)
    # dora=3m (指示牌2m), 正解切9m
    total += 1
    if test_scenario(
        "场景3: 2m 4567m 99m | 678p | 11s 45s, dora=3m, 正解切9m",
        [('man', 2), ('man', 4), ('man', 5), ('man', 6), ('man', 7), ('man', 9), ('man', 9),
         ('pin', 6), ('pin', 7), ('pin', 8),
         ('sou', 1), ('sou', 1), ('sou', 4), ('sou', 5)],
        ('man', 2),
        ('man', 9)
    ): passed += 1
    
    # === 场景4: 三雀头最弱 ===
    # 手牌: 33m 5789m | 11p 35p | 67s | 北北 (14张)
    # dora=北 (指示牌西), 正解切1p
    total += 1
    if test_scenario(
        "场景4: 33m 5789m | 11p 35p | 67s | 北北, dora=北, 正解切1p",
        [('man', 3), ('man', 3), ('man', 5), ('man', 7), ('man', 8), ('man', 9),
         ('pin', 1), ('pin', 1), ('pin', 3), ('pin', 5),
         ('sou', 6), ('sou', 7),
         ('honor', 4), ('honor', 4)],
        ('honor', 3),
        ('pin', 1)
    ): passed += 1
    
    # === 场景5: 孤立老头牌 ===
    # 手牌: 7m 99m | 67p | 1s 222s 456s 89s (14张)
    # dora=8s (指示牌7s), 正解切1s
    total += 1
    if test_scenario(
        "场景5: 7m 99m | 67p | 1s 222s 456s 89s, dora=8s, 正解切1s",
        [('man', 7), ('man', 9), ('man', 9),
         ('pin', 6), ('pin', 7),
         ('sou', 1), ('sou', 2), ('sou', 2), ('sou', 2), ('sou', 4), ('sou', 5), ('sou', 6), ('sou', 8), ('sou', 9)],
        ('sou', 7),
        ('sou', 1)
    ): passed += 1
    
    # === 场景6: 搭子溢出拆愚型 ===
    # 手牌: 23m 67m | 3p 44p 99p | 33s 5s | 中中 (14张)
    # dora=8m (指示牌7m), 正解切9p
    total += 1
    if test_scenario(
        "场景6: 23m 67m | 3p 44p 99p | 33s 5s | 中中, dora=8m, 正解切9p",
        [('man', 2), ('man', 3), ('man', 6), ('man', 7),
         ('pin', 3), ('pin', 4), ('pin', 4), ('pin', 9), ('pin', 9),
         ('sou', 3), ('sou', 3), ('sou', 5),
         ('honor', 7), ('honor', 7)],
        ('man', 7),
        ('pin', 9)
    ): passed += 1
    
    # === 场景7: 拆客风暗刻激活断幺九 ===
    # 手牌: 88m | 44p 67p | 34s 9s 88s | 北北北 (14张)
    # dora=2m (指示牌1m), 正解切北
    total += 1
    if test_scenario(
        "场景7: 88m | 44p 67p | 34s 6s 88s | 北北北, dora=2m, 正解切北",
        [('man', 8), ('man', 8),
         ('pin', 4), ('pin', 4), ('pin', 6), ('pin', 7),
         ('sou', 3), ('sou', 4), ('sou', 6), ('sou', 8), ('sou', 8),
         ('honor', 4), ('honor', 4), ('honor', 4)],
        ('man', 1),
        ('honor', 4)
    ): passed += 1
    
    # === 场景8: 双坎张负担孤张端 ===
    # 手牌: 4557m | 3566788p | 234s (14张)
    # dora=2s (指示牌1s), 正解切3p
    total += 1
    if test_scenario(
        "场景8: 4557m | 3566788p | 234s, dora=2s, 正解切3p",
        [('man', 4), ('man', 5), ('man', 5), ('man', 7),
         ('pin', 3), ('pin', 5), ('pin', 6), ('pin', 6), ('pin', 7), ('pin', 8), ('pin', 8),
         ('sou', 2), ('sou', 3), ('sou', 4)],
        ('sou', 1),
        ('pin', 3)
    ): passed += 1
    
    # === 场景9: 宝牌对子冗余 ===
    # 手牌: 344789m | 7889p | 3456s (14张)
    # dora=8p (指示牌7p), 正解切8p
    total += 1
    if test_scenario(
        "场景9: 344789m | 7889p | 3456s, dora=8p, 正解切8p",
        [('man', 3), ('man', 4), ('man', 4), ('man', 7), ('man', 8), ('man', 9),
         ('pin', 7), ('pin', 8), ('pin', 8), ('pin', 9),
         ('sou', 3), ('sou', 4), ('sou', 5), ('sou', 6)],
        ('pin', 7),
        ('pin', 8)
    ): passed += 1
    
    # === 场景10: 亚两面端点拆 ===
    # 手牌: 4567m | 345667p | 3455s (14张)
    # dora=2p (指示牌1p), 正解切5s
    total += 1
    if test_scenario(
        "场景10: 4567m | 345667p | 3455s, dora=2p, 正解切5s",
        [('man', 4), ('man', 5), ('man', 6), ('man', 7),
         ('pin', 3), ('pin', 4), ('pin', 5), ('pin', 6), ('pin', 6), ('pin', 7),
         ('sou', 3), ('sou', 4), ('sou', 5), ('sou', 5)],
        ('pin', 1),
        ('sou', 5)
    ): passed += 1
    
    # === 场景11: 双对子长连畸形块 ===
    # 手牌: 5677p 8p | 1122345s | 中中 (14张)
    # dora=西 (指示牌南), 正解切2s
    total += 1
    if test_scenario(
        "场景11: 5677p 8p | 1122345s | 中中, dora=西, 正解切2s",
        [('pin', 5), ('pin', 6), ('pin', 7), ('pin', 7), ('pin', 8),
         ('sou', 1), ('sou', 1), ('sou', 2), ('sou', 2), ('sou', 3), ('sou', 4), ('sou', 5),
         ('honor', 7), ('honor', 7)],
        ('honor', 2),  # dora指示牌南→dora=西
        ('sou', 2)     # 正解切2s
    ): passed += 1
    
    # === 场景12: 坎张连暗刻保护 vs 顺子冗余牌 ===
    # 手牌: 3p 555p 67p | 567s 5s 77s 88s (14张)
    # dora=3p (指示牌2p), 正解切5s
    total += 1
    if test_scenario(
        "场景12: 3筒 555筒 67筒 | 567条 5条 77条 88条, dora=3p, 正解切5s",
        [('pin', 3), ('pin', 5), ('pin', 5), ('pin', 5), ('pin', 6), ('pin', 7),
         ('sou', 5), ('sou', 6), ('sou', 7), ('sou', 5), ('sou', 7), ('sou', 7), ('sou', 8), ('sou', 8)],
        ('pin', 2),
        ('sou', 5)
    ): passed += 1

    # 场景13: 456三色诱惑 vs 速立直
    # 手牌: 123m 1m 456m 4m | 45p | 11s 2s 4s (14张)
    # dora=8m (指示牌7m), 正解切4s
    # 核心: 放弃不现实的456三色，保留一杯口潜力，切坎张孤张端4s
    total += 1
    if test_scenario(
        "场景13: 123万 1万 456万 4万 | 45筒 | 11条 2条 4条, dora=8m, 正解切4s",
        [('man',1),('man',2),('man',3),('man',1),('man',4),('man',5),('man',6),('man',4),
         ('pin',4),('pin',5),
         ('sou',1),('sou',1),('sou',2),('sou',4)],
        ('man',7),
        ('sou',4)
    ): passed += 1

    # 场景14: 好型听牌概率 > 单纯进张枚数
    # 手牌: 678m 9m | 111p 2p 4p | 45s 777s (14张)
    # dora=西 (指示牌南), 正解切4p
    # 核心: 切4p保留2p，摸3p变23p两面=全好型一向听；切2p保留4p容易滑向愚形听牌
    total += 1
    if test_scenario(
        "场景14: 678万 9万 | 111筒 2筒 4筒 | 45条 777条, dora=西, 正解切4p",
        [('man',6),('man',7),('man',8),('man',9),
         ('pin',1),('pin',1),('pin',1),('pin',2),('pin',4),
         ('sou',4),('sou',5),('sou',7),('sou',7),('sou',7)],
        ('honor', 2),  # dora指示牌南→dora=西
        ('pin',4)
    ): passed += 1

    # 场景15: 四连复合型保护——保4567s四连 vs 拆愚型
    # 手牌: 11m 33m | 123p 4p 7p 9p | 456s 7s (14张)
    # dora=1m (指示牌9m), 正解切1p
    # 核心: 切1p保住4567s四连完整(7s不脱离)，筒子留23p两面搭子；
    #       切9p会破坏四连型(7s沦为孤张)，只顾眼前进张多忽略未来好型改良
    total += 1
    if test_scenario(
        "场景15: 11万 33万 | 123筒 4筒 7筒 9筒 | 456条 7条, dora=1m, 正解切1p",
        [('man',1),('man',1),('man',3),('man',3),
         ('pin',1),('pin',2),('pin',3),('pin',4),('pin',7),('pin',9),
         ('sou',4),('sou',5),('sou',6),('sou',7)],
        ('man',9),  # dora指示牌9m→dora=1m
        ('pin',1)   # 正解切1p
    ): passed += 1
    
    print(f"\n{'='*60}")
    print(f"验证完成: {passed}/{total} 通过")
