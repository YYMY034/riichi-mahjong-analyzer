#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日麻分析器核心模块 - 包含牌、役种分析和胜率计算
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Optional, Set, Tuple
from collections import Counter
import math


class Suit(Enum):
    """牌花色枚举"""
    MAN = 'man'      # 万
    PIN = 'pin'      # 筒  
    SOU = 'sou'      # 条
    HONOR = 'honor'  # 字牌


@dataclass
class MahjongTile:
    """麻将牌类"""
    suit: str
    value: int
    
    def __str__(self):
        if self.suit == 'man':
            return f"{self.value}万"
        elif self.suit == 'pin':
            return f"{self.value}筒"
        elif self.suit == 'sou':
            return f"{self.value}条"
        elif self.suit == 'honor':
            honor_map = {1: '东', 2: '南', 3: '西', 4: '北', 5: '白', 6: '发', 7: '中'}
            return honor_map.get(self.value, f"字{self.value}")
        else:
            return f"{self.suit}{self.value}"
    
    def __repr__(self):
        return self.__str__()
    
    def __eq__(self, other):
        if not isinstance(other, MahjongTile):
            return False
        return self.suit == other.suit and self.value == other.value
    
    def __hash__(self):
        return hash((self.suit, self.value))
    
    def is_yaochu(self) -> bool:
        """是否幺九牌（老头牌或字牌）"""
        return self.suit == 'honor' or self.value in [1, 9]
    
    def is_honor(self) -> bool:
        """是否字牌"""
        return self.suit == 'honor'
    
    def is_terminal(self) -> bool:
        """是否老头牌（1、9）"""
        return self.value in [1, 9]
    
    @staticmethod
    def from_str(s: str) -> Optional['MahjongTile']:
        """从字符串解析牌（如 '3万' -> MahjongTile('man', 3)）"""
        s = s.strip()
        if not s:
            return None
        for suit, suffix in [('man', '万'), ('pin', '筒'), ('sou', '条')]:
            if s.endswith(suffix):
                num_part = s[:-len(suffix)]
                try:
                    val = int(num_part)
                    if 1 <= val <= 9:
                        return MahjongTile(suit, val)
                except ValueError:
                    pass
        honor_map = {'东': 1, '南': 2, '西': 3, '北': 4, '白': 5, '发': 6, '中': 7}
        if s in honor_map:
            return MahjongTile('honor', honor_map[s])
        return None


class YakuAnalyzer:
    """役种分析器（雀魂/立直麻将 全役种）"""
    
    # ============================================================
    # 面子拆解辅助方法
    # ============================================================
    
    # 拆解缓存（避免对同一手牌重复递归）
    _decompose_cache = {}
    
    @staticmethod
    def _decompose_4m1p(tile_counts: Counter) -> List[Tuple]:
        """将14张牌拆解为4面子+1雀头的所有可能方式
        
        返回: [(mentsu_list, pair_tile), ...]
        mentsu_list: [(type, tile), ...] type='shuntsu'/'koutsu'
                     shuntsu的tile是顺子最小牌, koutsu的tile是刻子牌
        pair_tile: 雀头牌
        """
        if sum(tile_counts.values()) != 14:
            return []
        
        # 缓存键：将Counter转为可哈希的元组
        cache_key = tuple(sorted((t.suit, t.value, c) for t, c in tile_counts.items()))
        if cache_key in YakuAnalyzer._decompose_cache:
            return YakuAnalyzer._decompose_cache[cache_key]
        
        results = []
        # 尝试每种对子作为雀头
        for pair_tile in list(tile_counts.keys()):
            if tile_counts[pair_tile] >= 2:
                remaining = Counter(tile_counts)
                remaining[pair_tile] -= 2
                if remaining[pair_tile] == 0:
                    del remaining[pair_tile]
                
                for mentsu_list in YakuAnalyzer._decompose_4mentsu(remaining):
                    results.append((mentsu_list, pair_tile))
        
        YakuAnalyzer._decompose_cache[cache_key] = results
        return results
    
    @staticmethod
    def _decompose_4mentsu(tile_counts: Counter) -> List[List[Tuple]]:
        """将12张牌拆解为4个面子的所有可能方式
        
        返回: [mentsu_list, ...]
        mentsu_list: [(type, tile), ...] type='shuntsu'/'koutsu'
        """
        if not tile_counts or sum(tile_counts.values()) == 0:
            return [[]]
        
        if sum(tile_counts.values()) % 3 != 0:
            return []
        
        # 缓存键
        cache_key = tuple(sorted((t.suit, t.value, c) for t, c in tile_counts.items()))
        if cache_key in YakuAnalyzer._decompose_cache:
            return YakuAnalyzer._decompose_cache[cache_key]
        
        results = []
        sorted_tiles = sorted(tile_counts.keys(), key=lambda t: (t.suit, t.value))
        min_tile = sorted_tiles[0]
        
        # 尝试1：刻子
        if tile_counts[min_tile] >= 3:
            remaining = Counter(tile_counts)
            remaining[min_tile] -= 3
            if remaining[min_tile] == 0:
                del remaining[min_tile]
            for sub in YakuAnalyzer._decompose_4mentsu(remaining):
                results.append([('koutsu', min_tile)] + sub)
        
        # 尝试2：顺子（数牌，min_tile.value <= 7）
        if min_tile.suit != 'honor' and min_tile.value <= 7:
            t2 = MahjongTile(min_tile.suit, min_tile.value + 1)
            t3 = MahjongTile(min_tile.suit, min_tile.value + 2)
            if tile_counts.get(t2, 0) >= 1 and tile_counts.get(t3, 0) >= 1:
                remaining = Counter(tile_counts)
                remaining[min_tile] -= 1
                remaining[t2] -= 1
                remaining[t3] -= 1
                if remaining[min_tile] == 0:
                    del remaining[min_tile]
                if remaining[t2] == 0:
                    del remaining[t2]
                if remaining[t3] == 0:
                    del remaining[t3]
                for sub in YakuAnalyzer._decompose_4mentsu(remaining):
                    results.append([('shuntsu', min_tile)] + sub)
        
        YakuAnalyzer._decompose_cache[cache_key] = results
        return results
    
    @staticmethod
    def _can_decompose(tile_counts: Counter) -> bool:
        """检查14张牌能否拆成4面子+1雀头"""
        return len(YakuAnalyzer._decompose_4m1p(tile_counts)) > 0
    
    @staticmethod
    def _get_all_mentsu(tile_counts: Counter) -> List[List[Tuple]]:
        """获取所有面子+雀头拆解方式（含雀头信息）
        返回: [(mentsu_list, pair_tile), ...]
        """
        return YakuAnalyzer._decompose_4m1p(tile_counts)
    
    # ============================================================
    # 主分析入口
    # ============================================================
    
    @staticmethod
    def analyze_yaku(hand_tiles: List[MahjongTile], winning_tile: Optional[MahjongTile] = None, 
                     is_menzen: bool = True, is_richi: bool = False, 
                     is_tsumo: bool = False, round_wind: int = None,
                     seat_wind: int = None) -> List[str]:
        """分析手牌可能的役种
        
        参数:
            hand_tiles: 手牌列表(14张=4面子+雀头)
            winning_tile: 和牌张(可选)
            is_menzen: 是否门清
            is_richi: 是否立直
            is_tsumo: 是否自摸
            round_wind: 场风(1=东,2=南,3=西,4=北)
            seat_wind: 自风(1=东,2=南,3=西,4=北)
        """
        if not hand_tiles:
            return []
        
        # 清空拆解缓存（每次调用是不同手牌，避免内存无限增长）
        YakuAnalyzer._decompose_cache.clear()
        
        tile_counts = Counter(hand_tiles)
        yaku_list = []
        
        # ========== 1番役种 ==========
        
        # 立直（需外部状态判断）
        if is_richi:
            yaku_list.append("立直")
            # 一发
            # (需外部状态判断，这里不检测)
        
        # 门前清自摸和
        if is_menzen and is_tsumo:
            yaku_list.append("门前清自摸和")
        
        # 平和
        if is_menzen and YakuAnalyzer._is_pinfu(hand_tiles, tile_counts, round_wind, seat_wind):
            yaku_list.append("平和")
        
        # 一杯口
        if is_menzen and YakuAnalyzer._is_iipeikou(hand_tiles, tile_counts):
            yaku_list.append("一杯口")
        
        # 断幺九
        if YakuAnalyzer._is_tanyao(hand_tiles, tile_counts):
            yaku_list.append("断幺九")
        
        # 役牌（三元牌+场风+自风）
        yakuhai_list = YakuAnalyzer._get_yakuhai(tile_counts, round_wind, seat_wind)
        yaku_list.extend(yakuhai_list)
        
        # 岭上开花、抢杠、海底捞月、河底捞鱼
        # (需外部状态判断，这里不检测)
        
        # ========== 2番役种 ==========
        
        # 七对子
        if is_menzen and YakuAnalyzer._is_chiitoitsu(hand_tiles, tile_counts):
            yaku_list.append("七对子")
        
        # 对对和
        if YakuAnalyzer._is_toitoihou(hand_tiles, tile_counts):
            yaku_list.append("对对和")
        
        # 混全带幺九
        if YakuAnalyzer._is_chantai(hand_tiles, tile_counts):
            yaku_list.append("混全带幺九")
        
        # 一气通贯
        if YakuAnalyzer._is_ittsu(hand_tiles, tile_counts):
            yaku_list.append("一气通贯")
        
        # 三色同顺
        if YakuAnalyzer._is_sanshoku(hand_tiles, tile_counts):
            yaku_list.append("三色同顺")
        
        # 三色同刻
        if YakuAnalyzer._is_sanshoku_doukou(hand_tiles, tile_counts):
            yaku_list.append("三色同刻")
        
        # 三暗刻
        if YakuAnalyzer._is_sanankou(hand_tiles, tile_counts):
            yaku_list.append("三暗刻")
        
        # 小三元
        if YakuAnalyzer._is_shousangen(hand_tiles, tile_counts):
            yaku_list.append("小三元")
        
        # ========== 3-6番役种 ==========
        
        # 混一色
        if YakuAnalyzer._is_honiisou(hand_tiles, tile_counts):
            yaku_list.append("混一色")
        
        # 纯全带幺九
        if YakuAnalyzer._is_junchantai(hand_tiles, tile_counts):
            yaku_list.append("纯全带幺九")
        
        # 二杯口
        if is_menzen and YakuAnalyzer._is_ryanpeikou(hand_tiles, tile_counts):
            yaku_list.append("二杯口")
        
        # 清一色
        if YakuAnalyzer._is_chiniisou(hand_tiles, tile_counts):
            yaku_list.append("清一色")
        
        # ========== 役满 ==========
        
        # 国士无双
        if YakuAnalyzer._is_kokushi(hand_tiles, tile_counts):
            yaku_list.append("国士无双")
        
        # 大三元
        if YakuAnalyzer._is_daisangen(hand_tiles, tile_counts):
            yaku_list.append("大三元")
        
        # 大四喜
        if YakuAnalyzer._is_daisuushii(hand_tiles, tile_counts):
            yaku_list.append("大四喜")
        
        # 小四喜
        if YakuAnalyzer._is_shousuushii(hand_tiles, tile_counts):
            yaku_list.append("小四喜")
        
        # 清老头
        if YakuAnalyzer._is_chinroutou(hand_tiles, tile_counts):
            yaku_list.append("清老头")
        
        # 绿一色
        if YakuAnalyzer._is_ryuuiisou(hand_tiles, tile_counts):
            yaku_list.append("绿一色")
        
        # 九莲宝灯
        if YakuAnalyzer._is_chuurenpoutou(hand_tiles, tile_counts):
            yaku_list.append("九莲宝灯")
        
        # 四暗刻
        if YakuAnalyzer._is_suuankou(hand_tiles, tile_counts):
            yaku_list.append("四暗刻")
        
        # 四杠子（需外部杠信息判断，这里不检测）
        
        # 天和、地和（需外部状态判断，这里不检测）
        
        # ========== 混老头（包含在混全/纯全中，单独列出） ==========
        if YakuAnalyzer._is_honroutou(hand_tiles, tile_counts):
            yaku_list.append("混老头")
        
        return yaku_list
    
    # ============================================================
    # 1番役种
    # ============================================================
    
    @staticmethod
    def _is_pinfu(tiles: List[MahjongTile], tile_counts: Counter = None, 
                  round_wind: int = None, seat_wind: int = None) -> bool:
        """检查平和（4顺子+1对子，雀头非役牌，全部两面听）
        
        规则：
        1. 4个顺子+1个对子
        2. 雀头不是役牌（三元牌、场风、自风）
        3. 所有面子都是顺子（无刻子）
        4. 全部两面听（非边张、非坎张）
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        decompositions = YakuAnalyzer._decompose_4m1p(tile_counts)
        if not decompositions:
            return False
        
        for mentsu_list, pair_tile in decompositions:
            # 全部必须是顺子（无刻子）
            if any(mtype == 'koutsu' for mtype, _ in mentsu_list):
                continue
            
            # 雀头不能是役牌
            if pair_tile.is_honor():
                # 三元牌
                if pair_tile.value in [5, 6, 7]:
                    continue
                # 场风
                if round_wind and pair_tile.value == round_wind:
                    continue
                # 自风
                if seat_wind and pair_tile.value == seat_wind:
                    continue
                # 其他字牌做雀头可以（非役牌）
            elif pair_tile.is_terminal():
                # 老头牌做雀头可以（非役牌，但平和要求两面听）
                pass
            
            # 检查所有顺子不能是边张或坎张听
            # 平和的顺子本身没有限制（234、345、456、567、678都可以）
            # 关键是听牌时全部两面听，但这里检查手牌结构
            # 只要有一种拆法全是顺子+非役牌雀头，就算平和
            return True
        
        return False
    
    @staticmethod
    def _is_tanyao(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查断幺九（无老头牌和字牌）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        return all(not tile.is_yaochu() for tile in tile_counts.keys())
    
    @staticmethod
    def _is_iipeikou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查一杯口（同一花色两组完全相同的顺子）
        
        如234m、234m
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            # 统计同花色同位置的顺子
            shuntsu_count = Counter()
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    shuntsu_count[(tile.suit, tile.value)] += 1
            # 有至少一对相同的顺子
            if any(c >= 2 for c in shuntsu_count.values()):
                return True
        return False
    
    @staticmethod
    def _get_yakuhai(tile_counts: Counter, round_wind: int = None, seat_wind: int = None) -> List[str]:
        """检查役牌（三元牌+场风+自风），返回役种列表"""
        result = []
        
        # 三元牌刻子
        for dragon in [5, 6, 7]:  # 白发中
            dragon_tile = MahjongTile('honor', dragon)
            if tile_counts.get(dragon_tile, 0) >= 3:
                result.append("役牌")
                break  # 三元牌只报一次"役牌"
        
        # 场风刻子
        if round_wind and round_wind in [1, 2, 3, 4]:
            wind_tile = MahjongTile('honor', round_wind)
            if tile_counts.get(wind_tile, 0) >= 3 and round_wind not in [5, 6, 7]:
                if "役牌" not in result:
                    result.append("役牌")
        
        # 自风刻子
        if seat_wind and seat_wind in [1, 2, 3, 4]:
            wind_tile = MahjongTile('honor', seat_wind)
            if tile_counts.get(wind_tile, 0) >= 3 and seat_wind not in [5, 6, 7]:
                if "役牌" not in result:
                    result.append("役牌")
        
        return result
    
    # ============================================================
    # 2番役种
    # ============================================================
    
    @staticmethod
    def _is_chiitoitsu(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查七对子（7个不同的对子）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        # 7个对子
        pairs = sum(1 for c in tile_counts.values() if c == 2)
        # 不能有刻子（3张相同）
        has_triplet = any(c >= 3 for c in tile_counts.values())
        return pairs == 7 and not has_triplet
    
    @staticmethod
    def _is_toitoihou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查对对和（4组刻子+1对子）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        # 4个刻子+1个对子
        triplets = sum(1 for c in tile_counts.values() if c >= 3)
        pairs = sum(1 for c in tile_counts.values() if c == 2)
        # 刻子+对子=5, 且总共14张
        if triplets == 4 and pairs == 1:
            return True
        # 也可能有4刻+雀头其中雀头是刻子中拆出
        # 更精确检查
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            if all(mtype == 'koutsu' for mtype, _ in mentsu_list):
                return True
        return False
    
    @staticmethod
    def _is_chantai(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查混全带幺九
        
        规则：所有面子（顺子/刻子）和雀头都必须包含至少一张幺九牌（1或9或字牌）。
        - 顺子只能是123或789（含1或9），不能是234/345/456/567/678
        - 刻子必须是幺九牌的刻子
        - 雀头必须是幺九牌
        - 至少有1张字牌（否则为纯全带幺九）
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        has_honor = any(t.suit == 'honor' for t in tile_counts.keys())
        if not has_honor:
            return False  # 无字牌则非"混"全带幺九
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            # 雀头必须是幺九牌
            if not pair_tile.is_yaochu():
                continue
            
            all_ok = True
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    # 顺子必须是123或789
                    if tile.value not in [1, 7]:
                        all_ok = False
                        break
                elif mtype == 'koutsu':
                    # 刻子必须是幺九牌
                    if not tile.is_yaochu():
                        all_ok = False
                        break
            
            if all_ok:
                return True
        
        return False
    
    @staticmethod
    def _is_sanshoku(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查三色同顺（万筒条同数顺子）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            # 同花色可能有多条顺子，用list存储
            shuntsu_by_suit = {}  # suit -> list of starting values
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    if tile.suit not in shuntsu_by_suit:
                        shuntsu_by_suit[tile.suit] = []
                    shuntsu_by_suit[tile.suit].append(tile.value)
            # 检查3花色各取1条同数顺子
            if len(shuntsu_by_suit) == 3:
                for v in range(1, 8):
                    if all(v in vals for vals in shuntsu_by_suit.values()):
                        return True
        return False
    
    @staticmethod
    def _is_ittsu(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查一气通贯（同花色123+456+789）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            # 按花色收集顺子
            shuntsu_by_suit = {}  # suit -> set of starting values
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    if tile.suit not in shuntsu_by_suit:
                        shuntsu_by_suit[tile.suit] = set()
                    shuntsu_by_suit[tile.suit].add(tile.value)
            # 检查是否有花色包含1,4,7
            for suit, vals in shuntsu_by_suit.items():
                if {1, 4, 7}.issubset(vals):
                    return True
        return False
    
    @staticmethod
    def _is_sanshoku_doukou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查三色同刻（万筒条同数刻子）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            koutsu_by_suit = {}
            for mtype, tile in mentsu_list:
                if mtype == 'koutsu':
                    koutsu_by_suit[tile.suit] = tile.value
            if len(koutsu_by_suit) == 3:
                vals = list(koutsu_by_suit.values())
                if vals[0] == vals[1] == vals[2]:
                    return True
        return False
    
    @staticmethod
    def _is_sanankou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查三暗刻（3组暗刻）
        
        注意：这里只检测手牌中的刻子，不区分暗刻/明刻
        实际需要副露信息才能区分，这里简化为手牌中3组刻子
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            koutsu_count = sum(1 for mtype, _ in mentsu_list if mtype == 'koutsu')
            if koutsu_count >= 3:
                return True
        return False
    
    @staticmethod
    def _is_shousangen(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查小三元（中发白两个刻子+一个对子）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        # 统计三元牌
        sangen_triplets = 0
        sangen_pairs = 0
        for val in [5, 6, 7]:  # 白发中
            c = tile_counts.get(MahjongTile('honor', val), 0)
            if c >= 3:
                sangen_triplets += 1
            elif c == 2:
                sangen_pairs += 1
        
        return sangen_triplets == 2 and sangen_pairs == 1
    
    # ============================================================
    # 3-6番役种
    # ============================================================
    
    @staticmethod
    def _is_honiisou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查混一色（一种数牌+字牌）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        suits_present = set(t.suit for t in tile_counts.keys() if t.suit != 'honor')
        honors_present = any(t.suit == 'honor' for t in tile_counts.keys())
        
        # 恰好1种数牌+字牌
        return len(suits_present) == 1 and honors_present
    
    @staticmethod
    def _is_junchantai(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查纯全带幺九
        
        规则：所有面子和雀头都带数字1或9，不含字牌
        - 顺子只能是123或789
        - 刻子必须是1或9的刻子
        - 雀头必须是1或9
        - 无字牌
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        # 不能有字牌
        if any(t.suit == 'honor' for t in tile_counts.keys()):
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            # 雀头必须是1或9
            if not pair_tile.is_terminal():
                continue
            
            all_ok = True
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    if tile.value not in [1, 7]:
                        all_ok = False
                        break
                elif mtype == 'koutsu':
                    if not tile.is_terminal():
                        all_ok = False
                        break
            
            if all_ok:
                return True
        
        return False
    
    @staticmethod
    def _is_ryanpeikou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查二杯口（两组一杯口=同一花色4张相同顺子×2）
        
        如234m234m 567p567p
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            shuntsu_count = Counter()
            for mtype, tile in mentsu_list:
                if mtype == 'shuntsu':
                    shuntsu_count[(tile.suit, tile.value)] += 1
            # 两组各2个相同顺子
            pairs_count = sum(1 for c in shuntsu_count.values() if c == 2)
            if pairs_count == 2:
                return True
        return False
    
    @staticmethod
    def _is_chiniisou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查清一色（只有万/筒/条其中一种花色）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        suits_present = set(t.suit for t in tile_counts.keys())
        return len(suits_present) == 1 and 'honor' not in suits_present
    
    # ============================================================
    # 役满
    # ============================================================
    
    @staticmethod
    def _is_kokushi(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查国士无双（十三幺）
        
        13种幺九牌各1张+其中1种做对子
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        # 13种幺九牌
        yaochu_set = set()
        for suit in ['man', 'pin', 'sou']:
            yaochu_set.add(MahjongTile(suit, 1))
            yaochu_set.add(MahjongTile(suit, 9))
        for val in [1, 2, 3, 4, 5, 6, 7]:
            yaochu_set.add(MahjongTile('honor', val))
        
        # 所有牌都是幺九牌
        if not all(t.is_yaochu() for t in tile_counts.keys()):
            return False
        
        # 检查每种幺九牌都有
        for yt in yaochu_set:
            if tile_counts.get(yt, 0) < 1:
                return False
        
        # 恰好1种有2张（对子）
        pair_count = sum(1 for c in tile_counts.values() if c == 2)
        single_count = sum(1 for c in tile_counts.values() if c == 1)
        
        return pair_count == 1 and single_count == 12
    
    @staticmethod
    def _is_daisangen(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查大三元（中发白全部刻/杠）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        for val in [5, 6, 7]:  # 白发中
            if tile_counts.get(MahjongTile('honor', val), 0) < 3:
                return False
        return True
    
    @staticmethod
    def _is_daisuushii(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查大四喜（东南西北全部刻/杠）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        for val in [1, 2, 3, 4]:  # 东南西北
            if tile_counts.get(MahjongTile('honor', val), 0) < 3:
                return False
        return True
    
    @staticmethod
    def _is_shousuushii(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查小四喜（东南西北3组刻子+1个对子做雀头）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        wind_triplets = 0
        wind_pairs = 0
        for val in [1, 2, 3, 4]:  # 东南西北
            c = tile_counts.get(MahjongTile('honor', val), 0)
            if c >= 3:
                wind_triplets += 1
            elif c == 2:
                wind_pairs += 1
        
        return wind_triplets == 3 and wind_pairs == 1
    
    @staticmethod
    def _is_chinroutou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查清老头（只有数字1、9组成手牌，无字牌）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        # 无字牌
        if any(t.suit == 'honor' for t in tile_counts.keys()):
            return False
        
        # 所有数牌都是1或9
        return all(t.value in [1, 9] for t in tile_counts.keys())
    
    @staticmethod
    def _is_ryuuiisou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查绿一色（只有2,3,4,6,8条和发组成）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        
        green_tiles = set()
        # 条子：2,3,4,6,8
        for val in [2, 3, 4, 6, 8]:
            green_tiles.add(MahjongTile('sou', val))
        # 发
        green_tiles.add(MahjongTile('honor', 6))
        
        for tile in tile_counts.keys():
            if tile not in green_tiles:
                return False
        return True
    
    @staticmethod
    def _is_chuurenpoutou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查九莲宝灯（同花色1112345678999+同花色任意1张）
        
        如1112345678999m + 5m
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        # 只能有一种花色
        suits_present = set(t.suit for t in tile_counts.keys())
        if len(suits_present) != 1 or 'honor' in suits_present:
            return False
        
        suit = list(suits_present)[0]
        
        # 标准九莲宝灯：1112345678999
        standard = {1: 3, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 3}
        
        # 实际手牌
        actual = {}
        for val in range(1, 10):
            actual[val] = tile_counts.get(MahjongTile(suit, val), 0)
        
        # 检查是否满足：每个值都>=标准数量，且多出1张
        extra = 0
        for val in range(1, 10):
            diff = actual[val] - standard[val]
            if diff < 0:
                return False
            extra += diff
        
        # 多出恰好1张
        return extra == 1
    
    @staticmethod
    def _is_suuankou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查四暗刻（4个暗刻+1对子）
        
        注意：这里简化检测手牌中4组刻子，不区分暗刻/明刻
        """
        if tile_counts is None:
            tile_counts = Counter(tiles)
        if len(tiles) != 14:
            return False
        
        # 4个刻子+1个对子
        for mentsu_list, pair_tile in YakuAnalyzer._decompose_4m1p(tile_counts):
            koutsu_count = sum(1 for mtype, _ in mentsu_list if mtype == 'koutsu')
            if koutsu_count == 4:
                return True
        return False
    
    # ============================================================
    # 混老头
    # ============================================================
    
    @staticmethod
    def _is_honroutou(tiles: List[MahjongTile], tile_counts: Counter = None) -> bool:
        """检查混老头（所有牌都是幺九牌，含字牌和数牌1/9）"""
        if tile_counts is None:
            tile_counts = Counter(tiles)
        return all(tile.is_yaochu() for tile in tile_counts.keys())


class WinProbabilityCalculator:
    """胜率计算器"""
    
    @staticmethod
    def calculate_shanten(hand_tiles: List[MahjongTile]) -> int:
        """计算向听数"""
        if len(hand_tiles) == 0:
            return 6  # 空手牌
        
        # 简化的向听数计算
        unique_tiles = len(set(hand_tiles))
        pairs = sum(1 for count in Counter(hand_tiles).values() if count >= 2)
        
        # 基于牌数和配对数估算向听数
        base_shanten = max(0, 8 - unique_tiles - pairs)
        
        # 手牌太少时的调整
        if len(hand_tiles) < 13:
            return max(base_shanten, 14 - len(hand_tiles) - 1)
        
        return max(0, base_shanten)
    
    @staticmethod
    def estimate_win_probability(hand_tiles: List[MahjongTile], remaining_tiles: int = 70) -> float:
        """估算和牌概率"""
        shanten = WinProbabilityCalculator.calculate_shanten(hand_tiles)
        
        if shanten == 0:
            # 听牌状态 - 较高概率
            return min(0.8, remaining_tiles / 100)
        elif shanten == 1:
            # 一向听 - 中等概率
            return min(0.6, remaining_tiles / 120)
        elif shanten == 2:
            # 二向听 - 较低概率
            return min(0.3, remaining_tiles / 200)
        else:
            # 多向听 - 很低概率
            return min(0.1, remaining_tiles / 300)
    
    @staticmethod
    def calculate_tile_efficiency(hand_tiles: List[MahjongTile]) -> Dict[MahjongTile, float]:
        """计算各牌的进张效率"""
        efficiency = {}
        
        for tile in hand_tiles:
            # 简化的效率计算
            if tile.is_honor() or tile.is_terminal():
                efficiency[tile] = 0.3  # 字牌和老头牌效率较低
            else:
                efficiency[tile] = 0.8  # 中张数牌效率较高
        
        return efficiency


__all__ = ['MahjongTile', 'Suit', 'YakuAnalyzer', 'WinProbabilityCalculator']